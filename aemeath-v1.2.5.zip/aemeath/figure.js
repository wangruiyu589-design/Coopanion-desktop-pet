/**
 * 爱弥斯 (Aemeath, fan-made, Wuthering Waves): a chibi figure with two forms for the Coopanion kit (web/kit/body.js):
 *   n — her normal form (pink ponytail, white dress, galaxy coat tails), drawn with the kit's createRig;
 *   q — her mech form (隧者兵装 / 机兵形态, silver-white armour, feather-plate wings), also a rig, hovering.
 * Switching form plays a full-screen cut-in transition (pre-rendered shots of the approved art, with blade wipes,
 * the dimmed desktop and the heart glow drawn live over the real desktop), with the official voice lines and
 * music. She can sing 《远航星的告别》 to the end (`sing`): mouth from the vocal's envelope, lyrics over her head.
 *
 * Rig space = the kit's logo space: x=128 under the body, soles at y=256, facing right.
 * Structure follows Coopanion's web/whale/figure.js (AGPL-3.0-or-later, Pal-AI-Lab), from which this is derived.
 */
const f1 = n => Math.round(n * 100) / 100;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, k) => a + (b - a) * k;
const ease = (rate, dt) => 1 - Math.exp(-rate * dt);
const bump = u => Math.sin(Math.PI * clamp(u, 0, 1));
const smooth = (a, b, x) => { const k = clamp((x - a) / (b - a), 0, 1); return k * k * (3 - 2 * k); };
const SVGNS = 'http://www.w3.org/2000/svg';
const TAU = Math.PI * 2;

function spring(k, c, lim = Infinity) {
  return {
    x: 0, v: 0,
    step(target, dt) {
      if (!Number.isFinite(target) || !Number.isFinite(dt)) return this.x;
      this.v += ((target - this.x) * k - this.v * c) * dt;
      this.x += this.v * dt;
      if (Math.abs(this.x) > lim) { this.x = Math.sign(this.x) * lim; this.v = 0; }
      return this.x;
    },
  };
}
/** A leg's warp: below the hip it turns about the pivot by `a` degrees and lifts by `ty`; above, the turn fades out. */
function hinge([px, py], a, ty) {
  const c = Math.cos(a * Math.PI / 180), s = Math.sin(a * Math.PI / 180);
  return (u, v, x, y) => {
    const w = smooth(py - 6, py + 12, y), lx = x - px, ly = y - py;
    return [(lx * c - ly * s - lx) * w, ((lx * s + ly * c - ly) + ty) * w];
  };
}
/** A leg with a knee: below the hip everything turns about the hip by p.a; below the knee the shin turns a further p.b
 *  about the (moved) knee, blended over a few px so the knee rounds instead of creasing. */
function kneeHinge([px, py], p) {
  const ky = py + 41;                                     // knee height (rig px): just under the boot top
  const ca = Math.cos(p.a * Math.PI / 180), sa = Math.sin(p.a * Math.PI / 180);
  return (u, v, x, y) => {
    // Smooth hip rotation from the pelvic root (py - 10) down, tucked cleanly behind n_body's V-cut skirt (z=4.0)
    const w = smooth(py - 12, py + 6, y), wTy = smooth(py - 4, py + 14, y), lx = x - px, ly = y - py;
    let X = px + lx * ca - ly * sa, Y = py + lx * sa + ly * ca;
    const kb = smooth(ky - 14, ky + 14, y);
    if (kb > 0 && p.b) {
      const kx = px - (ky - py) * sa, kyy = py + (ky - py) * ca;          // the knee after the hip turn
      const b = p.b * kb * Math.PI / 180, cb = Math.cos(b), sb = Math.sin(b), dx = X - kx, dy = Y - kyy;
      X = kx + dx * cb - dy * sb; Y = kyy + dx * sb + dy * cb;
    }
    return [(X - x) * w, (Y - y) * w + p.ty * wTy];
  };
}
function loadImage(url) {
  return new Promise((ok, bad) => { const im = new Image(); im.crossOrigin = 'anonymous'; im.onload = () => ok(im); im.onerror = bad; im.src = String(url); });
}

/* the kit's faces → which drawn face patch gives the eyes and which the mouth (normal form), and extra blush */
const NF = {
  neutral: ['neutral', 'neutral'], happy: ['happy', 'happy'], wink: ['wink', 'wink'], love: ['love', 'love', .72],
  shy: ['neutral', 'neutral', .9], surprised: ['surprised', 'surprised'], angry: ['angry', 'angry'], sad: ['sad', 'sad'],
  sleepy: ['blink', 'neutral'], sleep: ['sleep', 'sleep'], dizzy: ['dizzy', 'dizzy', .4], dragged: ['drag', 'drag'],
  content: ['neutral', 'happy', .25], waking: ['blink', 'neutral'], squeeze: ['blink', 'neutral'], listening: ['neutral', 'neutral'],
  thinking: ['think', 'think'], run: ['neutral', 'happy'], smug: ['smug', 'smug'], pout: ['neutral', 'think', .6],
  worried: ['worried', 'worried'], determined: ['angry', 'neutral'], flustered: ['drag', 'drag', .64], scared: ['surprised', 'worried'],
  excited: ['excited', 'excited'], cry: ['cry', 'cry'], bowing: ['blink', 'neutral'], confused: ['think', 'worried'],
  singing: ['sing', 'sing'], hearting: ['love', 'love', .72],
};
const HEAD_TILT = { shy: 6, thinking: -7, smug: -5, pout: -4, confused: -7, worried: 3, cry: 4, singing: 0 };

export async function createAemeathFigure(base = new URL('./', import.meta.url), opts = {}) {
  const createRig = opts.kit?.createRig ?? (await import('../kit/rig.js')).createRig;
  const model = opts.model || await (await fetch(new URL('model.json', base))).json();
  const asset = opts.asset || (p => new URL(p, base));
  const load = opts.loadImage || loadImage;
  const host = opts.host || null;
  const FORMS = model.forms;
  const SONG = model.song;

  /* ---------- scheme: `<form>-<speech>` (selectable Normal / Mech appearance) ---------- */
  const pickOf = (id, o = {}) => {
    if (id && typeof id === 'object') {
      return {
        form: id.form === 'mech' || id.form === 'q' ? 'q' : 'n',
        speech: id.speech ?? o?.pick?.speech ?? o?.speech,
      };
    }
    const parts = String(id ?? '').split('-');
    const f = parts[0];
    const spVal = parts.includes('off') ? 'off' : parts.includes('on') ? 'on' : (o?.pick?.speech ?? o?.speech);
    return { form: f === 'mech' ? 'q' : 'n', speech: spVal };
  };
  let { form, speech: initSpeech } = pickOf(opts.scheme, opts);
  let schemeId = `${form === 'q' ? 'mech' : 'normal'}-${initSpeech === 'off' ? 'off' : 'on'}`;

  /* ---------- textures ---------- */
  const tex = {}, img = {};
  await Promise.all([
    ...Object.values(FORMS).flatMap(F => F.parts.map(async p => { tex[p.tex] = await load(asset(`tex/${p.tex}.png`)); })),
    ...FORMS.n.patches.map(async n => { img[`n_${n}`] = await load(asset(`feat/n_${n}.png`)); }),
    ...['visor_on', 'visor_off', 'core_on', 'core_off'].map(async n => { img[`q_${n}`] = await load(asset(`feat/q_${n}.png`)); }),
  ]);

  /* ---------- rigs ---------- */
  const VIEW = [-24, -16, 280, 272];
  function layoutOf(k) {
    const F = FORMS[k], PV = F.pivots;
    const box = Object.fromEntries(F.parts.map(p => [p.id, p.box]));
    const rectOf = id => { const [x, y, w, h] = box[id]; return [x, y, x + w, y + h]; };
    let deformers;
    const parts = F.parts.map(p => ({ ...p }));
    const union = (...ids) => { const r = ids.map(rectOf); return [Math.min(...r.map(q => q[0])), Math.min(...r.map(q => q[1])), Math.max(...r.map(q => q[2])), Math.max(...r.map(q => q[3]))]; };
    if (k === 'n') {
      deformers = {
        body: { kind: 'rot', pivot: PV.body },
        bodyWarp: { kind: 'warp', parent: 'body', rect: rectOf('n_body') },
        coatWarp: { kind: 'warp', parent: 'body', rect: rectOf('n_coat') },
        ribF: { kind: 'warp', parent: 'coatWarp', rect: rectOf('n_rib_F') },
        ribB: { kind: 'warp', parent: 'coatWarp', rect: rectOf('n_rib_B') },
        // legs: a hip hinge + a knee (thigh and shin turn separately; the thigh top stays at the hip, under the leotard)
        legF: { kind: 'warp', parent: 'body', rect: rectOf('n_leg_F') },
        legB: { kind: 'warp', parent: 'body', rect: rectOf('n_leg_B') },
        waist: { kind: 'rot', parent: 'body', pivot: PV.waist },
        neck: { kind: 'rot', parent: 'waist', pivot: PV.neck },
        headWarp: { kind: 'warp', parent: 'neck', rect: rectOf('n_head') },
        hairSway: { kind: 'warp', parent: 'neck', rect: rectOf('n_hair_back') },
        // Unified whole arms (Coopanion web/whale style): each arm is a single whole component deformed continuously
        shF: { kind: 'rot', parent: 'waist', pivot: PV.shF },
        foreF: { kind: 'rot', parent: 'shF', pivot: PV.elF },
        slvF: { kind: 'warp', parent: 'shF', rect: rectOf('n_arm_F') },
        shB: { kind: 'rot', parent: 'waist', pivot: PV.shB },
        foreB: { kind: 'rot', parent: 'shB', pivot: PV.elB },
        slvB: { kind: 'warp', parent: 'shB', rect: rectOf('n_arm_B') },
      };
      for (const p of parts) {
        if (p.id === 'n_leg_F') { p.grid = [10, 24]; p.z = 3.2; }
        else if (p.id === 'n_leg_B') p.grid = [10, 24];
        else if (p.id === 'n_body') { p.grid = [16, 20]; p.z = 2.8; }
        else if (p.id === 'n_skirt_F') { p.parent = 'bodyWarp'; p.grid = [16, 20]; p.z = 4.0; }
        else if (p.id === 'n_arm_F') { p.parent = 'slvF'; p.grid = [28, 24]; p.z = 2.2; }
        else if (p.id === 'n_arm_B') { p.parent = 'slvB'; p.grid = [30, 24]; }
      }
      parts.push({ id: 'n_faceFx', tex: 'n_faceFx', box: F.face.box, z: 9, parent: 'headWarp', grid: [12, 12] });
    } else {
      deformers = {
        body: { kind: 'rot', pivot: PV.body },
        bodyWarp: { kind: 'warp', parent: 'body', rect: rectOf('q_body') },
        waist: { kind: 'rot', parent: 'body', pivot: PV.waist },
        neckHead: { kind: 'rot', parent: 'waist', pivot: PV.neck },
        // 4 independent floating wings (detached from the back, hovering in mid-air with phase-staggered oscillation)
        wingRUp:     { kind: 'rot',  parent: 'waist',   pivot: PV.wingRUp || PV.wingBack },
        wingRLow:    { kind: 'rot',  parent: 'waist',   pivot: PV.wingRLow || PV.wingBack },
        wingLUp:     { kind: 'rot',  parent: 'waist',   pivot: PV.wingLUp || PV.wingFront },
        wingLLow:    { kind: 'rot',  parent: 'waist',   pivot: PV.wingLLow || PV.wingFront },
        wingRUpFlex: { kind: 'warp', parent: 'wingRUp', rect: rectOf('q_wing_R_up') },
        wingRLowFlex:{ kind: 'warp', parent: 'wingRLow',rect: rectOf('q_wing_R_low') },
        wingLUpFlex: { kind: 'warp', parent: 'wingLUp', rect: rectOf('q_wing_L_up') },
        wingLLowFlex:{ kind: 'warp', parent: 'wingLLow',rect: rectOf('q_wing_L_low') },
        // Unified whole mechanical arms (q_arm_L and q_arm_R)
        shL: { kind: 'rot', parent: 'waist', pivot: PV.shL },
        foreL: { kind: 'rot', parent: 'shL', pivot: PV.elL },
        armL: { kind: 'warp', parent: 'shL', rect: rectOf('q_arm_L') },
        shR: { kind: 'rot', parent: 'waist', pivot: PV.shR },
        foreR: { kind: 'rot', parent: 'shR', pivot: PV.elR },
        armR: { kind: 'warp', parent: 'shR', rect: rectOf('q_arm_R') },
      };
      for (const p of parts) {
        if (p.id === 'q_arm_L') { p.parent = 'armL'; p.grid = [12, 16]; }
        else if (p.id === 'q_arm_R') { p.parent = 'armR'; p.grid = [12, 16]; }
      }
      parts.push({ id: 'q_visorFx', tex: 'q_visorFx', box: F.patch.visor, z: 7.5, parent: 'neckHead', grid: [2, 2] });
      parts.push({ id: 'q_coreFx', tex: 'q_coreFx', box: F.patch.core, z: 3.5, parent: 'bodyWarp', grid: [2, 2] });
    }
    // which way is "outward" for each shoulder (a positive turn raises an arm on the left of the body)
    const out = n => Math.sign(PV.body[0] - PV[n][0]) || 1;
    return { PV, deformers, parts, rectOf, out };
  }
  const LAY = { n: layoutOf('n'), q: layoutOf('q') };

  /* ---------- live textures: her face, the mech's visor and core ---------- */
  const mk = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
  const [FW, FH] = FORMS.n.face.px, MROW = FORMS.n.face.mouthRow;
  const faceCv = mk(FW, FH), fg = faceCv.getContext('2d');
  const visorCv = mk(img.q_visor_off.width, img.q_visor_off.height), vg = visorCv.getContext('2d');
  const coreCv = mk(img.q_core_off.width, img.q_core_off.height), cg = coreCv.getContext('2d');
  let blushK = 0, talkSm = 0, voiceUntil = 0;
  /** Eyes from one patch, mouth from another (each a whole face patch, split at the mouth row). */
  let eyeShiftX = 0, eyeShiftY = 0;
  function half(name, top, alpha = 1, sy = 1, sx = 1) {
    const im = img[`n_${name}`]; if (!im || alpha <= .01) return;
    fg.globalAlpha = alpha;
    if (top) fg.drawImage(im, 0, 0, FW, MROW, Math.round(eyeShiftX), Math.round(eyeShiftY), FW, MROW);
    else if (sy === 1 && sx === 1) fg.drawImage(im, 0, MROW, FW, FH - MROW, 0, MROW, FW, FH - MROW);
    else {
      // Anchor mouth scaling strictly at the anatomical mouth center (X_LIP = 215, Y_LIP = 197)
      // so the mouth opens and closes in place without ever sliding up toward the nose!
      const h = FH - MROW, X_LIP = 215, Y_LIP = 197;
      const dw = FW * sx, dh = h * sy;
      const dx = X_LIP * (1 - sx), dy = MROW + (Y_LIP - MROW) * (1 - sy);
      fg.drawImage(im, 0, MROW, FW, h, dx, dy, dw, dh);
    }
    fg.globalAlpha = 1;
  }
  function paintFace(face, o, sing) {
    fg.clearRect(0, 0, FW, FH);
    eyeShiftX = clamp((o.look?.[0] || 0) * 1.45, -7, 7);
    eyeShiftY = clamp((o.look?.[1] || 0) * 1.25, -5, 5);
    const [eyes, mouth, blush] = NF[face] || NF.neutral;
    blushK = lerp(blushK, blush || 0, .15);
    if (blushK > .02) {
      // the drawn patches carry their own blush; this one is for the moods that borrow a plain face
      for (const [x, y, r] of [[FW * .29, FH * .61, 31], [FW * .76, FH * .60, 25]]) {
        const gr = fg.createRadialGradient(x, y, 0, x, y, r);
        gr.addColorStop(0, `rgba(255,120,150,${f1(.5 * blushK)})`); gr.addColorStop(1, 'rgba(255,120,150,0)');
        fg.fillStyle = gr; fg.fillRect(x - r, y - r, 2 * r, 2 * r);
      }
    }
    const open = ['neutral', 'surprised', 'angry', 'sad', 'think', 'smug', 'worried', 'excited', 'love', 'wink'].includes(eyes);
    const shut = open ? Math.max(o.blink || 0, o.eyeClose || 0) : 0;
    const renderMouthOpen = (openK, baseMouth) => {
      if (openK <= 0.08) {
        half(baseMouth, false, 1);
      } else {
        // Continuous single-family D-mouth articulation ('sing' mouth anchored at X_LIP=215, Y_LIP=197)
        const u = smooth(0.08, 0.92, openK);
        half('sing', false, 1, 0.24 + 0.76 * u, 0.84 + 0.16 * u);
      }
    };
    if (sing) {
      if (sing.eyes > 0.45) half('sing', true, 1); else half('neutral', true, 1);
      renderMouthOpen(clamp(sing.m || 0, 0, 1), 'neutral');
      return;
    }
    if (shut > 0.42) half('blink', true, 1);
    else half(eyes, true, 1);
    const wt = (o.t || 0);
    const syl = 0.48 + 0.38 * Math.sin(wt * 11.2) + 0.28 * Math.sin(wt * 17.8 + 0.9) + 0.18 * Math.cos(wt * 6.4);
    const realVoice = wt < voiceUntil ? clamp(syl, 0, 1) : 0;
    const rawTalk = Math.max(realVoice, (o.talk || 0) > 0.12 ? (o.talk || 0) : 0);
    talkSm = lerp(talkSm, rawTalk, rawTalk > talkSm ? 0.32 : 0.22);
    renderMouthOpen(talkSm, mouth);
  }
  /* the visor: unlit glass, the eyes drawn as light (an LED face) */
  const EA = [86, 90, 42, 31], EB = [224, 100, 18, 25];   // eye centres and half-sizes in the visor patch (px)
  function glowStroke(g, draw, a = 1, col = '#8ff6ff') {
    g.save(); g.globalAlpha = a; g.strokeStyle = col; g.fillStyle = col; g.lineCap = 'round'; g.lineJoin = 'round';
    g.shadowColor = col; g.shadowBlur = 14; draw(g); g.shadowBlur = 5; draw(g); g.restore();
  }
  function ledEye(g, [cx, cy, rx, ry], shape, t, s = 1) {
    const w = Math.max(4, rx * .16) * s;
    g.lineWidth = w;
    switch (shape) {
      case 'up': g.beginPath(); g.moveTo(cx - rx * .8, cy + ry * .25); g.quadraticCurveTo(cx, cy - ry * 1.1, cx + rx * .8, cy + ry * .25); g.stroke(); break;
      case 'down': g.beginPath(); g.moveTo(cx - rx * .8, cy - ry * .1); g.quadraticCurveTo(cx, cy + ry * .55, cx + rx * .8, cy - ry * .1); g.stroke(); break;
      case 'line': g.beginPath(); g.moveTo(cx - rx * .8, cy); g.lineTo(cx + rx * .8, cy); g.stroke(); break;
      case 'heart': {
        const k = rx * .9 * (1 + .06 * Math.sin(t * 9)) / 19; g.save(); g.translate(cx, cy); g.scale(k, k);
        g.beginPath(); g.moveTo(0, 14); g.bezierCurveTo(-7, 8, -19, 1, -19, -6); g.bezierCurveTo(-19, -15, -8, -18, 0, -9); g.bezierCurveTo(8, -18, 19, -15, 19, -6); g.bezierCurveTo(19, 1, 7, 8, 0, 14); g.restore(); g.fillStyle = '#ff8fc8'; g.fill(); break;
      }
      case 'spiral': {
        g.beginPath(); for (let i = 0; i < 60; i++) { const a = i * .32, r = rx * .9 * i / 60; const x = cx + r * Math.cos(a), y = cy + r * Math.sin(a) * ry / rx; i ? g.lineTo(x, y) : g.moveTo(x, y); } g.lineWidth = w * .6; g.stroke(); break;
      }
      case 'gt': case 'lt': { const d = shape === 'gt' ? 1 : -1; g.beginPath(); g.moveTo(cx - d * rx * .6, cy - ry * .7); g.lineTo(cx + d * rx * .6, cy); g.lineTo(cx - d * rx * .6, cy + ry * .7); g.stroke(); break; }
      case 'angry': g.beginPath(); g.moveTo(cx - rx * .8, cy - ry * .5); g.lineTo(cx + rx * .8, cy + ry * .1); g.stroke(); break;
      case 'sad': g.beginPath(); g.moveTo(cx - rx * .8, cy + ry * .1); g.lineTo(cx + rx * .8, cy - ry * .5); g.stroke(); break;
      case 'star': {
        g.save(); g.translate(cx, cy); const R = rx * .95 * (.9 + .1 * Math.sin(t * 7)), q = R * .32;
        g.beginPath(); g.moveTo(0, -R); g.quadraticCurveTo(q, -q, R, 0); g.quadraticCurveTo(q, q, 0, R); g.quadraticCurveTo(-q, q, -R, 0); g.quadraticCurveTo(-q, -q, 0, -R); g.fill(); g.restore(); break;
      }
      default: g.beginPath(); g.ellipse(cx, cy, rx * .78 * s, ry * .62 * s, 0, 0, TAU); g.fill();
    }
  }
  const QF = {
    happy: 'up', wink: ['ring', 'up'], love: 'heart', sleepy: 'line', sleep: 'down', dizzy: 'spiral', dragged: ['gt', 'lt'], flustered: ['gt', 'lt'],
    angry: 'angry', determined: 'angry', sad: 'sad', worried: 'sad', cry: 'down', excited: 'star', surprised: 'wide', scared: 'wide',
    squeeze: 'line', bowing: 'line', smug: 'line', singing: 'up', hearting: 'heart', content: 'ring', waking: 'line',
  };
  let visorLit = 1, coreBeat = 0;
  function paintVisor(face, o, t, sing) {
    vg.clearRect(0, 0, visorCv.width, visorCv.height);
    vg.drawImage(img.q_visor_off, 0, 0);
    let sh = QF[face] || 'ring';
    if (sing) sh = sing.m > .2 ? 'up' : 'ring';
    const shut = Math.max(o.blink || 0, o.eyeClose || 0);
    const [sa, sb] = Array.isArray(sh) ? sh : [sh, sh];
    const lit = visorLit * (.85 + .15 * Math.sin(t * 2.2));
    if (sa === 'ring' && sb === 'ring' && shut < .4) { vg.globalAlpha = lit; vg.drawImage(img.q_visor_on, 0, 0); vg.globalAlpha = 1; return; }
    glowStroke(vg, g => {
      ledEye(g, EA, shut >= .4 && sa === 'ring' ? 'line' : sa === 'wide' ? 'ring' : sa, t, sa === 'wide' ? 1.25 : 1);
      ledEye(g, EB, shut >= .4 && sb === 'ring' ? 'line' : sb === 'wide' ? 'ring' : sb, t, sb === 'wide' ? 1.25 : 1);
    }, lit);
  }
  function paintCore(face, t, sing, extra = 0) {
    cg.clearRect(0, 0, coreCv.width, coreCv.height);
    cg.drawImage(img.q_core_off, 0, 0);
    const beat = Math.pow(Math.max(0, Math.sin(t * Math.PI * 1.3)), 8);
    const k = clamp(.75 + .25 * beat + (sing ? .5 * sing.m : 0) + extra, 0, 1.6);
    cg.globalAlpha = clamp(k, 0, 1); cg.drawImage(img.q_core_on, 0, 0); cg.globalAlpha = 1;
    if (face === 'love' || face === 'hearting' || extra > .1 || k > 1) {
      const w = coreCv.width, h = coreCv.height, gr = cg.createRadialGradient(w / 2, h * .55, 0, w / 2, h * .55, w * .45);
      const pink = face === 'love' || face === 'hearting' || extra > .1;
      gr.addColorStop(0, pink ? `rgba(255,140,200,${f1(.7 * clamp(k - .3, 0, 1))})` : `rgba(160,250,255,${f1(.5 * (k - 1))})`); gr.addColorStop(1, 'rgba(255,140,200,0)');
      cg.globalCompositeOperation = 'lighter'; cg.fillStyle = gr; cg.fillRect(0, 0, w, h); cg.globalCompositeOperation = 'source-over';
    }
  }

  /* ---------- mounting inside the pet's SVG group ---------- */
  let fo = null, canvas = null, fxG = null, rig = null, rigForm = null, mountedIn = null, pxScale = 0, frameN = 0;
  function mount(petG) {
    petG.textContent = '';
    rig?.dispose(); rig = null;
    const box = el => { el.setAttribute('x', VIEW[0]); el.setAttribute('y', VIEW[1]); el.setAttribute('width', VIEW[2] - VIEW[0]); el.setAttribute('height', VIEW[3] - VIEW[1]); return el; };
    canvas = document.createElementNS('http://www.w3.org/1999/xhtml', 'canvas');
    if (opts.raster) fo = box(document.createElementNS(SVGNS, 'image'));
    else { fo = box(document.createElementNS(SVGNS, 'foreignObject')); canvas.style.cssText = 'width:100%;height:100%;display:block'; fo.appendChild(canvas); }
    fxG = document.createElementNS(SVGNS, 'g');
    const backG = document.createElementNS(SVGNS, 'g');
    petG.append(backG, fo, fxG);
    mountedIn = petG; pxScale = 0; rigForm = null; fxBack = backG; fx = ''; fxb = '';
  }
  let fxBack = null;
  function buildRig() {
    if (rig) {
      // a disposed rig takes its GL context with it: the new form draws into a fresh canvas
      rig.dispose();
      const c2 = document.createElementNS('http://www.w3.org/1999/xhtml', 'canvas');
      c2.style.cssText = canvas.style.cssText;
      if (!opts.raster) fo.replaceChild(c2, canvas);
      canvas = c2;
    }
    const Lr = LAY[form];
    rig = createRig(canvas, { deformers: Lr.deformers, parts: Lr.parts, view: VIEW });
    for (const p of FORMS[form].parts) rig.upload(p.tex, tex[p.tex]);
    rigForm = form; pxScale = 0; fitCanvas();
  }
  let fixedRes = 0, decoded = null;
  function fitCanvas() {
    const m = fixedRes ? null : mountedIn?.getScreenCTM?.();
    if (!m && !fixedRes) return;
    const k = fixedRes || Math.hypot(m.c, m.d) * (window.devicePixelRatio || 1) * 1.25;
    if (Math.abs(k - pxScale) / (pxScale || 1) < .08) return;
    pxScale = k;
    canvas.width = Math.max(16, Math.round((VIEW[2] - VIEW[0]) * Math.min(k, 6)));
    canvas.height = Math.max(16, Math.round((VIEW[3] - VIEW[1]) * Math.min(k, 6)));
  }

  /* ---------- per-frame state ---------- */
  const sp = {
    hair: spring(40, 5, 2), hairY: spring(40, 6, 1.4), coat: spring(70, 7, 1.8), coatY: spring(70, 8, 1.2),
    head: spring(70, 10, 16), armF: spring(80, 11, 120), armB: spring(70, 10, 160),
    elF: spring(90, 12, 120), elB: spring(90, 12, 120),
    slvF: spring(28, 4.2, 30), slvB: spring(28, 4.2, 30),          // sleeve cloth: lags behind the arm, settles slowly
    ribF: spring(18, 2.6, 26), ribB: spring(16, 2.4, 26),          // ribbons: slow pendulums
    lockL: spring(34, 4, 14), lockR: spring(30, 3.6, 14),          // side locks
    wingF: spring(60, 7, 40), wingB: spring(60, 7, 40), legs: spring(30, 6, 1.5), hover: spring(20, 5, 30),
  };
  const st = { z: {}, alpha: {}, tint: {} };
  let lastT = null, prevTilt = 0, prevLow = 0, headTilt = 0, wTilt = 0, wLean = 0, facing = 1, faceSm = 1;
  let sitK = 0, walkK = 0, runK = 0, dragK = 0, swingK = 0, locoPh = 0;
  let swaySm = 0, tiltVelSm = 0, lowVSm = 0, vFSm = 0, vBSm = 0;
  const GROUP = { air: [1, 1], drag: [1, 1], crouch: [1, 1], land: [1, 1], walk: [1, .5], run: [1, .5], dance: [.6, 0] };
  const groupTilt = (mode, tilt, lean) => tilt * wTilt + lean * wLean + runK * (form === 'q' ? 14 : 8.5) * faceSm;
  let fx = '', fxb = '';
  const prevArm = {};
  let curFace = 'neutral', singNow = null;

  /* ---------- Wuthering Waves Aemeath (鸣潮·爱弥斯) 1-to-1 Synced Official Voice Lines & Speech Toggle ---------- */
  const IDLE_LINES = model.idleLines || [
    {"id": "idle_qihang", "zh": "启航之时！", "en": "Time to set sail!", "sound": "vQihang", "file": "snd/v_qihang.mp3", "dur": 2.4},
    {"id": "idle_shouhu", "zh": "世界，由我守护！", "en": "This world is mine to protect!", "sound": "vShouhu", "file": "snd/v_shouhu.mp3", "dur": 3.0},
    {"id": "idle_youling", "zh": "幽灵登台！", "en": "Digital Ghost, taking the stage!", "sound": "vYouling", "file": "snd/v_youling.mp3", "dur": 2.6},
    {"id": "idle_zhengjiu", "zh": "一起去拯救世界吧！", "en": "Let's go save the world together!", "sound": "vZhengjiu", "file": "snd/v_zhengjiu.mp3", "dur": 2.6},
    {"id": "idle_feiba", "zh": "飞吧！", "en": "Fly!", "sound": "vFeiba", "file": "snd/v_feiba.mp3", "dur": 2.0}
  ];
  let idleDeck = [], idleLineState = null, nextIdleLineT = 2.0, lastIdleIdx = -1, prevTalk = 0;
  let speechOn = (() => {
    if (initSpeech !== undefined) return initSpeech !== 'off';
    try { return localStorage.getItem('aemeath_speech_on') !== '0'; } catch { return true; }
  })();
  function pickNextIdleLine() {
    if (!idleDeck.length) {
      idleDeck = IDLE_LINES.map((_, i) => i);
      for (let i = idleDeck.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [idleDeck[i], idleDeck[j]] = [idleDeck[j], idleDeck[i]];
      }
      if (idleDeck.length > 1 && idleDeck[0] === lastIdleIdx) {
        [idleDeck[0], idleDeck[idleDeck.length - 1]] = [idleDeck[idleDeck.length - 1], idleDeck[0]];
      }
    }
    const idx = idleDeck.shift();
    lastIdleIdx = idx;
    return IDLE_LINES[idx];
  }
  function matchLineFromText(txt) {
    if (!txt) return null;
    const s = String(txt);
    if (s.includes('启航') || /set sail/i.test(s)) return IDLE_LINES.find(l => l.id === 'idle_qihang');
    if (s.includes('守护') || /protect/i.test(s)) return IDLE_LINES.find(l => l.id === 'idle_shouhu');
    if (s.includes('幽灵') || /ghost/i.test(s)) return IDLE_LINES.find(l => l.id === 'idle_youling');
    if (s.includes('拯救') || /save the world/i.test(s)) return IDLE_LINES.find(l => l.id === 'idle_zhengjiu');
    if (s.includes('飞吧') || /\bfly\b/i.test(s)) return IDLE_LINES.find(l => l.id === 'idle_feiba');
    return null;
  }
  function findHostBubbleElements() {
    const out = [];
    try {
      const roots = new Set();
      if (typeof document !== 'undefined') roots.add(document);
      if (host?.root?.ownerDocument) roots.add(host.root.ownerDocument);
      if (host?.root?.getRootNode) roots.add(host.root.getRootNode());
      const sel = '.bubble, .speech, .quote, .dialog, .dialogue, .pet-bubble, .pet-speech, .chat-bubble, [data-bubble], [data-speech], [class*="bubble"], [class*="speech"], [class*="quote"]';
      for (const r of roots) {
        if (!r?.querySelectorAll) continue;
        for (const el of r.querySelectorAll(sel)) {
          if (fo && fo.contains(el)) continue;
          if (fxG && fxG.contains(el)) continue;
          if (el.tagName === 'BUTTON' || el.tagName === 'INPUT' || el.tagName === 'SELECT') continue;
          out.push(el);
        }
      }
    } catch {}
    return out;
  }
  function syncHostAemeathSpeech(lineObj, tNow = 0) {
    const els = findHostBubbleElements();
    let anyVisibleHostBubble = false;
    for (const el of els) {
      try {
        if (!speechOn) {
          el.style.visibility = 'hidden';
          el.style.opacity = '0';
          continue;
        } else if (el.style.visibility === 'hidden') {
          el.style.visibility = '';
          el.style.opacity = '';
        }
        const st = typeof getComputedStyle !== 'undefined' ? getComputedStyle(el) : null;
        if (st && (st.display === 'none' || st.visibility === 'hidden' || parseFloat(st.opacity) < 0.05)) continue;
        const leaf = el.querySelector?.('span, p, div') || el;
        const curTxt = (leaf.textContent || '').trim();
        if (!curTxt) continue;
        anyVisibleHostBubble = true;
        if (lineObj) {
          if (curTxt !== lineObj.zh) {
            leaf.textContent = lineObj.zh;
            el.dataset.aemeathSyncedTxt = lineObj.zh;
          }
        } else if (el.dataset.aemeathSyncedTxt !== curTxt) {
          const matched = matchLineFromText(curTxt) || pickNextIdleLine();
          if (matched) {
            leaf.textContent = matched.zh;
            el.dataset.aemeathSyncedTxt = matched.zh;
            idleLineState = { line: matched, t0: tNow, dur: matched.dur || 2.8 };
            playPackSound(matched.sound, matched.file, 0.95);
          }
        }
      } catch {}
    }
    return anyVisibleHostBubble;
  }
  function triggerAemeathLine(line, tNow, vol = 0.94) {
    if (!line) return;
    playPackSound(line.sound, line.file, vol);
    voiceUntil = Math.max(voiceUntil, tNow + Math.min(2.6, line.dur || 1.6));
    if (speechOn) {
      idleLineState = { line, t0: tNow, dur: line.dur || 2.8 };
      syncHostAemeathSpeech(line, tNow);
    }
  }

  /* ---------- singing (automatic 《远航星的告别》 playback + vocal lip-sync + bilingual lyrics) ---------- */
  let sing = null, songContext = null, songBuffer = null, songPaused = false;
  const LINES = SONG.lines, MOUTH = SONG.mouth, MFPS = SONG.fps;
  let activeVoiceAudio = null, lastVoicePlayMs = 0;
  function stopActiveVoice() {
    if (activeVoiceAudio) {
      try { activeVoiceAudio.pause(); activeVoiceAudio.src = ''; } catch {}
      activeVoiceAudio = null;
    }
  }
  function playPackSound(id, file, vol = 0.9) {
    const nowMs = typeof performance !== 'undefined' ? performance.now() : Date.now();
    if (nowMs - lastVoicePlayMs < 180) return null;
    lastVoicePlayMs = nowMs;
    if (host?.sound) {
      try { host.sound(id, 'face'); } catch {}
    }
    if (typeof Audio !== 'undefined' && file) {
      try {
        stopActiveVoice();
        const a = new Audio(String(asset(file)));
        a.volume = vol;
        activeVoiceAudio = a;
        a.play?.().catch?.(() => {});
        return a;
      } catch {}
    }
    return null;
  }
  // The figure sandbox allows fetching this pack's files but blocks media elements.
  // Decode once, and use a cancellable source and the audio context's playback clock.
  async function startSing() {
    if (songPaused) return;
    stopSing();
    stopActiveVoice();
    idleLineState = null;
    const request = { source: null, startedAt: 0, eyes: 0 };
    sing = request;
    try {
      const Context = globalThis.AudioContext || globalThis.webkitAudioContext;
      if (!Context) throw new Error('Web Audio is unavailable');
      const ctx = songContext ??= new Context();
      const resume = ctx.resume();
      songBuffer ??= fetch(asset(SONG.file)).then(response => {
        if (!response.ok) throw new Error(`Song request failed: ${response.status}`);
        return response.arrayBuffer();
      }).then(bytes => ctx.decodeAudioData(bytes)).catch(error => {
        songBuffer = null;
        throw error;
      });
      const [, buffer] = await Promise.all([resume, songBuffer]);
      if (sing !== request) return;
      const source = ctx.createBufferSource();
      const gain = ctx.createGain();
      gain.gain.value = .85;
      source.buffer = buffer;
      source.connect(gain);
      gain.connect(ctx.destination);
      request.source = source;
      request.gain = gain;
      request.startedAt = ctx.currentTime;
      source.onended = () => { if (sing === request) stopSing(); };
      source.start(request.startedAt);
    } catch (error) {
      if (sing === request) {
        stopSing();
        console.error('Aemeath song playback failed', error);
      }
    }
  }
  function stopSing() {
    const active = sing;
    sing = null;
    singNow = null;
    if (active?.source) {
      active.source.onended = null;
      try { active.source.stop(); } catch {}
      active.source.disconnect();
      active.gain.disconnect();
    }
  }
  function setSongPaused(paused) {
    if (songPaused === paused) return;
    songPaused = paused;
    if (!songContext || !sing) return;
    const change = paused ? songContext.suspend() : songContext.resume();
    change.catch(error => console.error('Aemeath song pause state failed', error));
  }
  function singState() {
    if (songPaused || !sing?.source || songContext.state !== 'running') return null;
    const u = Math.max(0, songContext.currentTime - sing.startedAt);
    if (u >= sing.source.buffer.duration) { stopSing(); return null; }
    const i = Math.floor(u * MFPS), m = MOUTH[clamp(i, 0, MOUTH.length - 1)] || 0;
    let acc = 0; for (let j = -8; j <= 8; j++) acc += MOUTH[clamp(i + j, 0, MOUTH.length - 1)] || 0;
    sing.eyes = lerp(sing.eyes ?? 0, smooth(.15, .4, acc / 17), .12);
    const line = LINES.find(l => u >= l.t && u < l.end) || null;
    return { u, m, eyes: sing.eyes, line, beat: (u * SONG.bpm / 60) % 1 };
  }

  let hiFpsTimer = null, lastDrawArgs = null;
  function ensure120HzLoop() {
    if (hiFpsTimer || typeof window === 'undefined') return;
    hiFpsTimer = setInterval(() => {
      if (gKind !== 'paperplane') {
        clearInterval(hiFpsTimer);
        hiFpsTimer = null;
        return;
      }
      if (lastDrawArgs && mountedIn) {
        const [petG, fc, oPrev] = lastDrawArgs;
        const nowT = (oPrev.t || 0) + (performance.now() / 1000 - lastDrawArgs[3]);
        draw(petG, fc, { ...oPrev, t: nowT }, true);
      }
    }, 1000 / 120);
  }
  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
  function setForm(k) {
    if (form === k) return;
    form = k; schemeId = `${form === 'q' ? 'mech' : 'normal'}-${speechOn ? 'on' : 'off'}`;
    reset(true);
  }

  /* ---------- the frame ---------- */
  let gWas = null;
  let gHeart = 0, gWish = 0, gPlane = 0, gKind = null, gProg = 0;
  let idleAcc = 0, autoPlaneT0 = null;
  // signature poses (outward-positive degrees): HA hands meet at the heart, WA the near arm up to the sky
  const HA = { a: -8, e: 52, qa: -14, qe: 46 }, WA = { a: 34, e: 44, e2: 50, qa: 54, qe: 44 };
  function draw(petG, fc, o, fromHiFps = false) {
    if (!fromHiFps && typeof performance !== 'undefined') lastDrawArgs = [petG, fc, o, performance.now() / 1000];
    if (mountedIn !== petG || !petG.contains(fo)) mount(petG);
    if (rigForm !== form || !rig) buildRig();
    if (frameN++ % 20 === 0) fitCanvas();
    const t = o.t, rawDt = lastT == null ? 1 / 60 : t - lastT; lastT = t;
    const dt = clamp(rawDt, 1 / 240, .05), dtSafe = Math.max(dt, 1 / 120);
    const mode = o.mode || 'idle'; let face = o.face || 'neutral'; curFace = face;
    facing = Math.sign(o.facing || 1) || 1;
    faceSm = lerp(faceSm, clamp(o.facing ?? facing, -1, 1), ease(14, dt));
    const walking = mode === 'walk' || mode === 'run', held = mode === 'drag', airborne = mode === 'air';
    // the pack's own words arrive as gestures; in addition, during calm idle she periodically folds & throws a paper plane!
    let g = o.gesture;
    const curTalk = o.talk || 0;
    if (!sing && curTalk > 0.12 && prevTalk <= 0.12 && !idleLineState) {
      const line = pickNextIdleLine();
      triggerAemeathLine(line, t, 0.94);
    }
    prevTalk = curTalk;
    if (speechOn && !sing && mode === 'idle') {
      if (!idleLineState && t >= nextIdleLineT) {
        const line = pickNextIdleLine();
        triggerAemeathLine(line, t, 0.92);
      }
      if (idleLineState) {
        const elapsed = t - idleLineState.t0;
        syncHostAemeathSpeech(idleLineState.line, t);
        if (elapsed >= idleLineState.dur) {
          idleLineState = null;
          nextIdleLineT = t + 6.5;
        }
      } else {
        syncHostAemeathSpeech(null, t);
      }
    } else if (!speechOn || sing) {
      idleLineState = null;
      if (!speechOn) syncHostAemeathSpeech(null, t);
    }
    const isCalmIdle = !g && !sing && mode === 'idle' && (o.sit ?? 0) < 0.1 && (face === 'neutral' || face === 'happy' || face === 'content');
    if (isCalmIdle) {
      idleAcc += dt;
      if (autoPlaneT0 === null && idleAcc >= 11.5) {
        autoPlaneT0 = t;
      }
      if (autoPlaneT0 !== null) {
        const pu = (t - autoPlaneT0) / 3.8;
        if (pu <= 1.0) {
          g = { kind: 'paperplane', k: pu };
        } else {
          autoPlaneT0 = null;
          idleAcc = 0;
        }
      }
    } else {
      idleAcc = 0;
      autoPlaneT0 = null;
    }
    const gk = g ? g.k : 0, gid = g ? `${g.kind}` : null;
    if (gid !== gWas) {

      if (gid === 'heart' || gid === 'starwish' || gid === 'paperplane') {
        const targetId = gid === 'heart'
          ? 'idle_zhengjiu'
          : gid === 'starwish'
            ? (form === 'q' ? 'idle_feiba' : 'idle_shouhu')
            : 'idle_qihang';
        const line = IDLE_LINES.find(l => l.id === targetId) || IDLE_LINES[0];
        triggerAemeathLine(line, t, 0.95);
      }
      gWas = gid;
    }
    const sg = singState(); singNow = sg;
    if (!sg && face === 'singing') face = 'neutral';
    sitK = lerp(sitK, clamp(o.sit ?? 0, 0, 1), ease(10, dt));
    dragK = lerp(dragK, held ? 1 : 0, ease(12, dt));
    walkK = lerp(walkK, walking ? 1 : 0, ease(10, dt));
    runK = lerp(runK, mode === 'run' ? 1 : 0, ease(8, dt));
    const walkOnlyK = clamp(walkK - runK, 0, 1);

    // Incrementally integrated locomotion phase: eliminates 100% of phase-windup vibration at start-of-run & boundary stops!
    const locoFreq = 1.42 + 0.36 * runK;
    if (walkK > .001) locoPh = (locoPh + dt * TAU * locoFreq) % (TAU * 100);
    else locoPh = lerp(locoPh, Math.round(locoPh / Math.PI) * Math.PI, ease(6, dt));

    // Smooth vertical velocity (ignoring body.js's sharp |sin(phase)| cusps during walk/run so springs never jitter)
    const low = o.low || 0, cleanLow = sitK * 29 + (1 - walkK) * low;
    const rawLowV = (cleanLow - prevLow) / dtSafe; prevLow = cleanLow;
    lowVSm = lerp(lowVSm, clamp(rawLowV, -180, 180), ease(14, dt));
    const lowV = lowVSm;

    const breath = Math.sin(t * (mode === 'sleep' ? 1.7 : 2.4));
    const env = (a, b2) => smooth(0, a, gk) * (1 - smooth(b2, 1, gk));
    const nod = g?.kind === 'nod' ? Math.sin(gk * Math.PI * 2) ** 2 * (1 - .3 * gk) : 0;
    const shake = g?.kind === 'shake' ? Math.sin(gk * Math.PI * 6) * smooth(0, .12, gk) * (1 - gk) : 0;
    const wave = g?.kind === 'wave' ? env(.15, .8) : 0;
    const bow = g?.kind === 'bow' ? env(.25, .7) : 0;
    const heartK = g?.kind === 'heart' ? env(.16, .8) : 0;
    const wish = g?.kind === 'starwish' ? env(.12, .86) : 0;
    const wishEyes = g?.kind === 'starwish' ? smooth(.55, .66, gk) * (1 - smooth(.88, .97, gk)) : 0;
    // Paper plane 360° orbit state: appears in starlight, orbits 360° around Aemeath (front -> right -> behind back -> left -> front), and vanishes while her gaze tracks it and her arms stay 100% calm!
    const planeK = g?.kind === 'paperplane' ? smooth(0, .10, gk) * (1 - smooth(.90, 1.0, gk)) : 0;
    const planeOrbU = g?.kind === 'paperplane' ? smooth(.03, .97, gk) : 0;
    const planeTheta = planeOrbU * TAU;
    // Gaze vector tracking the orbiting paper plane in real time (x: left-right, y: up-down)
    const planeLookX = planeK * Math.sin(planeTheta) * 4.8;
    const planeLookY = planeK * (Math.cos(planeTheta) * 1.8 - Math.sin(planeTheta * 2) * 0.8);
    if (planeK > 0.01) {
      ensure120HzLoop();
      o = { ...o, look: [lerp(o.look?.[0] || 0, planeLookX, planeK), lerp(o.look?.[1] || 0, planeLookY, planeK)] };
      if (form === 'n' && (face === 'neutral' || face === 'happy' || face === 'content')) face = 'content';
    }
    const tfU = 0, tfUpK = 0, tfDnK = 0;

    gHeart = heartK; gWish = wish; gPlane = planeK; gKind = g?.kind || null; gProg = gk;
    if (wishEyes > .5 && form === 'n') o = { ...o, eyeClose: Math.max(o.eyeClose || 0, 1) };
    const singK = sg ? smooth(0, 1.2, sg.u) * (1 - smooth(SONG.duration - 1, SONG.duration + .3, sg.u)) : 0;
    const beatS = sg ? Math.sin(sg.u * Math.PI * 2 * SONG.bpm / 60 / 2) : 0;

    /* head */
    let tiltT = o.look[0] * .7 + Math.sin(t * .9) * 1.2 + o.look[1] * .4 + (HEAD_TILT[face] || 0) * (1 - planeK * 0.6);
    if (mode === 'sleep') tiltT += 6;
    if (face === 'dizzy') tiltT += 3 * Math.sin(t * 4.5);
    if (held) tiltT += clamp(o.swing || 0, -28, 28) * .22;
    tiltT += singK * 5 * beatS;
    headTilt = sp.head.step(tiltT, dt);
    const [gT, gL] = GROUP[mode] || [0, 0];
    wTilt = lerp(wTilt, gT, ease(10, dt)); wLean = lerp(wLean, gL, ease(10, dt));
    const tfHeadTilt = tfUpK * (-8 * smooth(.15, .45, tfU) + 6 * smooth(.55, .85, tfU)) + tfDnK * (6 * smooth(.2, .6, tfU));
    const headA = headTilt + nod * 7 + shake * 2.5 + bow * 5.5 + wave * 3 + heartK * 5 * Math.sin(t * 3) - wish * 3 + tfHeadTilt;
    const rawTiltVel = (headA - prevTilt) / dtSafe; prevTilt = headA;
    tiltVelSm = lerp(tiltVelSm, clamp(rawTiltVel, -240, 240), ease(14, dt));
    const tiltVel = tiltVelSm;

    const angleX = clamp(clamp(o.look[0] / 5, -1, 1) * .95 + shake * 1.1, -1.4, 1.4);
    const angleY = clamp(clamp(o.look[1] / 4, -1, 1) * .80 + (mode === 'sleep' ? .8 : 0) + nod * .9 + bow * .75 - wish * .9 * (1 - wishEyes) + heartK * .25 - tfUpK * 0.65 * smooth(.15, .45, tfU), -1.4, 1.4);
    swaySm = lerp(swaySm, clamp((o.swing || 0) / 26, -1.6, 1.6), ease(14, dt));
    const sway = swaySm, up = airborne || held ? 1 : 0;

    // Legs: use clean stride phase during walk/run and decay smoothly to 0 at boundary without fighting body.js's pet.phase!
    const rawLegA = o.legs.map(l => -Math.atan2(l[2] - l[0], Math.max(4, l[3] - l[1])) * 180 / Math.PI);
    const rawLift = o.legs.map(l => clamp(29 - Math.hypot(l[2] - l[0], l[3] - l[1]), -8, 20));
    const strideDeg = 11.5 * walkOnlyK + 15.5 * runK;
    const strideLift = 4.2 * walkOnlyK + 6.8 * runK;
    const nonWalkLegK = clamp(dragK + (airborne ? 1 : 0) + (mode === 'dance' ? 1 : 0), 0, 1) * (1 - walkK);
    const legA = [0, 1].map(i => lerp(-Math.sin(locoPh + i * Math.PI) * strideDeg * walkK, rawLegA[i], nonWalkLegK));
    const lift = [0, 1].map(i => lerp(strideLift * Math.max(0, Math.cos(locoPh + i * Math.PI)) * walkK, rawLift[i], nonWalkLegK));
    st.z = {}; st.alpha = {}; st.tint = {};

    if (form === 'n') {
      const Lr = LAY.n, PV = Lr.PV;
      // Note: inside petG, scale(kx, ky) ALREADY mirrors horizontally when facing < 0, so in rig space +x is ALWAYS forward and -x is ALWAYS trailing!
      const mK = walkOnlyK + 1.25 * runK;
      const dragWave = dragK * Math.sin(t * 13);
      const hairStride = mK * (-0.50 + 0.44 * Math.sin(locoPh - 0.5) + 0.24 * Math.sin(locoPh * 2 - 0.8)) + dragK * 0.45 * Math.sin(t * 13 - 0.6);
      const coatStride = mK * (-0.42 + 0.38 * Math.sin(locoPh - 0.4) + 0.22 * Math.sin(locoPh * 2 - 0.6)) + dragK * 0.40 * Math.sin(t * 13 - 0.4);
      const hair = sp.hair.step(sway * 1.15 - tiltVel * .0035 + hairStride + singK * .25 * beatS, dt);
      const hairY = sp.hairY.step(up * -.85 + lowV * .005 + mK * 0.32 * Math.cos(locoPh * 2 - 0.4) + dragK * 0.35 * Math.cos(t * 13), dt);
      const coat = sp.coat.step(sway * .9 + coatStride + singK * .3 * beatS, dt);
      const flare = sp.coatY.step(up * .75 + sitK * .5 + clamp(-lowV * .008, -.3, .6) + mK * 0.24 * Math.abs(Math.sin(locoPh)) + dragK * 0.30 * Math.abs(dragWave), dt);
      /* arms: shoulder angle (a*), elbow angle (e*), each "outward-positive" (o*) so both arms share the same numbers */
      const oF = Lr.out('shF'), oB = Lr.out('shB');
      let aF = 0, aB = 0, eF = 6, eB = 6, swing = walking ? 1 : 0;
      if (airborne) { aF = 22; aB = 26; eF = 18; eB = 20; }
      if (held) { aF = 40 + 13 * Math.sin(t * 13); aB = 46 + 11 * Math.sin(t * 13 + 1.3); eF = 28 + 8 * Math.cos(t * 13); eB = 32 + 8 * Math.cos(t * 13 + 1.3); }
      if ((face === 'happy' || face === 'love' || face === 'excited') && planeK < 0.01) { aB += 8 + 4 * Math.sin(t * 8); eB += 14; aF += 4; }
      if (face === 'angry') { aF = 6; aB = 10 + 2 * Math.sin(t * 30); eF = 60; eB = 64; swing = 0; }
      if (mode === 'dance') { const bb = Math.sin((o.modeT || 0) * TAU * 1.1); aB = 26 + 24 * Math.max(0, bb); eB = 24 + 26 * Math.max(0, bb); aF = 12 + 16 * Math.max(0, -bb); eF = 18 + 24 * Math.max(0, -bb); }
      if (walkOnlyK > .001) { eF = lerp(eF, 16, walkOnlyK); eB = lerp(eB, 16, walkOnlyK); }
      if (runK > .001) { eF = lerp(eF, 20, runK); eB = lerp(eB, 25, runK); }
      if (wave) { aB = lerp(aB, 44, wave); eB = lerp(eB, 46 + 14 * Math.sin(t * 9.5), wave); }
      if (heartK) { aB = lerp(aB, HA.a, heartK); eB = lerp(eB, HA.e, heartK); aF = lerp(aF, -10, heartK); eF = lerp(eF, 60, heartK); swing = 0; }
      if (wish) { aB = lerp(aB, WA.a, wish); eB = lerp(eB, WA.e * (1 - wishEyes) + WA.e2 * wishEyes, wish); aF = lerp(aF, 10, wish); eF = lerp(eF, 30 + 50 * wishEyes, wish); swing = 0; }
      // During paperplane orbit, keep arms 100% calm and natural in resting idle pose (zero arm waving!)
      if (planeK > 0.01) {
        swing = 0;
      }
      // Live 120Hz Official Gameplay Transformation Choreography (Normal Form):
      // Up: Stage 1 (0..0.22) Hands to Heart Tacet Mark -> Stage 2 (0.22..0.50) Raise right arm skyward & Zero-G ascent!
      if (tfUpK > 0.01) {
        const s1 = smooth(0, .18, tfU) * (1 - smooth(.22, .34, tfU));
        const s2 = smooth(.20, .38, tfU);
        aB = lerp(aB, -10 * s1 + 45 * s2, tfUpK);
        eB = lerp(eB, 56 * s1 + 56 * s2, tfUpK);
        aF = lerp(aF, -12 * s1 + 16 * s2, tfUpK);
        eF = lerp(eF, 58 * s1 + 34 * s2, tfUpK);
        swing = 0;
      }
      // Down: Stage 2..3 (0.48..1.0) Descending in starlight feathers -> soft landing & gentle wave!
      if (tfDnK > 0.01) {
        const sDesc = (1 - smooth(.65, .85, tfU));
        const sWave = smooth(.68, .82, tfU) * (1 - smooth(.92, 1.0, tfU));
        aB = lerp(aB, 34 * sDesc + 42 * sWave, tfDnK);
        eB = lerp(eB, 22 * sDesc + (48 + 12 * Math.sin(t * 10)) * sWave, tfDnK);
        aF = lerp(aF, 26 * sDesc + 8 * sWave, tfDnK);
        eF = lerp(eF, 20 * sDesc + 16 * sWave, tfDnK);
        swing = 0;
      }
      if (singK) { aB = lerp(aB, 16 + 10 * Math.max(0, beatS), singK); eB = lerp(eB, 52 + 10 * Math.max(0, beatS), singK); aF = lerp(aF, 6, singK); eF = lerp(eB, 18, singK); }
      if (sitK > .5 && !walking) { aF = lerp(aF, 4, sitK); aB = lerp(aB, 6, sitK); eF = lerp(eF, 40, sitK); eB = lerp(eB, 44, sitK); }
      swingK = lerp(swingK, swing, ease(8, dt));
      const gait = swingK * (1 - wave) * (.28 + .07 * runK);
      const swF = legA[1] * gait * oF * -1, swB = legA[0] * gait * oB * -1;
      const armF = sp.armF.step(aF, dt), armB = sp.armB.step(aB, dt);
      const eMin = -165 * gHeart;
      const elF = sp.elF.step(clamp(eF, 0, 125), dt), elB = sp.elB.step(clamp(eB, eMin, 125), dt);
      const hover = sitK * (-16 + 2.2 * Math.sin(t * 1.6));
      const locoBob = (walkOnlyK * 1.35 + runK * 2.0) * Math.sin(locoPh * 2);
      const tfLiftN = tfUpK * (-18 * smooth(.18, .48, tfU)) + tfDnK * (-16 * (1 - smooth(.50, .82, tfU)) + 3.5 * Math.sin(clamp((tfU - .78) / .18, 0, 1) * Math.PI));
      st.body = { a: -sway * 1.2 + (held ? clamp(o.swing || 0, -28, 28) * .14 : 0) + singK * 2.2 * beatS - wish * 2, ty: lerp(cleanLow, (1.2 * walkOnlyK + 2.2 * runK) + locoBob, walkK) - 29 * sitK + hover - wish * 3 - heartK * 1.5 * Math.abs(Math.sin(t * 6)) + tfLiftN, sx: 1 + .006 * breath, sy: 1 - .012 * breath };
      // Positive waistLean in rig space leans her upper body forward (+x) during walk, run, nod, and bow
      const waistLean = bow * 13 + nod * 6.0 + walkOnlyK * 2.0 + runK * 3.8;
      st.waist = { a: waistLean };
      st.shF = { a: oF * armF + swF }; st.foreF = { a: oF * elF };
      st.shB = { a: oB * armB + swB }; st.foreB = { a: oB * elB };
      const raise = smooth(45, 75, armB);
      st.z.n_arm_B = 5.1 + 4 * raise;

      // Dynamic wide galaxy sleeves: respond to arm angular velocity, gravity droop when raised, drag waving (t*13), wave/dance, and walk/run!
      const angF = oF * armF + swF + oF * elF, angB = oB * armB + swB + oB * elB;
      const rawVF = (angF - (prevArm.F ?? angF)) / dtSafe, rawVB = (angB - (prevArm.B ?? angB)) / dtSafe;
      prevArm.F = angF; prevArm.B = angB;
      vFSm = lerp(vFSm, clamp(rawVF, -320, 320), ease(14, dt));
      vBSm = lerp(vBSm, clamp(rawVB, -320, 320), ease(14, dt));
      const slvDragF = dragK * (Math.sin(t * 13 - 0.7) * 14.5 + sway * 9.5) + wave * Math.sin(t * 9.5 - 0.6) * 7.5;
      const slvDragB = dragK * (Math.sin(t * 13 + 0.6) * 16.0 + sway * 10.5) + wave * Math.sin(t * 9.5 - 0.5) * 12.0;
      const lagF = sp.slvF.step(clamp(-vFSm * .065, -18, 18) - 4.2 * mK + Math.sin(locoPh - 0.6) * 4.5 * mK + slvDragF, dt);
      const lagB = sp.slvB.step(clamp(-vBSm * .065, -18, 18) - 4.2 * mK - Math.sin(locoPh - 0.6) * 4.5 * mK + slvDragB, dt);
      const mkS = (key, o_, aSh, aEl, lagA) => {
        const sh = PV['sh' + key], el = PV['el' + key], wr = PV['wr' + key];
        const ux = el[0] - sh[0], uy = el[1] - sh[1], L2 = (ux * ux + uy * uy) || 1;
        const wx = wr[0] - el[0], wy = wr[1] - el[1], Lw2 = (wx * wx + wy * wy) || 1;
        // Bend origin sits at the elbow (88% along sh->el, below the pleated cyan cuff) so the cuff stays 100% rigid
        const px = sh[0] + .88 * ux, py = sh[1] + .88 * uy;
        const shTotal = o_ * aSh + (key === 'F' ? swF : swB);
        const phKey = key === 'B' ? 0 : 1.4;
        return (uu, vv, x, y) => {
          const dxC = clamp(x - sh[0], -12, 12);
          const s_u = (dxC * ux + (y - sh[1]) * uy) / L2;
          const s_f = Math.max(0, ((x - el[0]) * wx + (y - el[1]) * wy) / Lw2);
          const s_ = s_u + .85 * s_f;
          // 2) Strict anatomical decoupling between the solid arm/wrist/white-gloved-hand and the outer sleeve streamer:
          //    In n_arm_B and n_arm_F, the shoulder, upper-arm cuff, forearm, cyan wrist bracelet, and white gloved hand
          //    all lie inside `uOut <= 0.24 + 0.48 * vv` (where `wHem === 0.000`, 100% rigid skeletal attachment!).
          //    ONLY the outer starry galaxy sleeve wing and long white-gold streamer (`uOut > 0.24 + 0.48 * vv`) flutter!
          const wE = smooth(.35, 1.50, s_);
          const uOut = key === 'F' ? uu : 1 - uu;
          const uArmBorder = 0.24 + 0.48 * vv;
          const wHem = smooth(0.03, 0.22, uOut - uArmBorder) * smooth(0.22, 0.42, vv);
          const slvWave = (
            Math.sin(locoPh - uOut * 2.6) * 3.8 * mK
            + Math.sin(t * 11 + phKey - uOut * 3.0) * 8.5 * dragK
            + Math.sin(t * 8.5 + phKey - uOut * 2.8) * 5.2 * wave
            + Math.sin(t * 2.0 - uOut * 2.5) * 0.65
          ) * wHem;
          const gravDroopAng = -o_ * aSh * (0.24 * wHem * (dragK + 0.45 * wave + 0.25 * mK));
          const ang = (o_ * aEl * wE + gravDroopAng + lagA * (0.38 * wHem) + slvWave) * Math.PI / 180;
          const c = Math.cos(ang), sn = Math.sin(ang), dx = x - px, dy = y - py;
          const billowX = (
            -1.8 * mK
            + Math.sin(locoPh - uOut * 2.4) * 1.5 * mK
            + Math.sin(t * 11 + phKey - uOut * 2.8) * 4.2 * dragK
            + sway * 2.8 * dragK
            + Math.sin(t * 8.5 + phKey - uOut * 2.6) * 2.4 * wave
          ) * wHem;
          const billowY = (
            Math.cos(locoPh - uOut * 2.2) * 1.0 * mK
            + (3.2 + Math.cos(t * 11 + phKey - uOut * 2.6) * 3.4) * dragK
            + (1.2 + Math.cos(t * 8.5 + phKey - uOut * 2.4) * 2.0) * wave
          ) * wHem;
          const sleeveX = px + dx * c - dy * sn + billowX;
          const sleeveY = py + dx * sn + dy * c + billowY;
          // Move the inner cuff edge with the torso. Convert its torso-space point
          // back through the waist and shoulder so those rotations only affect the outer sleeve.
          const towardBody = key === 'F' ? -1 : 1;
          const inside = towardBody * (x - sh[0]);
          const root = smooth(-4.5, 3.0, inside) * (1 - smooth(.16, .53, s_));
          if (root <= .001) return [sleeveX - x, sleeveY - y];
          const rect = Lr.rectOf('n_body');
          const [tx, ty] = st.bodyWarp.fn(clamp((x - rect[0]) / (rect[2] - rect[0]), 0, 1), 0, x, y);
          const rotate = (valueX, valueY, [ox, oy], deg) => {
            const angle = deg * Math.PI / 180;
            const c = Math.cos(angle), s = Math.sin(angle), dx = valueX - ox, dy = valueY - oy;
            return [ox + c * dx - s * dy, oy + s * dx + c * dy];
          };
          const [waistX, waistY] = rotate(x + tx + towardBody * 1.4, y + ty, PV.waist, -waistLean);
          const [rootX, rootY] = rotate(waistX, waistY, sh, -shTotal);
          return [lerp(sleeveX, rootX, root) - x, lerp(sleeveY, rootY, root) - y];
        };
      };
      st.slvF = { fn: mkS('F', oF, armF, elF, lagF) }; st.slvB = { fn: mkS('B', oB, armB, elB, lagB) };
      /* torso + skirt frills (bodyWarp) and the coat tails (coatWarp): flutter from the waist down, lagging the body,
         while the top of the neck cylinder follows head rotation smoothly */
      {
        const R = Lr.rectOf('n_body'), top = PV.waist[1] + 2, bot = R[3];
        const nkDeg = headA - walkOnlyK * 3.5 - runK * 7.0, nkTy = (mode === 'sleep' ? 2.5 : 0) + breath * .35;
        st.bodyWarp = { fn: (uu, vv, x, y) => {
          // Keep the upper torso and white pleated skirt crisp and structurally solid (no jelly mesh distortion!)
          const v = clamp((y - top) / (bot - top), 0, 1), k = Math.pow(v, 1.6);
          const hemSwayX = (coat * 2.2 + Math.sin(locoPh - 0.5) * 0.8 * mK - 0.7 * mK) * k;
          let X = x + hemSwayX + flare * (uu - .5) * 3.5 * k;
          let Y = y - flare * k * 1.0;
          // 1) Neck & choker region follows headWarp chin parallax + neck rotation & translation 100% together with n_head
          const wN = smooth(PV.neck[1] + 15, PV.neck[1] - 2, y) * Math.exp(-Math.pow((x - PV.neck[0]) / 15.5, 2));
          if (wN > 0.001) {
            X += angleX * 1.35 * wN;
            Y += angleY * 1.40 * wN;
            const aN = (nkDeg * wN) * Math.PI / 180, cN = Math.cos(aN), sN = Math.sin(aN), rx = X - PV.neck[0], ry = Y - PV.neck[1];
            X = PV.neck[0] + rx * cN - ry * sN;
            Y = PV.neck[1] + rx * sN + ry * cN + nkTy * wN;
          }
          // 2) Upper torso above the waist leans forward together with st.waist (on nod, bow, walk, and run)
          const wW = smooth(PV.waist[1] + 12, PV.waist[1] - 18, y);
          if (wW > 0.001) {
            const aW = (waistLean * wW) * Math.PI / 180, cW = Math.cos(aW), sW = Math.sin(aW), wx = X - PV.waist[0], wy = Y - PV.waist[1];
            X = PV.waist[0] + wx * cW - wy * sW;
            Y = PV.waist[1] + wx * sW + wy * cW;
          }
          return [X - x, Y - y];
        } };
        const C = Lr.rectOf('n_coat'), ct = PV.coat[1], cb = C[3];
        st.coatWarp = { fn: (uu, vv, x, y) => {
          const v = clamp((y - ct) / (cb - ct), 0, 1), k = Math.pow(v, 1.45);
          const edge = .70 + .65 * Math.abs(uu - .5);
          const windX = -2.2 * mK * k;
          const waveX = (Math.sin(locoPh - v * 2.2) * 2.2 * mK
            + Math.sin(t * 11 - v * 2.6) * 2.6 * dragK
            + Math.sin(t * 2.2 - v * 2.4) * 0.85) * k * edge;
          const waveY = (-flare * 2.8 - 0.8 * mK * edge
            + Math.cos(locoPh - v * 2.0) * 0.9 * mK
            + Math.cos(t * 2.2 - v * 2.4) * 0.45) * k;
          return [coat * 6.5 * k + flare * (uu - .5) * 9.5 * v + windX + waveX, waveY];
        } };
      }
      /* ribbons: hung under the coat's hem; root (s_ < 0.20) is 100% locked to coatWarp so ribbons NEVER disconnect */
      const ribStride = mK * (-7.0 + 7.2 * Math.sin(locoPh - 0.7) + 3.6 * Math.cos(locoPh * 2 - 1.0)) + dragK * 7.5 * Math.sin(t * 13 - 0.8);
      const ribDrive = sway * 11 + ribStride + tiltVel * .012 + singK * 3 * beatS;
      const rF = sp.ribF.step(clamp(ribDrive, -16, 16), dt), rB = sp.ribB.step(clamp(ribDrive * .92, -16, 16), dt);
      const ribFn = (P, Rk, ang, ph) => {
        const R = Lr.rectOf(Rk), len = (R[3] - P[1]) || 1;
        return (uu, vv, x, y) => {
          const s_ = clamp((y - P[1]) / len, 0, 1);
          const w_rib = smooth(.08, .30, s_) * Math.pow(s_, 0.65);
          if (w_rib <= 1e-4) return [0, 0];
          const waveAng = (Math.sin(locoPh + ph - s_ * 3.2) * 9.2 * mK
            + Math.sin(locoPh * 2 + ph - s_ * 4.8) * 4.6 * mK
            + Math.sin(t * 13 + ph - s_ * 3.6) * 9.0 * dragK
            + Math.sin(t * 2.6 + ph - s_ * 3.8) * 3.6) * w_rib;
          const a_ = (ang * w_rib + waveAng) * Math.PI / 180;
          const c = Math.cos(a_), sn = Math.sin(a_), dx = x - P[0], dy = y - P[1];
          const whipX = (-2.4 * mK + Math.sin(locoPh * 2 + ph - s_ * 4.2) * 2.0 * mK + Math.sin(t * 13 + ph - s_ * 4.0) * 2.6 * dragK) * w_rib * s_;
          const whipY = (-Math.abs(ang) * 0.06 + Math.cos(locoPh * 2 + ph - s_ * 3.8) * 1.2 * mK) * w_rib * s_;
          return [P[0] + dx * c - dy * sn - x + whipX, P[1] + dx * sn + dy * c - y + whipY];
        };
      };
      st.ribF = { fn: ribFn(PV.ribF, 'n_rib_F', rF, 0) }; st.ribB = { fn: ribFn(PV.ribB, 'n_rib_B', rB, 1.7) };
      /* legs: each a whole leg hinged at the hip */
      const legSit = sitK;
      const legPose = (i, sitA) => {
        const L = Math.max(0, lift[i]) * (1 - legSit), bend = clamp(L * 1.35, 0, 14);
        return { a: lerp(legA[i], sitA, legSit) - bend * .25, b: bend, ty: -Math.max(0, lift[i]) * .10 * (1 - legSit) + Math.min(0, lift[i]) * .18 };
      };
      st.legB = { fn: kneeHinge(PV.hipB, legPose(0, -14)) };
      st.legF = { fn: kneeHinge(PV.hipF, legPose(1, -26)) };
      st.neck = { a: headA - walkOnlyK * 3.5 - runK * 7.0, ty: (mode === 'sleep' ? 2.5 : 0) + breath * .35 };
      /* head turn (parallax) + the two side locks swinging and rippling with wind waves during walk, run & drag */
      const lkL = sp.lockL.step(-sway * 6 - tiltVel * .025 - 5.0 * mK + Math.sin(locoPh - 0.4) * 5.5 * mK + Math.sin(t * 13 - 0.5) * 6.5 * dragK + Math.sin(t * 1.5) * 1.2, dt);
      const lkR = sp.lockR.step(-sway * 5 - tiltVel * .02 - 4.2 * mK + Math.sin(locoPh + 0.8) * 4.8 * mK + Math.sin(t * 13 + 0.7) * 6.0 * dragK - Math.max(0, headA) * .65 + Math.sin(t * 1.35 + 1) * 1.0, dt);
      const HR = Lr.rectOf('n_head'), lockFn = (P, ang, ph, x, y) => {
        const dy = y - P[1]; if (dy <= 0) return [0, 0];
        const sL = clamp(dy / 42, 0, 1.25);
        const w = smooth(0, 1, dy / 24) * Math.exp(-Math.pow((x - P[0]) / 24, 2));
        const waveA = (Math.sin(locoPh + ph - sL * 1.8) * 3.6 * mK
          + Math.sin(t * 11 + ph - sL * 2.2) * 4.5 * dragK
          + Math.sin(t * 2.0 + ph - sL * 2.0) * 1.0) * sL;
        const a_ = (ang + waveA) * Math.PI / 180 * w * Math.min(1, dy / 34), c = Math.cos(a_), sn = Math.sin(a_), dx = x - P[0];
        const dxWind = -1.2 * mK * w * sL;
        const dyWind = -0.4 * mK * w * sL;
        return [P[0] + dx * c - dy * sn - x + dxWind, P[1] + dx * sn + dy * c - y + dyWind];
      };
      const headParallax = (x, y) => {
        const uH = clamp((x - HR[0]) / (HR[2] - HR[0]), 0, 1), vH = clamp((y - HR[1]) / (HR[3] - HR[1]), 0, 1);
        return [angleX * 2.6 * bump(uH) * (.4 + .6 * bump(vH)), angleY * 1.8 * bump(vH) * (.4 + .6 * bump(uH))];
      };
      st.headWarp = { fn: (uu, vv, x, y) => {
        const p = headParallax(x, y);
        const a = lockFn(PV.lockL, lkL, 0, x, y), b = lockFn(PV.lockR, lkR, 1.4, x, y);
        return [p[0] + a[0] + b[0], p[1] + a[1] + b[1]];
      } };
      /* ponytail (n_hair_back):
       * Because hairSway's parent is 'neck', n_hair_back ALREADY rotates and translates 100% identically to n_head!
       * In the head/crown/nape connection region (y <= 106), we apply the exact same headParallax(x, y) as st.headWarp
       * and keep wFree === 0.0 so front hair, face, and back hair are 100% rigidly locked in all motions! */
      const nk = PV.neck, na = headA * Math.PI / 180, hr = PV.hair, HB = Lr.rectOf('n_hair_back');
      st.hairSway = {
        fn: (uu, v, x, y) => {
          const hp = headParallax(x, y);
          const wHead = 1 - smooth(96, 138, y);
          const hPx = hp[0] * wHead, hPy = hp[1] * wHead;

          // Detachment weight wFree: strictly 0.0 throughout the head-crown connection zone (y <= 94 and inside head box)
          const wFree = smooth(94, 132, y) * smooth(.28, .62, v);
          if (wFree <= 1e-4) return [hPx, hPy];

          const a = -na * .48 * wFree, c = Math.cos(a), s = Math.sin(a), dx = x - nk[0], dy = y - nk[1];
          const d = clamp(Math.hypot(x - hr[0], y - hr[1]) / Math.hypot(HB[2] - hr[0], HB[3] - hr[1]), 0, 1.2);
          const wv = wFree * Math.pow(d, 1.15);
          const travX = (Math.sin(locoPh - d * 3.4) * 4.5 * mK
            + Math.sin(locoPh * 2 - d * 5.0 + uu * 2.2) * 2.8 * mK
            + Math.sin(t * 13 - d * 4.0 + uu * 2.0) * 5.2 * dragK
            + Math.sin(t * 2.1 - d * 4.4) * 2.4) * wv;
          const travY = (Math.cos(locoPh * 2 - d * 3.8) * 2.2 * mK
            + Math.cos(t * 13 - d * 4.0) * 2.8 * dragK
            + Math.cos(t * 2.1 - d * 4.4) * 1.0) * wv;
          const windLift = (-2.5 * mK - 1.8 * dragK) * wv;
          return [hPx + nk[0] + dx * c - dy * s - x + (hair * 10.5 - 3.6 * mK) * wv + travX,
            hPy + nk[1] + dx * s + dy * c - y + hairY * 8.5 * wv * wv + windLift - Math.abs(hair) * 1.5 * wv + travY];
        },
      };
      paintFace(face, o, sg);
      rig.upload('n_faceFx', faceCv);
    } else {
      const Lr = LAY.q, PV = Lr.PV;
      // she hovers: a slow bob, a lean into the glide, wings beating softly (harder in the air or when happy)
      const hov = sp.hover.step(-6 - 4 * walkK - (held ? 0 : 0) + sitK * 10 - wish * 20, dt);
      const beatRate = airborne || held ? 9 : walking ? 5 : 2.2 + singK * 1.2, beatAmp = airborne || held ? 9 : walking ? 5 : 2.5 + singK * 2;
      const flap = Math.sin(t * beatRate) * beatAmp;
      const happy = face === 'happy' || face === 'love' || face === 'excited';
      let wf = flap + (happy ? -4 : 0) - sitK * 10 + (face === 'sad' || face === 'cry' ? 8 : 0);
      if (mode === 'sleep') wf = 12 + Math.sin(t * 1.2);
      wf = wf - wish * 15 - heartK * 5;
      const wingF = sp.wingF.step(wf, dt), wingB = sp.wingB.step(-wf * .8, dt);
      // arms (outward-positive): L is the near arm (drawn over the body), it waves; elbows on rigid cutout hinges
      const oL = Lr.out('shL'), oR = Lr.out('shR');
      let aL = 4, aR = 3, eL = 8, eR = 8;
      if (held) { aL = 34 + 10 * Math.sin(t * 12); aR = 30 + 8 * Math.sin(t * 12 + 1); eL = 30; eR = 28; }
      if (airborne) { aL = 18; aR = 16; eL = 22; eR = 20; }
      if (happy && planeK < 0.01) { aL += 8; eL += 14; aR += 5; }
      if (wave) { aL = lerp(aL, 48, wave); eL = lerp(eL, 52 + 14 * Math.sin(t * 9.5), wave); }
      if (heartK) { aL = lerp(aL, HA.qa, heartK); eL = lerp(eL, HA.qe, heartK); aR = lerp(aR, 14, heartK); eR = lerp(eR, 30, heartK); }
      if (wish) { aL = lerp(aL, WA.qa, wish); eL = lerp(eL, WA.qe, wish); aR = lerp(aR, 18, wish); eR = lerp(eR, 24, wish); }
      // During paperplane orbit, keep Mech arms 100% calm in resting pose!
      if (singK) { aL = lerp(aL, 18 + 10 * Math.max(0, beatS), singK); eL = lerp(eL, 46 + 10 * Math.max(0, beatS), singK); aR = lerp(aR, 8, singK); eR = lerp(eR, 20, singK); }
      // Live 120Hz Official Gameplay Transformation Choreography (Mech Form):
      // Up (0.48..1.0): Quantum armor assembly -> 4 Floating Wings unfurl (-32 deg -> +24 deg) -> Savior Rises heroic arm sweep!
      if (tfUpK > 0.01) {
        const sBurst = smooth(.45, .68, tfU) * (1 - smooth(.82, .96, tfU));
        aL = lerp(aL, 56 * sBurst, tfUpK); eL = lerp(eL, 28 * sBurst, tfUpK);
        aR = lerp(aR, 52 * sBurst, tfUpK); eR = lerp(eR, 26 * sBurst, tfUpK);
      }
      // Down (0.0..0.52): 4 Floating Wings fold inward around core while arms cross gently at chest!
      if (tfDnK > 0.01) {
        const sFold = smooth(.05, .42, tfU);
        aL = lerp(aL, -14 * sFold, tfDnK); eL = lerp(eL, 48 * sFold, tfDnK);
        aR = lerp(aR, -10 * sFold, tfDnK); eR = lerp(eR, 44 * sFold, tfDnK);
      }
      const armL = sp.armB.step(aL, dt), armR = sp.armF.step(aR, dt);
      const elL = sp.elB.step(clamp(eL, -45, 95), dt), elR = sp.elF.step(clamp(eR, 0, 95), dt);
      const legs = sp.legs.step(walkK * .8 + runK * .6 + up * .5 + tfUpK * 0.65 * smooth(.45, .75, tfU), dt);
      const tfLiftQ = tfUpK * (-16 * (1 - smooth(.72, .96, tfU))) + tfDnK * (-14 * smooth(.10, .48, tfU));
      st.body = { a: -sway * 1.6 + (held ? o.swing * .12 : 0) + singK * 1.6 * beatS, ty: low * .3 + hov + Math.sin(t * 1.9) * 3.2 + breath * .4 + tfLiftQ, sx: 1, sy: 1 };
      const qWaistLean = bow * 14 + nod * 6.0 + runK * 6;
      st.waist = { a: qWaistLean };
      st.neckHead = { a: (headA + nod * 4) * .72, tx: bow * 2.5 + nod * 1.2, ty: bow * 4.5 + nod * 2.0 };
      // 4 independent detached floating wings: hover with phase-staggered oscillation, plus dramatic unfurl/fold during transformation!
      const hovUp = Math.sin(t * 2.4) * 2.2, hovLow = Math.sin(t * 2.4 - 1.1) * 2.6;
      const tfWingUnfurl = tfUpK * lerp(28, -18, smooth(.46, .74, tfU)) * (1 - smooth(.84, .98, tfU)) + tfDnK * (26 * smooth(.08, .46, tfU));
      st.wingLUp  = { a: wingF * .85 + tfWingUnfurl, tx: 1.2 * Math.sin(t * 1.8), ty: hovUp };
      st.wingLLow = { a: wingF * .65 + 2 * Math.sin(t * beatRate - .8) + tfWingUnfurl * 0.85, tx: 1.5 * Math.sin(t * 1.8 - .9), ty: hovLow };
      st.wingRUp  = { a: wingB * .85 - tfWingUnfurl, tx: -1.2 * Math.sin(t * 1.8), ty: hovUp };
      st.wingRLow = { a: wingB * .65 - 2 * Math.sin(t * beatRate - .8) - tfWingUnfurl * 0.85, tx: -1.5 * Math.sin(t * 1.8 - .9), ty: hovLow };
      const flex = (dir, ph = 0) => (uu, vv, x, y) => {
        const d = dir > 0 ? uu : 1 - uu;
        return [Math.sin(t * beatRate - 1.6 * d - .4 + ph) * beatAmp * .07 * d * d * dir, dir * Math.sin(t * beatRate - .9 - 1.4 * d + ph) * beatAmp * .16 * d * vv];
      };
      st.wingLUpFlex  = { fn: flex(1, 0) };
      st.wingLLowFlex = { fn: flex(1, -.7) };
      st.wingRUpFlex  = { fn: flex(-1, 0) };
      st.wingRLowFlex = { fn: flex(-1, -.7) };
      st.shL = { a: oL * armL }; st.foreL = { a: oL * elL };
      st.shR = { a: oR * armR }; st.foreR = { a: oR * elR };
      // True ball-and-socket whole mech arm skinning: spherical shoulder ball rotates inside q_body_top's concave arch, forearm bends smoothly at elbow!
      const mkQArm = (key, o_, aSh, aEl) => {
        const sh = PV['sh' + key], el = PV['el' + key], wr = PV['wr' + key];
        const ux = el[0] - sh[0], uy = el[1] - sh[1], L2 = (ux * ux + uy * uy) || 1;
        const wx = wr[0] - el[0], wy = wr[1] - el[1], Lw2 = (wx * wx + wy * wy) || 1;
        const px = sh[0] + .85 * ux, py = sh[1] + .85 * uy;
        return (uu, vv, x, y) => {
          const dxC = clamp(x - sh[0], -14, 14);
          const s_u = (dxC * ux + (y - sh[1]) * uy) / L2;
          const s_f = Math.max(0, ((x - el[0]) * wx + (y - el[1]) * wy) / Lw2);
          const s_ = s_u + .75 * s_f;
          const wRoot = 1 - smooth(-.05, .36, s_);
          let X = x, Y = y;
          if (wRoot > 0.001) {
            const aR = -(o_ * aSh) * .62 * wRoot * Math.PI / 180;
            const cR = Math.cos(aR), sR = Math.sin(aR), rx = X - sh[0], ry = Y - sh[1];
            X = sh[0] + rx * cR - ry * sR;
            Y = sh[1] + rx * sR + ry * cR;
          }
          const wE = smooth(.55, 1.35, s_);
          const ang = (o_ * aEl * wE) * Math.PI / 180;
          const c = Math.cos(ang), sn = Math.sin(ang), dx = X - px, dy = Y - py;
          return [px + dx * c - dy * sn - x, py + dx * sn + dy * c - y];
        };
      };
      st.armL = { fn: mkQArm('L', oL, armL, elL) };
      st.armR = { fn: mkQArm('R', oR, armR, elR) };
      st.z.q_arm_L = 2.6;      {
        const hy = PV.hips[1], bot = Lr.rectOf('q_body')[3];
        st.bodyWarp = { fn: (uu, vv, x, y) => {
          const k = smooth(hy, bot, y);
          let X = x - legs * 10 * k * k + Math.sin(t * 1.5) * 1.2 * k, Y = y - legs * 3 * k;
          // Dorsal collar fins tilt gently with the raised arms like articulated spring-loaded shoulder guards
          const wFinR = smooth(112, 92, x) * smooth(112, 86, y);
          if (wFinR > 0.001) {
            const aFR = (oR * armR * 0.22 * wFinR) * Math.PI / 180, cFR = Math.cos(aFR), sFR = Math.sin(aFR), dxR = X - 112, dyR = Y - 98;
            X = 112 + dxR * cFR - dyR * sFR; Y = 98 + dxR * sFR + dyR * cFR;
          }
          const wFinL = smooth(130, 144, x) * smooth(114, 92, y);
          if (wFinL > 0.001) {
            const aFL = (oL * armL * 0.18 * wFinL) * Math.PI / 180, cFL = Math.cos(aFL), sFL = Math.sin(aFL), dxL = X - 130, dyL = Y - 100;
            X = 130 + dxL * cFL - dyL * sFL; Y = 100 + dxL * sFL + dyL * cFL;
          }
          const wN = smooth(PV.neck[1] + 14, PV.neck[1] - 2, y);
          if (wN > 0.001) {
            const aN = ((headA + nod * 4) * .72 * wN) * Math.PI / 180, cN = Math.cos(aN), sN = Math.sin(aN), rx = X - PV.neck[0], ry = Y - PV.neck[1];
            X = PV.neck[0] + rx * cN - ry * sN + (bow * 2.5 + nod * 1.2) * facing * wN;
            Y = PV.neck[1] + rx * sN + ry * cN + (bow * 4.5 + nod * 2.0) * wN;
          }
          const wW = smooth(PV.waist[1] + 12, PV.waist[1] - 18, y);
          if (wW > 0.001) {
            const aW = (qWaistLean * wW) * Math.PI / 180, cW = Math.cos(aW), sW = Math.sin(aW), wx = X - PV.waist[0], wy = Y - PV.waist[1];
            X = PV.waist[0] + wx * cW - wy * sW;
            Y = PV.waist[1] + wx * sW + wy * cW;
          }
          return [X - x, Y - y];
        } };
      }
      visorLit = lerp(visorLit, mode === 'sleep' ? .35 : 1, ease(3, dt));
      paintVisor(face, o, t, sg); rig.upload('q_visorFx', visorCv);
      paintCore(face, t, sg, heartK * (.7 + .3 * Math.sin(t * 9))); rig.upload('q_coreFx', coreCv);
    }
    rig.render(st);
    if (opts.raster) { fo.setAttribute('href', canvas.toDataURL('image/png')); decoded = fo.decode ? fo.decode().catch(() => {}) : null; }
    drawFx(t, sg);
  }

  /* ---------- effects drawn over the figure (SVG): heart cushion, music notes, lyrics ---------- */
  const NOTE = ['M0 -14V4A5 4 0 1 1 -3 0.5V-14Z', 'M-6 -14L8 -17V2A5 4 0 1 1 5 -1.5V-10L-3 -8V5A5 4 0 1 1 -6 1.5Z'];
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
  function drawFx(t, sg) {
    let s = '', sb = '';
    const P = FORMS[form].pivots;
    const pt = (dn, x, y) => rig.point(dn, st, x, y);
    // normal form: sitting, she floats on a soft glowing heart of light
    if (form === 'n' && sitK > .02) {
      const c = pt('body', 128, 196), k = sitK, br = .7 + .3 * Math.sin(t * 2.2), sc = .9 * (.6 + .4 * k);
      sb += `<g opacity="${f1(k)}" transform="translate(${f1(c[0])} ${f1(c[1] + 6)}) scale(${f1(sc * 2.4)} ${f1(sc * 1.15)})">`
        + `<path d="M0 14C-7 8 -19 1 -19 -6C-19 -15 -8 -18 0 -9C8 -18 19 -15 19 -6C19 1 7 8 0 14Z" fill="#ff9fcf" fill-opacity="${f1(.35 * br)}" stroke="#fff0fa" stroke-width="1.1" stroke-opacity="${f1(.9 * br)}"/></g>`;
      for (let i = 0; i < 5; i++) {
        const p = (t * .4 + i / 5) % 1, x = c[0] - 40 + 80 * ((i * .37) % 1), y = c[1] + 8 - 30 * p;
        s += `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(1.4 + (i % 2))}" fill="#ffd6ec" opacity="${f1(k * Math.sin(Math.PI * p))}"/>`;
      }
    }
    if (sg) {
      // notes float up from her as she sings
      const m0 = form === 'n' ? pt('neck', 150, 98) : pt('neckHead', 150, 86);
      for (let i = 0; i < 5; i++) {
        const p = (sg.u * .32 + i / 5) % 1, side = i % 2 ? 1 : -1;
        const x = m0[0] + 16 + side * 8 + 22 * p + 6 * Math.sin(p * 9 + i), y = m0[1] - 6 - 70 * p, a = Math.sin(Math.PI * p) * (.4 + .6 * sg.m + .2);
        s += `<path d="${NOTE[i % 2]}" fill="${i % 3 ? '#ff8fc4' : '#7fe7ff'}" stroke="#fff" stroke-width="1.2" opacity="${f1(clamp(a, 0, 1))}" transform="translate(${f1(x)} ${f1(y)}) scale(${f1(.7 + .3 * p)}) rotate(${f1(10 * Math.sin(p * 6 + i))})"/>`;
      }
      // the Aemeath voice line / lyric being spoken or sung, over her head (Chinese primary, English secondary)
      const L = sg.line;
      if (L) {
        const a = smooth(L.t - .15, L.t + .25, sg.u) * (1 - smooth(L.end, L.end + .3, sg.u)), top = form === 'n' ? pt('body', 128, 10) : pt('body', 128, 6);
        const S0 = Math.max(.2, host?.bounds?.().S || .42), fs1 = f1(Math.max(13, 14.5 / S0)), fs2 = f1(Math.max(10, 11.2 / S0));
        const unflip = facing < 0 ? ` transform="translate(${f1(2 * top[0])} 0) scale(-1 1)"` : '';
        s += `<g opacity="${f1(a)}"${unflip} text-anchor="middle" font-family="'Noto Sans SC','Microsoft YaHei','PingFang SC',sans-serif">`
          + `<text x="${f1(top[0])}" y="${f1(top[1] - 6 - fs2 * 1.15)}" font-size="${fs1}" font-weight="700" fill="#fff" stroke="#c0507f" stroke-width="${f1(fs1 * .22)}" paint-order="stroke" stroke-linejoin="round">${esc(L.zh || L.en)}</text>`
          + (L.zh && L.en ? `<text x="${f1(top[0])}" y="${f1(top[1] - 3)}" font-size="${fs2}" fill="#ffeef8" stroke="#6c4f9f" stroke-width="${f1(fs2 * .24)}" paint-order="stroke" stroke-linejoin="round">${esc(L.en)}</text>` : '')
          + '</g>';
      }
    } else if (speechOn && idleLineState) {
      const uIdle = t - idleLineState.t0, dIdle = idleLineState.dur;
      const aIdle = smooth(0, 0.22, uIdle) * (1 - smooth(dIdle - 0.30, dIdle, uIdle));
      if (aIdle > 0.02) {
        const L = idleLineState.line, top = form === 'n' ? pt('body', 128, 12) : pt('body', 128, 8);
        const S0 = Math.max(.25, host?.bounds?.().S || .42), fs1 = f1(clamp(11.0 / S0, 12, 22));
        const bw = f1(Math.max(88, (L.zh.length + 1.8) * fs1 * 0.96)), bh = f1(fs1 * 2.05);
        const bx = f1(top[0] - bw / 2), by = f1(top[1] - bh - 10);
        const bFill = form === 'q' ? 'rgba(20,38,46,0.92)' : 'rgba(255,255,255,0.95)';
        const bStroke = form === 'q' ? '#5FD8F2' : '#FF7FB8';
        const bText = form === 'q' ? '#e2fbff' : '#4a2340';
        const unflip = facing < 0 ? ` transform="translate(${f1(2 * top[0])} 0) scale(-1 1)"` : '';
        s += `<g opacity="${f1(aIdle * 0.98)}"${unflip} text-anchor="middle" font-family="'Noto Sans SC','Microsoft YaHei','PingFang SC',sans-serif">`
          + `<rect x="${bx}" y="${by}" width="${bw}" height="${bh}" rx="${f1(bh * 0.46)}" fill="${bFill}" stroke="${bStroke}" stroke-width="2.2"/>`
          + `<path d="M${f1(top[0] - 5)},${f1(by + bh - 1)} L${f1(top[0])},${f1(by + bh + 6)} L${f1(top[0] + 5)},${f1(by + bh - 1)} Z" fill="${bFill}" stroke="${bStroke}" stroke-width="1.8" stroke-linejoin="round"/>`
          + `<text x="${f1(top[0])}" y="${f1(by + bh * 0.67)}" font-size="${fs1}" font-weight="700" fill="${bText}">${esc(L.zh)}</text>`
          + '</g>';
      }
    }
    // 比心: a heart of light swells at her heart and floats up, small hearts trailing it
    if (gKind === 'heart' && gProg > .12) {
      const h0 = form === 'n' ? pt('waist', ...P.heart) : pt('bodyWarp', ...P.heart);
      const u = clamp((gProg - .12) / .88, 0, 1), rise = smooth(.18, 1, u), a = smooth(0, .12, u) * (1 - smooth(.78, 1, u));
      const [fc1, fc2] = form === 'n' ? ['#ff9fcf', '#ffe3f2'] : ['#7fe7ff', '#e6fbff'];
      const sc = (.3 + .6 * smooth(0, .3, u)) * (1 + .06 * Math.sin(t * 12) * (1 - rise));
      const HP = 'M0 14C-7 8 -19 1 -19 -6C-19 -15 -8 -18 0 -9C8 -18 19 -15 19 -6C19 1 7 8 0 14Z';
      const hx = h0[0] + facing * 70 * rise + 5 * Math.sin(u * 5), hy = h0[1] - 6 - 96 * rise;
      sb += `<path d="${HP}" transform="translate(${f1(hx)} ${f1(hy)}) scale(${f1(sc * 1.7)})" fill="${fc1}" fill-opacity="${f1(.18 * a)}" stroke="none"/>`;
      s += `<path d="${HP}" transform="translate(${f1(hx)} ${f1(hy)}) scale(${f1(sc)})" fill="${fc1}" fill-opacity="${f1(.55 * a)}" stroke="${fc2}" stroke-width="1.6" stroke-opacity="${f1(a)}"/>`;
      s += `<circle cx="${f1(hx - 7 * sc)}" cy="${f1(hy - 6 * sc)}" r="${f1(2.6 * sc)}" fill="#fff" opacity="${f1(.85 * a)}"/>`;
      for (let i = 0; i < 6; i++) {
        const q = clamp(u * 1.4 - i * .09, 0, 1); if (q <= 0 || q >= 1) continue;
        const side = i % 2 ? 1 : -1, x = h0[0] + facing * 46 * q + side * (14 + 9 * (i % 3)) + 8 * Math.sin(q * 7 + i), y = h0[1] - 10 - 74 * q, aa = Math.sin(Math.PI * q) * a;
        s += `<path d="${HP}" transform="translate(${f1(x)} ${f1(y)}) scale(${f1(.28 + .12 * (i % 2))}) rotate(${f1(side * 14)})" fill="${i % 3 ? fc1 : '#fff'}" stroke="${fc2}" stroke-width="2" opacity="${f1(aa)}"/>`;
      }
    }
    // 许愿: a shooting star leaves her raised fingertip, arcs over her head and away, shedding sparks
    if (gKind === 'starwish' && gProg > .2) {
      const tip = form === 'n' ? pt('foreB', ...P.wrB) : pt('foreL', ...P.wrL);
      const u = clamp((gProg - .2) / .6, 0, 1), e = 1 - (1 - u) ** 2, a = smooth(0, .06, u) * (1 - smooth(.85, 1, u));
      const dir = facing;           // from her raised hand up over her head and away in front of her
      const path = v => [tip[0] + dir * (230 * v), tip[1] - 20 - 95 * Math.sin(Math.PI * Math.min(1, v * .8)) + 30 * v * v];
      const [sx, sy] = path(e);
      const STAR = 'M0 -9L2.2 -2.2L9 0L2.2 2.2L0 9L-2.2 2.2L-9 0L-2.2 -2.2Z';
      // the tail: a fading string of glow behind the head
      for (let i = 1; i <= 14; i++) {
        const v = Math.max(0, e - i * .022), [x, y] = path(v), k = (1 - i / 15) * a;
        s += `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(3.4 * (1 - i / 16) + .6)}" fill="${i % 3 ? '#fff4c8' : '#bff3ff'}" opacity="${f1(.75 * k)}"/>`;
      }
      sb += `<circle cx="${f1(sx)}" cy="${f1(sy)}" r="16" fill="#fff0b0" opacity="${f1(.22 * a)}"/>`;
      s += `<path d="${STAR}" transform="translate(${f1(sx)} ${f1(sy)}) rotate(${f1(t * 240)}) scale(1.25)" fill="#fff7d0" stroke="#ffd37a" stroke-width="1" opacity="${f1(a)}"/>`;
      // sparks it drops, falling slowly and twinkling out
      for (let i = 0; i < 9; i++) {
        const v0 = i / 9 * .95; if (e < v0) continue;
        const age = (e - v0) / .5; if (age > 1) continue;
        const [x, y] = path(v0), k = Math.sin(Math.PI * age) * (.6 + .4 * Math.sin(t * 14 + i)) * a;
        s += `<path d="${STAR}" transform="translate(${f1(x + 4 * Math.sin(i * 2.3))} ${f1(y + 26 * age)}) scale(${f1(.35 + .15 * (i % 3))})" fill="${i % 2 ? '#ffe9a6' : '#ffc3e3'}" opacity="${f1(k)}"/>`;
      }
      // a soft sparkle at the fingertip as it leaves
      const ka = smooth(0, .05, u) * (1 - smooth(.08, .3, u));
      if (ka > .01) s += `<path d="${STAR}" transform="translate(${f1(tip[0])} ${f1(tip[1])}) scale(${f1(1.2 + ka)})" fill="#fff" opacity="${f1(ka)}"/>`;
    }
    // 纸飞机环绕追视 (paperplane): paper plane materializes in starlight, flies a complete 360° 3D orbit around Aemeath
    // (front -> right side -> behind her back/hair with depth occlusion -> left side -> front) and dissolves into starlight!
    if (gKind === 'paperplane' && gProg > .01 && gProg < .99) {
      const c0 = form === 'n' ? pt('waist', 128, 114) : pt('bodyWarp', 128, 110);
      const STAR = 'M0 -7L1.8 -1.8L7 0L1.8 1.8L0 7L-1.8 1.8L-7 0L-1.8 -1.8Z';
      const uOrb = smooth(.03, .97, gProg);
      const aOrb = smooth(.01, .11, gProg) * (1 - smooth(.88, .99, gProg));
      const orbitAt = u => {
        const th = u * TAU;
        const rx = 74, ry = 18;
        const x = c0[0] + Math.sin(th) * rx;
        const y = c0[1] + Math.cos(th) * ry - Math.sin(th * 2) * 7;
        const z = Math.cos(th); // +1 in front of her, -1 behind her back!
        return [x, y, z, th];
      };
      const [px, py, pz, thNow] = orbitAt(uOrb);
      const [pxPrev, pyPrev] = orbitAt(Math.max(0, uOrb - 0.018));
      const vx = px - pxPrev, vy = py - pyPrev;
      const heading = Math.atan2(vy, vx || 0.01) * 180 / Math.PI;
      const sc = (0.90 + 0.26 * pz) * (0.4 + 0.6 * aOrb);

      // Draw depth-sorted 3D ribbon trail (segments with z >= 0 in foreground `s`, segments with z < 0 in background `sb` behind character!)
      for (let i = 16; i >= 1; i--) {
        const u0 = Math.max(0, uOrb - i * 0.016);
        const u1 = Math.max(0, uOrb - (i - 1) * 0.016);
        if (u1 <= 0.002) continue;
        const [x0, y0, z0] = orbitAt(u0);
        const [x1, y1, z1] = orbitAt(u1);
        const segK = (1 - i / 17) * aOrb;
        const segW = f1((1.2 + 2.2 * (1 - i / 17)) * (0.85 + 0.2 * z1));
        const segSvg = `<line x1="${f1(x0)}" y1="${f1(y0)}" x2="${f1(x1)}" y2="${f1(y1)}" stroke="${i % 2 ? '#ff9ed2' : '#8ef2ff'}" stroke-width="${segW}" stroke-linecap="round" opacity="${f1(0.75 * segK)}"/>`;
        if (z1 >= 0) s += segSvg; else sb += segSvg;
        if (i % 2 === 0) {
          const moteSvg = `<path d="${STAR}" transform="translate(${f1(x0 + 3 * Math.sin(i * 2.3))} ${f1(y0 + 3 * Math.cos(i * 1.9))}) scale(${f1((0.32 + 0.14 * (i % 3)) * (0.85 + 0.2 * z0))})" fill="${i % 4 === 0 ? '#fff4b8' : '#ffb8e2'}" opacity="${f1(0.85 * segK)}"/>`;
          if (z0 >= 0) s += moteSvg; else sb += moteSvg;
        }
      }

      // Spawn / dissolve starlight burst rings at the start (gProg < 0.14) and end (gProg > 0.86) of the 360° orbit
      const burstK = Math.max(smooth(0, .06, gProg) * (1 - smooth(.06, .16, gProg)), smooth(.84, .92, gProg) * (1 - smooth(.92, .99, gProg)));
      if (burstK > 0.02) {
        for (let i = 0; i < 6; i++) {
          const ang = i * TAU / 6 + t * 3.5, br = (6 + 16 * (1 - burstK));
          const bx = px + Math.cos(ang) * br, by = py + Math.sin(ang) * br * 0.7;
          s += `<path d="${STAR}" transform="translate(${f1(bx)} ${f1(by)}) scale(${f1(0.55 * burstK)})" fill="${i % 2 ? '#9ff6ff' : '#ffb8e2'}" opacity="${f1(burstK)}"/>`;
        }
      }

      // The 3D Origami Paper Plane (rendered in front `s` when pz >= 0, or behind her back `sb` when pz < 0!)
      const bankY = 0.82 + 0.18 * Math.abs(pz);
      const planeSvg = `<circle cx="${f1(px)}" cy="${f1(py)}" r="${f1(15 * sc)}" fill="#ff9ed2" opacity="${f1(0.28 * aOrb)}"/>`
        + `<g opacity="${f1(aOrb)}" transform="translate(${f1(px)} ${f1(py)}) rotate(${f1(heading)}) scale(${f1(sc)} ${f1(sc * bankY)})">`
        + `<polygon points="18,0 -13,-11 -7,-2" fill="#ffffff" stroke="#d95b96" stroke-width="1.25" stroke-linejoin="round"/>`
        + `<polygon points="18,0 -7,-2 -10,6" fill="#ffc2e2" stroke="#c0437e" stroke-width="1.15" stroke-linejoin="round"/>`
        + `<polygon points="18,0 -4,1 -14,10" fill="#fff5fa" stroke="#d95b96" stroke-width="1.25" stroke-linejoin="round"/>`
        + `<line x1="-6" y1="-1" x2="13" y2="0" stroke="#6be8ff" stroke-width="1.5" stroke-linecap="round"/>`
        + `</g>`;
      if (pz >= 0) s += planeSvg; else sb += planeSvg;

      // Official Wuthering Waves Aemeath paper plane voice line overhead
      const aSub = smooth(.05, .16, gProg) * (1 - smooth(.86, .97, gProg));
      const top = form === 'n' ? pt('body', 128, 10) : pt('body', 128, 6);
      const S0 = Math.max(.2, host?.bounds?.().S || .42), fs1 = f1(Math.max(12.5, 13.8 / S0));
      const unflip = facing < 0 ? ` transform="translate(${f1(2 * top[0])} 0) scale(-1 1)"` : '';
      const txt = '看！折好的纸飞机，乘着风环绕一周飞向星空啦～';
      s += `<g opacity="${f1(aSub)}"${unflip} text-anchor="middle" font-family="'Noto Sans SC','Microsoft YaHei','PingFang SC',sans-serif">`
        + `<text x="${f1(top[0])}" y="${f1(top[1] - 8)}" font-size="${fs1}" font-weight="700" fill="#fff" stroke="#c0507f" stroke-width="${f1(fs1 * .22)}" paint-order="stroke" stroke-linejoin="round">${esc(txt)}</text>`
        + `</g>`;
    }
    // mech: a faint glow ring under her while she hovers
    if (form === 'q') {
      const c = pt('body', 128, 252), k = .45 + .15 * Math.sin(t * 1.9);
      sb += `<ellipse cx="${f1(c[0])}" cy="${f1(c[1] + 4)}" rx="34" ry="6" fill="none" stroke="#9ff3ff" stroke-width="1.5" opacity="${f1(k)}"/>`
        + `<ellipse cx="${f1(c[0])}" cy="${f1(c[1] + 4)}" rx="40" ry="8" fill="none" stroke="#9ff3ff" stroke-width="5" opacity="${f1(k * .25)}"/>`;
    }
    if (s !== fx) { fxG.innerHTML = s; fx = s; }
    if (sb !== fxb) { fxBack.innerHTML = sb; fxb = sb; }
  }

  function reset(keepTf) {
    for (const k in sp) { sp[k].x = 0; sp[k].v = 0; }
    lastT = null; prevTilt = 0; prevLow = 0; headTilt = 0; wTilt = 0; wLean = 0; sitK = 0; walkK = 0; runK = 0; dragK = 0; swingK = 0; swaySm = 0; tiltVelSm = 0; lowVSm = 0; vFSm = 0; vBSm = 0;
    if (!keepTf) { stopSing(); }
  }
  function setScheme(id, o = {}) {
    const next = pickOf(id, o);
    if (next.form !== form) setForm(next.form);
    if (next && next.speech !== undefined) {
      speechOn = next.speech !== 'off';
      try { localStorage.setItem('aemeath_speech_on', speechOn ? '1' : '0'); } catch {}
      if (!speechOn) { idleLineState = null; syncHostAemeathSpeech(null, lastT ?? 0); }
    }
    schemeId = `${next.form === 'q' ? 'mech' : 'normal'}-${speechOn ? 'on' : 'off'}`;
    return Promise.resolve();
  }
  const ANCH = {
    n: { gaze: [134, 92], tear: [146, 94], tears: [[146, 94], [122, 94]], z: [180, 40], hearts: [92, 172, 66], bubble: [128, 14] },
    q: { gaze: [128, 80], tear: [128, 88], tears: [[132, 88], [120, 88]], z: [176, 34], hearts: [90, 170, 58], bubble: [128, 10] },
  };
  return {
    draw, groupTilt,
    gestures: ['nod', 'shake', 'wave', 'bow', 'sing', 'stopsing', 'heart', 'starwish', 'paperplane'],
    setScheme,
    get form() { return form; },
    get singing() { return !!sing; },
    startSing,
    setSongPaused,
    stopSing,
    snapshot(fc, o, res = 3, frames = 30) {
      fixedRes = res;
      const g = document.createElementNS(SVGNS, 'g');
      for (let i = 0; i < frames; i++) draw(g, fc, { ...o, t: (o.t || 0) + i / 60 });
      const href = canvas.toDataURL('image/png');
      rig.dispose(); rig = null; mountedIn = null; fixedRes = 0;
      return `<image href="${href}" x="${VIEW[0]}" y="${VIEW[1]}" width="${VIEW[2] - VIEW[0]}" height="${VIEW[3] - VIEW[1]}"/>`;
    },
    dispose() { if (hiFpsTimer) { clearInterval(hiFpsTimer); hiFpsTimer = null; } rig?.dispose(); rig = null; canvas = null; fo = null; fxG = null; mountedIn = null; stopSing();
      songContext?.close().catch(() => {}); songContext = null; songBuffer = null;
    },
    reset: () => reset(false),
    get scheme() { return schemeId; },
    get painted() { return decoded || Promise.resolve(); },
    get colors() { return { z: form === 'q' ? '#6fd8ff' : '#ff8fc4' }; },
    get anchors() { return ANCH[form]; },
    get extent() { return form === 'q' ? [16, 12, 200, 252] : [14, 20, 200, 256]; },
    get hits() { return form === 'q' ? [[128, 86, 44], [128, 170, 46], [92, 120, 34], [168, 120, 34]] : [[130, 76, 52], [128, 168, 52], [100, 210, 30]]; },
    setSpeech(v) { speechOn = !!v; try { localStorage.setItem('aemeath_speech_on', speechOn ? '1' : '0'); } catch {} if (!speechOn) { idleLineState = null; syncHostAemeathSpeech(null, lastT ?? 0); } },
    getSpeech() { return speechOn; },
    model,
  };
}

/** The pack's own words, beyond the kit's. */
export const WORDS = (song) => ({
  sing: { motion: { seconds: .18 } },
  stopsing: { motion: { seconds: .18 } },
  singing: { expression: { like: 'happy', seconds: 1 } },
  heart: { motion: { seconds: 2.8, face: 'hearting' } },
  hearting: { expression: { like: 'happy', seconds: 1 } },
  starwish: { motion: { seconds: 4.2, face: 'excited' } },
  paperplane: { motion: { seconds: 3.8, face: 'happy' } },
});

/** The pack's entry (figure.json): her body for the figure frame, the kit's body drawn by her figure. */
export async function createAemeathBody(base, opts) {
  const rawHost = opts.host;
  let fig = null;
  const wrappedHost = rawHost ? new Proxy(rawHost, {
    get(target, prop) {
      if (prop === 'sound') {
        return (id, kind) => {
          if (fig?.form === 'q' && (kind === 'move' || id === 'step' || id === 'walk' || id === 'footstep')) {
            return target.sound?.('mechHover', 'move');
          }
          return target.sound?.(id, kind);
        };
      }
      const val = Reflect.get(target, prop, target);
      return typeof val === 'function' ? val.bind(target) : val;
    }
  }) : rawHost;
  fig = await createAemeathFigure(base, { ...opts, host: wrappedHost });
  const body = opts.kit.createBody(wrappedHost, { figure: fig, words: WORDS(fig.model.song) });
  const setState = body.set;
  body.set = state => {
    if (typeof state?.botPaused === 'boolean') fig.setSongPaused(state.botPaused);
    return setState?.call(body, state);
  };
  const doWord = body.do;
  const ALIAS = { '唱歌': 'sing', '唱远航星的告别': 'sing', '远航星的告别': 'sing', '停止唱歌': 'stopsing', '别唱了': 'stopsing', '停唱': 'stopsing', 'stop-singing': 'stopsing', '比心': 'heart', '许愿': 'starwish', '折纸飞机': 'paperplane', '纸飞机': 'paperplane', '放纸飞机': 'paperplane' };
  body.do = (w) => {
    const cmd = ALIAS[w] || w;
    if (cmd === 'stopsing') {
      const wasSinging = fig.singing;
      fig.stopSing();
      const accepted = doWord(cmd);
      return wasSinging || accepted;
    }
    const accepted = doWord(cmd);
    if (accepted && cmd === 'sing' && !fig.singing) fig.startSing();
    return accepted;
  };
  body.sing = () => body.do('sing');
  body.stopSing = () => body.do('stopsing');
  const dispose = body.dispose;
  body.dispose = () => { fig.dispose(); dispose?.(); };
  return body;
}
