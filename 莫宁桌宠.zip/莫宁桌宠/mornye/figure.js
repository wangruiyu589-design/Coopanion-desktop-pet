/**
 * Mornye (莫宁, fan-made, Wuthering Waves): a chibi angel with a floating halo, as a figure for the Coopanion kit (web/kit/body.js),
 * drawn with the kit's createRig (kit/rig.js). Structure follows the bundled whale figure (web/whale/figure.js).
 *
 * She stands three-quarters on, facing right; the kit mirrors the whole group when she turns. The kit runs the
 * body (walking, jumping, dragging, faces); this file turns each frame into rig parameters, runs springs for the
 * long hair, the fringe, the coat tails, the halo and the arms, swings the crystal earring as a pendulum, paints
 * the face (the near eye, the mouth, blush) into a live texture, and draws the rig into a canvas inside the
 * pet's own SVG group, so the stage's transform (position, squash, tilt, facing) applies.
 *
 * Every layer was cut from one master drawing, so at rest the parts line up pixel for pixel; what each part
 * hides (the hair behind the head, the coat behind the legs and arms, the thighs under the shirt, the skin under
 * the fringe) was painted in by edits of that same drawing. Her far eye stays under the fringe and is not drawn.
 *
 * Rig space = the kit's logo space: x=128 under the body, soles at y=256.
 * model.json keeps the master drawing's pixel frame for the face sprites; U/V convert.
 *
 * Derived from Coopanion's web/whale/figure.js (AGPL-3.0-or-later, Pal-AI-Lab).
 */
const f1 = n => Math.round(n * 100) / 100;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, k) => a + (b - a) * k;
const ease = (rate, dt) => 1 - Math.exp(-rate * dt);
const bump = u => Math.sin(Math.PI * clamp(u, 0, 1));
const smooth = (a, b, x) => { const k = clamp((x - a) / (b - a), 0, 1); return k * k * (3 - 2 * k); };
const SVGNS = 'http://www.w3.org/2000/svg';

// the face texture covers this rect of the master drawing (master pixels), one texel per master pixel
let FACE = { x: 476, y: 356, w: 252, h: 192 };  // replaced by model.face
// the head's parallax warps act over this rect (rig units)
const HEAD = [56, 30, 200, 158];

/** A leg's warp: below the hip it turns about the pivot by `a` degrees and lifts by `ty`; above, the turn fades out. */
function hinge([px, py], a, ty) {
  const c = Math.cos(a * Math.PI / 180), s = Math.sin(a * Math.PI / 180);
  return (u, v, x, y) => {
    const w = smooth(py - 6, py + 12, y), lx = x - px, ly = y - py;
    return [(lx * c - ly * s - lx) * w, ((lx * s + ly * c - ly) + ty) * w];
  };
}

let badTargetLogged = false;
function spring(k, c, lim = Infinity) {
  return {
    x: 0, v: 0,
    step(target, dt) {
      if (!Number.isFinite(target) || !Number.isFinite(dt)) {
        if (!badTargetLogged) { badTargetLogged = true; console.warn(`[莫宁] spring target not finite: ${target} dt=${dt}`); }
        return this.x;
      }
      this.v += ((target - this.x) * k - this.v * c) * dt;
      this.x += this.v * dt;
      if (Math.abs(this.x) > lim) { this.x = Math.sign(this.x) * lim; this.v = 0; }
      return this.x;
    },
  };
}

function loadImage(url) {
  return new Promise((ok, bad) => { const im = new Image(); im.onload = () => ok(im); im.onerror = bad; im.src = url; });
}

/**
 * Loads the model and textures; resolves to a figure object for the kit's `opts.figure`.
 * Options as the whale's: `opts.raster`, `opts.scheme`, `opts.model`, `opts.asset`, `opts.loadImage`, `opts.kit`.
 */
export async function createMornyeFigure(base = new URL('./', import.meta.url), opts = {}) {
  const createRig = opts.kit?.createRig ?? (await import('../kit/rig.js')).createRig;
  const model = opts.model || await (await fetch(new URL('model.json', base))).json();
  const asset = opts.asset || (p => new URL(p, base));
  const load = opts.loadImage || loadImage;
  const { S, X0, FEET } = model.units;
  if (model.face) FACE = model.face;
  const U = x => 128 + (x - X0) * S, V = y => 256 - (FEET - y) * S;
  const feat = model.feat;
  const EYES = ['eyeL'];  // the near eye; the far one is under the fringe
  const featNames = [...Object.keys(feat.sprites), ...EYES.flatMap(k => ['lash', 'ball', 'iris', ...(feat.eyes[k].rim ? ['rim'] : [])].map(n => `${k}_${n}`))];
  const SCHEMES = (model.schemes || [{ id: 'mornye' }]).filter(sc => sc.ready !== false);
  const schemeInfo = id => SCHEMES.find(sc => sc.id === id) || SCHEMES[0];
  const OUTFITS = model.outfits || [{ id: 'coat' }];
  const outfitInfo = id => OUTFITS.find(o => o.id === id) || OUTFITS[0];
  const pickOf = id => { const [c, o] = String(id ?? '').split('-'); return { scheme: schemeInfo(c).id, outfit: outfitInfo(o).id }; };
  const partsOf = id => outfitInfo(id).parts || model.parts;
  const accent = () => schemeInfo(scheme).accent || '#8B6CF6';
  const loaded = {}, ready = {};
  function loadScheme(sc, of) {
    const key = `${sc}-${of}`;
    if (loaded[key]) return loaded[key];
    const dir = sc === SCHEMES[0].id ? '' : `schemes/${sc}/`;
    const set = { tex: {}, img: {} };
    loaded[key] = Promise.all([
      ...partsOf(of).map(async p => { set.tex[p.tex] = await load(asset(p.src || `${dir}tex/${p.tex}.png`)); }),
      ...featNames.map(async n => { set.img[n] = await load(asset(`${dir}feat/${n}.png`)); }),
      ...(schemeInfo(sc).eyeHighlights ? EYES.map(async k => { set.img[`${k}_hl`] = await load(asset(`${dir}feat/${k}_hl.png`)); }) : []),
    ]).then(() => (ready[key] = set));
    return loaded[key];
  }
  let { scheme, outfit } = pickOf(opts.scheme);
  let { tex, img } = await loadScheme(scheme, outfit);

  /** The rig's deformers and parts. */
  function layoutOf(of) {
    const list = partsOf(of);
    const PV = { ...model.pivots, ...outfitInfo(of).pivots };
    const box = Object.fromEntries(list.map(p => [p.id, p.box]));
    const rectOf = id => { const [x, y, w, h] = box[id]; return [x, y, x + w, y + h]; };
    const deformers = {
      body: { kind: 'rot', pivot: PV.body },
      // the coat's tails swing and flare like a skirt; the legs swing about the hip inside it
      // the torso and the coat tails share one field, so they can never part at the waist; the upper body bows in it
      bodyWarp: { kind: 'warp', parent: 'body', rect: [Math.min(rectOf('torso')[0], rectOf('coat')[0]), rectOf('torso')[1], Math.max(rectOf('torso')[2], rectOf('coat')[2]), rectOf('coat')[3]] },
      waist: { kind: 'rot', parent: 'body', pivot: PV.waist },
      armNear: { kind: 'rot', parent: 'waist', pivot: PV.armNear },
      armFar: { kind: 'rot', parent: 'waist', pivot: PV.armFar },
      // the forearm trails the swing a little (a soft elbow), more toward the hand
      armNearBend: { kind: 'warp', parent: 'armNear', rect: rectOf('arm_near') },
      armFarBend: { kind: 'warp', parent: 'armFar', rect: rectOf('arm_far') },
      legBack: { kind: 'warp', parent: 'body', rect: rectOf('leg_back') },
      legFront: { kind: 'warp', parent: 'body', rect: rectOf('leg_front') },
      // sitting: her lower body drawn seated, and the floating seat under her (it appears as she sits down)
      lowerSit: { kind: 'warp', parent: 'body', rect: rectOf('lower_sit') },
      seat: { kind: 'rot', parent: 'body', pivot: PV.seat },
      neck: { kind: 'rot', parent: 'waist', pivot: PV.neck },
      headBack: { kind: 'warp', parent: 'neck', rect: HEAD },
      headMid: { kind: 'warp', parent: 'neck', rect: HEAD },
      headFeat: { kind: 'warp', parent: 'neck', rect: HEAD },
      headFront: { kind: 'warp', parent: 'neck', rect: HEAD },
      hairSway: { kind: 'warp', parent: 'headBack', rect: rectOf('hair_back') },
      bangsSway: { kind: 'warp', parent: 'headFront', rect: rectOf('bangs') },
      // the halo floats over the head on its own spring: it follows the head, a beat late
      halo: { kind: 'rot', parent: 'neck', pivot: PV.halo },
    };
    const swings = outfitInfo(of).deformers || {};
    for (const [k, d] of Object.entries(swings)) deformers[k] = { kind: 'rot', parent: d.parent, pivot: d.pivot };
    const parts = list.map(p => ({ ...p, parent: { torso: 'bodyWarp', coat: 'bodyWarp', shoulder_cap: 'bodyWarp', arm_near: 'armNearBend', arm_far: 'armFarBend' }[p.id] || p.parent }));
    const coatTop = PV.waist[1], coatBot = rectOf('coat')[3], cx0 = rectOf('coat')[0], cx1 = rectOf('coat')[2];
    parts.push({ id: 'faceFx', tex: 'faceFx', box: [U(FACE.x), V(FACE.y), FACE.w * S, FACE.h * S], z: 9, parent: 'headFeat', grid: [4, 4] });
    return { PV, deformers, parts, swings, heldArms: outfitInfo(of).heldArms ?? .8, coatTop, coatBot, cx0, cx1, rectOf };
  }
  let L = layoutOf(outfit);

  /* ---------- face painting (master pixels) ---------- */
  // the face sprites are drawn at FS texels per master pixel
  const FS = feat.scale || 1;
  const faceCv = document.createElement('canvas');
  faceCv.width = FACE.w * FS; faceCv.height = FACE.h * FS;
  const faceCv2 = document.createElement('canvas');
  faceCv2.width = FACE.w * FS; faceCv2.height = FACE.h * FS;
  const dimg = (g, im, x, y) => g.drawImage(im, x, y, im.width / FS, im.height / FS);
  const fg1 = faceCv.getContext('2d'), fg2 = faceCv2.getContext('2d');
  let fg = fg1;
  let lashVis = 1;   // the lash flicks over the hair show only with the open drawn eye
  const eyeCv = document.createElement('canvas');
  const INK = '#5a2a33';
  const poly2 = (c, x) => c[0] * x * x + c[1] * x + c[2];

  const EYE = Object.fromEntries(EYES.map(k => {
    const e = feat.eyes[k], [x0, , x1] = e.ball;
    let h = 0;
    for (let x = x0 + 6; x < x1 - 6; x += 2) h = Math.max(h, poly2(e.rimFit, x) - poly2(e.lidFit, x));
    const cx = (e.iris[0] + e.iris[2]) / 2;
    return [k, { ...e, travel: h + 3, cx, cy: poly2(e.lidFit, cx) }];
  }));

  const hl = { dx: 0, dy: 0, scale: 1, quiver: 0, alpha: 1 };
  const HL_MOOD = {
    sad: { scale: 1.12, quiver: 1 }, worried: { scale: 1.1, quiver: .8 }, shy: { scale: 1.1, quiver: .6 }, pout: { scale: 1.06, quiver: .4 },
    excited: { scale: 1.18 }, listening: { scale: 1.06 }, angry: { scale: .78 }, determined: { scale: .86 },
    sleepy: { scale: .92, alpha: .7 }, content: { alpha: .8 }, waking: { alpha: .75 },
  };

  /** The open eye, lid at `open` (0 shut, 1 rest), iris moved by ix/iy, lid tilted by tilt (rad); `glint` adds stars. */
  function paintOpenEye(k, open, ix, iy, tilt, glint = 0, t = 0) {
    const e = EYE[k], [bx0, by0, bx1, by1] = e.ball, w = bx1 - bx0, h = by1 - by0;
    if (eyeCv.width !== (w + 40) * FS || eyeCv.height !== (h + 40) * FS) { eyeCv.width = (w + 40) * FS; eyeCv.height = (h + 40) * FS; }
    const g = eyeCv.getContext('2d');
    g.setTransform(FS, 0, 0, FS, (20 - bx0) * FS, (20 - by0) * FS);
    g.clearRect(bx0 - 20, by0 - 20, w + 40, h + 40);
    g.globalCompositeOperation = 'source-over';
    dimg(g, img[`${k}_ball`], bx0, by0);
    g.globalCompositeOperation = 'source-atop';
    dimg(g, img[`${k}_iris`], e.iris[0] + ix, e.iris[1] + iy);
    const d = (1 - clamp(open, 0, 1)) * e.travel, tn = Math.tan(tilt);
    const hlImg = img[`${k}_hl`];
    if (hlImg && e.hl) {
      const q = hl.quiver, w2 = hlImg.width / FS * hl.scale, h2 = hlImg.height / FS * hl.scale;
      const cx = (e.hl[0] + e.hl[2]) / 2 + ix + hl.dx + q * .8 * Math.sin(t * 29);
      let cy = (e.hl[1] + e.hl[3]) / 2 + iy + hl.dy + q * .6 * Math.sin(t * 37);
      const lid = poly2(e.lidFit, clamp(cx, bx0, bx1)) + d + tn * (cx - e.cx) + 2;
      if (cy - h2 / 2 < lid) cy = Math.max(cy, Math.min(lid + h2 / 2, (e.iris[1] + e.iris[3]) / 2 + iy));
      g.globalAlpha = hl.alpha;
      g.drawImage(hlImg, cx - w2 / 2, cy - h2 / 2, w2, h2);
      g.globalAlpha = 1;
    }
    if (e.rim) { g.globalCompositeOperation = 'source-over'; dimg(g, img[`${k}_rim`], e.rim[0], e.rim[1]); }
    if (glint > 0) {
      g.globalCompositeOperation = 'source-atop';
      const ic = [(e.iris[0] + e.iris[2]) / 2 + ix, (e.iris[1] + e.iris[3]) / 2 + iy];
      [[-.16, -.2, 16], [.2, .2, 9]].forEach(([fx, fy, r], j) => {
        const R = r * glint * (.8 + .3 * Math.sin(t * 7 + j * 2)), ww = R * .28;
        const cx = ic[0] + fx * (e.iris[2] - e.iris[0]), cy = ic[1] + fy * (e.iris[3] - e.iris[1]);
        g.save(); g.translate(cx, cy);
        g.fillStyle = 'rgba(255,255,255,.95)';
        g.beginPath(); g.moveTo(0, -R); g.quadraticCurveTo(ww, -ww, R, 0); g.quadraticCurveTo(ww, ww, 0, R); g.quadraticCurveTo(-ww, ww, -R, 0); g.quadraticCurveTo(-ww, -ww, 0, -R); g.fill();
        g.restore();
      });
    }
    // the lid hides everything above it
    g.globalCompositeOperation = 'destination-out';
    g.beginPath();
    g.moveTo(bx0 - 20, by0 - 20);
    for (let x = bx0 - 20; x <= bx1 + 20; x += 3) g.lineTo(x, poly2(e.lidFit, clamp(x, bx0, bx1)) + d + tn * (x - e.cx) - 1);
    g.lineTo(bx1 + 20, by0 - 20);
    g.closePath(); g.fill();
    g.globalCompositeOperation = 'source-over';
    fg.drawImage(eyeCv, bx0 - 20 - FACE.x, by0 - 20 - FACE.y, eyeCv.width / FS, eyeCv.height / FS);
    // the lashes ride down with the lid and flatten as they close
    const Ls = e.lash, sy = .55 + .45 * clamp(open, 0, 1);
    fg.save();
    fg.translate(e.cx - FACE.x, e.cy + d - FACE.y);
    fg.rotate(tilt);
    fg.scale(1, sy);
    dimg(fg, img[`${k}_lash`], Ls[0] - e.cx, Ls[1] - e.cy);
    fg.restore();
  }

  /** A whole drawn sprite (an expression's eye or mouth) at its place, optionally scaled/rotated about its centre. */
  function sprite(name, o = {}) {
    const b = feat.sprites[name];
    if (!b || !img[name]) return;
    const cx = (b[0] + b[2]) / 2, cy = (b[1] + b[3]) / 2;
    fg.save();
    fg.globalAlpha = o.alpha ?? 1;
    fg.translate(cx - FACE.x, cy - FACE.y);
    if (o.rot) fg.rotate(o.rot);
    fg.scale(o.sx ?? o.s ?? 1, o.sy ?? o.s ?? 1);
    dimg(fg, img[name], b[0] - cx, b[1] - cy);
    fg.restore();
  }

  // blush: under the near eye, and a little of the far cheek that shows by the fringe
  const CHEEKS = model.cheeks || [[652, 500, 34, 16], [468, 505, 16, 10]];
  function paintBlush(a) {
    if (a < .02) return;
    for (const [x, y, rx, ry] of CHEEKS) {
      fg.save();
      fg.translate(x - FACE.x, y - FACE.y); fg.scale(1, ry / rx);
      const gr = fg.createRadialGradient(0, 0, 0, 0, 0, rx);
      gr.addColorStop(0, `rgba(255,120,150,${f1(.55 * a)})`); gr.addColorStop(1, 'rgba(255,120,150,0)');
      fg.fillStyle = gr; fg.beginPath(); fg.arc(0, 0, rx, 0, Math.PI * 2); fg.fill();
      fg.restore();
    }
  }

  /** Small drawn mouths for the moods the sprites don't cover (form < 0 frowns). */
  function lineMouth(form, w = 1) {
    const [mx0, my0] = model.mouth || [537, 507];
    const cx = mx0 - FACE.x, cy = my0 - FACE.y;
    fg.save(); fg.strokeStyle = INK; fg.lineWidth = 2.6; fg.lineCap = 'round';
    fg.beginPath(); fg.moveTo(cx - 10 * w, cy - form * 3); fg.quadraticCurveTo(cx, cy + form * 5, cx + 10 * w, cy - form * 3); fg.stroke();
    fg.restore();
  }

  const MOUTH = {
    neutral: 'neutral_mouth', happy: 'happy_mouth', wink: ['happy_mouth', .8], love: 'love_mouth', shy: ['drag_mouth', .7],
    surprised: 'surprised_mouth', sleepy: 'sleep_mouth', sleep: 'sleep_mouth', dizzy: 'dizzy_mouth', dragged: 'drag_mouth',
    content: 'neutral_mouth', waking: ['surprised_mouth', .6], squeeze: 'sleep_mouth', listening: 'neutral_mouth',
    thinking: 'sleep_mouth', run: ['happy_mouth', .7], angry: -1, sad: -1.2,
    smug: .7, pout: ['surprised_mouth', .45], worried: ['drag_mouth', .6], determined: .15, flustered: ['drag_mouth', .8],
    scared: ['drag_mouth', .8], excited: 'happy_mouth', cry: ['surprised_mouth', .8], confused: -.35,
  };

  const TEAR_END = { eyeL: 532 };
  function paintStreams(t) {
    fg.save();
    EYES.forEach((k, i) => {
      const e = EYE[k], [bx0, , bx1, by1] = e.ball, w = (bx1 - bx0) * .22;
      const x = bx0 + (bx1 - bx0) * .55 - FACE.x, y0 = by1 - 6 - FACE.y;
      const y1 = Math.min(FACE.h - 4, TEAR_END[k] - FACE.y, y0 + 110), wob = 4 * Math.sin(t * 6 + i);
      const gr = fg.createLinearGradient(0, y0, 0, y1);
      gr.addColorStop(0, 'rgba(150,190,255,.95)'); gr.addColorStop(1, 'rgba(150,190,255,.3)');
      fg.fillStyle = gr;
      fg.beginPath();
      fg.moveTo(x - w * .15, y0);
      fg.bezierCurveTo(x - w * .5 + wob, y0 + 25, x - w * .55 + wob, y1 - 20, x - w * .4, y1);
      fg.quadraticCurveTo(x, y1 + 6, x + w * .4, y1);
      fg.bezierCurveTo(x + w * .55 + wob, y1 - 20, x + w * .5 + wob, y0 + 25, x + w * .15, y0);
      fg.closePath(); fg.fill();
    });
    fg.restore();
  }

  function paintFace(fc, face, o, t) {
    fg.setTransform(1, 0, 0, 1, 0, 0);
    fg.clearRect(0, 0, faceCv.width, faceCv.height);
    fg.setTransform(FS, 0, 0, FS, 0, 0);
    paintBlush(fc.blush || 0);
    if (fc.streams) paintStreams(t);
    sprite('nose');
    const shut = Math.max(o.blink || 0, o.eyeClose || 0);
    const lx = clamp(o.look[0], -6, 6), ly = clamp(o.look[1], -5, 5);
    const tilt = fc.brows === 'angry' ? .16 : fc.brows === 'sad' ? -.13 : 0;
    const e = fc.eyes[0], k = 'eyeL';  // the near eye is the kit's first
    lashVis = 0;
    if (e) {
      const squash = { sy: 1 - .85 * (o.eyeClose || 0) };
      if ((face === 'surprised' || fc.wide) && e.shape === 'ring') sprite(`surprised_${k}`, squash);
      else switch (e.shape) {
        case 'ring': case 'lid': {
          const open = (e.shape === 'ring' ? clamp(e.ry / e.rx, 0, 1) * (tilt ? .8 : 1) : clamp(e.ry / 16, 0, 1)) * (1 - shut);
          const ix = clamp(lx + (e.dx || 0), -6, 6), iy = clamp(ly * .7 + (e.dy || 0) * .7, -3.5, 3.5);
          paintOpenEye(k, open, ix * 1.1, iy + (e.shape === 'lid' ? 3 : 0), tilt, fc.sparkle ? 1 : 0, t);
          lashVis = smooth(.45, .8, open);
          break;
        }
        case 'up': sprite(`happy_${k}`, squash); break;
        case 'down': sprite(`sleep_${k}`, squash); break;
        case 'gt': case 'lt': sprite(`drag_${k}`, { s: 1 + .03 * Math.sin(t * 22) }); break;
        case 'heart': sprite(`love_${k}`, { s: .94 + .06 * (e.s ?? 1) / .8 }); break;
        case 'spiral': sprite(`dizzy_${k}`, { s: 1 + .04 * Math.sin(t * 6) }); break;   // the spiral pulses, it doesn't spin
      }
    }
    const talk = o.talk || 0;
    const gapOpen = clamp((Math.max(fc.gap[0], fc.gap[1]) - 50) / 14, 0, 1);
    const m = MOUTH[face] ?? 'neutral_mouth';
    const open = Math.max(talk * (.45 + .45 * Math.abs(Math.sin(t * 17))), face === 'sleepy' || face === 'waking' ? gapOpen : 0);
    if (open > .12) sprite(face === 'surprised' ? 'surprised_mouth' : 'happy_mouth', { sy: .35 + .65 * open, sx: .85 + .15 * open });
    else if (typeof m === 'number') lineMouth(m);
    else if (Array.isArray(m)) sprite(m[0], { s: m[1] });
    else sprite(m);
  }

  /* ---------- mounting inside the pet's SVG group ---------- */
  const VIEW = model.view;
  let fo = null, canvas = null, fxG = null, rig = null, mountedIn = null, pxScale = 0, frameN = 0;
  function mount(petG) {
    petG.textContent = '';
    rig?.dispose();
    rig = null;
    const box = (el) => { el.setAttribute('x', VIEW[0]); el.setAttribute('y', VIEW[1]); el.setAttribute('width', VIEW[2] - VIEW[0]); el.setAttribute('height', VIEW[3] - VIEW[1]); return el; };
    canvas = document.createElementNS('http://www.w3.org/1999/xhtml', 'canvas');
    if (opts.raster) {
      fo = box(document.createElementNS(SVGNS, 'image'));
    } else {
      fo = box(document.createElementNS(SVGNS, 'foreignObject'));
      canvas.style.cssText = 'width:100%;height:100%;display:block';
      fo.appendChild(canvas);
    }
    fxG = document.createElementNS(SVGNS, 'g');
    petG.append(fo, fxG);
    rig = createRig(canvas, { deformers: L.deformers, parts: L.parts, view: VIEW });
    for (const n in tex) rig.upload(n, tex[n]);
    if (fade) for (const n in fade.set.tex) rig.upload(n + '@mix', fade.set.tex[n]);
    mountedIn = petG; pxScale = 0;
  }
  let fade = null;
  function endFade() {
    if (!fade) return;
    tex = fade.set.tex; img = fade.set.img; fade = null;
    if (rig) for (const n in tex) rig.upload(n, tex[n]);
  }
  function setScheme(id, o = {}) {
    const next = pickOf(id), key = `${next.scheme}-${next.outfit}`;
    const apply = set => {
      endFade();
      if (scheme === next.scheme && outfit === next.outfit && tex === set.tex) return;
      scheme = next.scheme;
      if (outfit !== next.outfit) {
        outfit = next.outfit; L = layoutOf(outfit);
        tex = set.tex; img = set.img;
        rig?.dispose(); rig = null; mountedIn = null;
        return;
      }
      if (o.fade > 0 && rig) {
        fade = { set, dur: o.fade, t0: o.at ?? null };
        for (const n in set.tex) rig.upload(n + '@mix', set.tex[n]);
        return;
      }
      tex = set.tex; img = set.img;
      if (rig) for (const n in tex) rig.upload(n, tex[n]);
    };
    if (ready[key]) { apply(ready[key]); return Promise.resolve(); }
    return loadScheme(next.scheme, next.outfit).then(apply);
  }
  let decoded = null;
  let fixedRes = 0;
  function fitCanvas() {
    const m = fixedRes ? null : mountedIn.getScreenCTM();
    if (!m && !fixedRes) return;
    const k = fixedRes || Math.hypot(m.c, m.d) * (window.devicePixelRatio || 1) * 1.25;
    if (Math.abs(k - pxScale) / (pxScale || 1) < .08) return;
    pxScale = k;
    canvas.width = Math.max(16, Math.round((VIEW[2] - VIEW[0]) * Math.min(k, 6)));
    canvas.height = Math.max(16, Math.round((VIEW[3] - VIEW[1]) * Math.min(k, 6)));
  }

  /* ---------- per-frame state ---------- */
  const sp = {
    hair: spring(48, 6, 1.9), hairY: spring(45, 7, 1.3), bangs: spring(100, 9, 1.6),
    coat: spring(80, 7, 1.8), coatY: spring(80, 9, 1.2),
    haloX: spring(38, 5, 9), haloY: spring(42, 5, 10), haloA: spring(40, 4.5, 18),
    head: spring(70, 10, 16), armN: spring(90, 12, 125), armF: spring(80, 11, 95),
    hlX: spring(160, 9, 3), hlY: spring(160, 9, 3),
    bendN: spring(70, 9, 14), bendF: spring(70, 9, 14),
  };
  let armWas = {};
  const ELB = 1;   // the elbow turns the forearm the same way the shoulder raises the arm
  let lastT = null, prevTilt = 0, prevYaw = 0, prevLow = 0, headTilt = 0, fx = '';
  let prevLook = null, prevShut = 0, prevAir = 0;
  let rootWas = {};
  const GROUP = { air: [1, 1], drag: [1, 1], crouch: [1, 1], land: [1, 1], walk: [1, .5], run: [1, .5], dance: [.6, 0] };
  let wTilt = 0, wLean = 0, facing = 1;
  let haloMood = 0, haloGlow = 0, sitK = 0, walkK = 0, runK = 0, swingK = 0;
  // the seat: how far it has formed (0 gone, 1 there), and a clock for its sparkle burst
  let seatK = 0, seatBurst = -9, seatWas = 0;
  const groupTilt = (mode, tilt, lean) => tilt * wTilt + lean * wLean + runK * 12 * facing;
  const st = { z: {}, alpha: {}, tint: {} };

  // the halo by face: [how high it floats (+ up, units), glow 0..1 (the stars twinkle)]
  const HALO = {
    happy: [2.5, 1], love: [3, 1], wink: [1.5, .6], excited: [3.5, 1], surprised: [5, .5], smug: [1, .4], determined: [1, .3],
    sad: [-3, 0], cry: [-3.5, 0], worried: [-1.5, 0], scared: [-2, 0], sleepy: [-2, 0], sleep: [-2.5, 0], dizzy: [0, 0],
    shy: [-1, .3], flustered: [1, .2], angry: [0, 0], content: [0, .2], neutral: [0, 0], listening: [1, .3], thinking: [1, .2],
  };
  const HEAD_TILT = { shy: 7, thinking: -8, smug: -6, pout: -4, confused: -7, worried: 3, cry: 4 };
  const HEAD_PITCH = { sad: .35, cry: .45, worried: .15 };

  function draw(petG, fc, o) {
    if (mountedIn !== petG || !petG.contains(fo)) mount(petG);
    if (frameN++ % 20 === 0) fitCanvas();
    const t = o.t, dt = lastT == null ? 1 / 60 : clamp(t - lastT, 0, .05);
    lastT = t;
    const mode = o.mode || 'idle', face = o.face || 'neutral';
    facing = Math.sign(o.facing || 1);
    const walking = mode === 'walk' || mode === 'run', held = mode === 'drag', airborne = mode === 'air';

    sitK = lerp(sitK, clamp(o.sit ?? 0, 0, 1), ease(12, dt));
    const low = o.low || 0;
    const lowV = (low - prevLow) / Math.max(dt, 1e-3); prevLow = low;
    const breath = Math.sin(t * (mode === 'sleep' ? 1.7 : 2.4));

    /* head */
    let tiltT = o.look[0] * .7 + Math.sin(t * .9) * 1.2 + o.look[1] * .4;
    if (mode === 'sleep') tiltT += 6;
    tiltT += HEAD_TILT[face] || 0;
    if (face === 'dizzy') tiltT += 3 * Math.sin(t * 4.5);
    if (held) tiltT += o.swing * .25;
    headTilt = sp.head.step(tiltT, dt);
    const [gT, gL] = GROUP[mode] || [0, 0];
    const bend = (o.tilt ?? 0) * (1 - wTilt) + (o.lean ?? 0) * Math.sign(o.facing || 1) * (1 - wLean);
    wTilt = lerp(wTilt, gT, ease(10, dt)); wLean = lerp(wLean, gL, ease(10, dt));
    const g = o.gesture, gk = g ? g.k : 0;
    const env = (a, b) => smooth(0, a, gk) * (1 - smooth(b, 1, gk));
    const nod = g?.kind === 'nod' ? Math.sin(gk * Math.PI * 2) ** 2 * (1 - .3 * gk) : 0;
    const shake = g?.kind === 'shake' ? Math.sin(gk * Math.PI * 6) * smooth(0, .12, gk) * (1 - gk) : 0;
    const wave = g?.kind === 'wave' ? env(.15, .8) : 0;
    const bow = g?.kind === 'bow' ? env(.25, .7) : 0;
    const shiver = g?.kind === 'shiver' ? env(.08, .85) : 0;
    const flap = g?.kind === 'flap' ? env(.05, .75) : 0;
    const gNeck = nod * 7 + shake * 2.5 + bow * 10 + wave * 4, gYaw = shake * 1.1;
    const headA = headTilt + gNeck;
    const tiltVel = (headA - prevTilt) / Math.max(dt, 1e-3); prevTilt = headA;
    const yawVel = (gYaw - prevYaw) / Math.max(dt, 1e-3); prevYaw = gYaw;
    const angleX = clamp(clamp(o.look[0] / 5, -1, 1) * .9 + gYaw, -1.4, 1.4);
    const angleY = clamp(clamp(o.look[1] / 4, -1, 1) * .7 + (mode === 'sleep' ? .8 : 0) + (HEAD_PITCH[face] || 0) + nod * .9 + bow * .5, -1.4, 1.4);

    /* springs */
    const sway = clamp(o.swing / 26, -1.6, 1.6);
    const up = airborne || held ? 1 : 0;
    const hair = sp.hair.step(sway * 1.2 - tiltVel * .004 - yawVel * .02 + (walking ? -.3 : 0) - runK * .6, dt);
    const hairY = sp.hairY.step(up * -1 + lowV * .006, dt);
    const bangs = sp.bangs.step(sway * .7 - tiltVel * .004 - yawVel * .03, dt);
    const coat = sp.coat.step(sway * .9 + (walking ? -.25 : 0) - runK * .5, dt);
    const flare = sp.coatY.step(up * .8 + sitK * .7 + clamp(-lowV * .01, -.3, .6) + flap * .4 * Math.sin(t * 20), dt);
    const [hm, hg] = HALO[face] || HALO.neutral;
    haloMood = lerp(haloMood, hm + (mode === 'sleep' ? -2.5 : 0), ease(4, dt));
    haloGlow = lerp(haloGlow, Math.max(hg, flap, mode === 'dance' ? .8 : 0), ease(5, dt));

    /* legs */
    const legA = o.legs.map(l => -Math.atan2(l[2] - l[0], Math.max(4, l[3] - l[1])) * 180 / Math.PI);
    const lift = o.legs.map(l => clamp(29 - Math.hypot(l[2] - l[0], l[3] - l[1]), -8, 20));

    /* arms */
    walkK = lerp(walkK, walking ? 1 : 0, ease(8, dt));
    runK = lerp(runK, mode === 'run' ? 1 : 0, ease(7, dt));
    let aN = 3, aF = -2, swing = walking ? 1 : 0;
    if (airborne) { aN = 38; aF = -30; }
    if (held) { aN = (66 + 16 * Math.sin(t * 13)) * L.heldArms; aF = (-42 - 12 * Math.sin(t * 13 + 1.3)) * L.heldArms; }
    if (sitK > .5 && !walking) { aN = lerp(aN, -6, sitK); aF = lerp(aF, -4, sitK); }
    if (face === 'happy' || face === 'love') { aN += 10 + 5 * Math.sin(t * 8); aF -= 7 + 4 * Math.sin(t * 8); }
    if (face === 'angry') { aN = 18 + 3 * Math.sin(t * 30); aF = -16 - 3 * Math.sin(t * 30); swing = 0; }
    if (face === 'determined') { aN = 12; aF = -9; swing = 0; }
    if (face === 'excited') { aN += 16; aF -= 11; }
    if (mode === 'dance') { const b = Math.sin((o.modeT || 0) * Math.PI * 2 * 1.1); aN = 16 + 24 * Math.max(0, b); aF = -8 - 22 * Math.max(0, -b); }
    if (runK > .001) { aN = lerp(aN, 36, runK); aF = lerp(aF, 30, runK); }
    if (wave) aN = lerp(aN, 80, wave);   // waving: the upper arm lifts out to the side, the forearm does the waving
    if (shiver) { aN = lerp(aN, -10, shiver); aF = lerp(aF, 8, shiver); }
    swingK = lerp(swingK, swing, ease(8, dt));
    const gait = swingK * (1 - runK) * (1 - wave) * (1 - shiver) * .28;
    const armN = sp.armN.step(aN, dt) - legA[0] * gait + wave * 2.5 * Math.sin(t * 11 - .6) + shiver * 1.4 * Math.sin(t * 47) + flap * 9 * Math.sin(t * 24);
    const armF = sp.armF.step(aF, dt) - legA[1] * gait * .7 - shiver * 1.2 * Math.sin(t * 43 + 1) - flap * 9 * Math.sin(t * 24 + 1);

    /* deformer states */
    // seated she floats: the kit sinks the hips 29 for a seat on the floor; hers hovers, so she stays up and bobs with it
    const hover = sitK * (-4 + 2.2 * Math.sin(t * 1.6));
    st.body = { a: -sway * 1.2 + (held ? o.swing * .15 : 0), ty: low - 29 * sitK + hover, sx: (1 + .006 * breath) * (1 - .03 * shiver), sy: 1 - .012 * breath };
    st.waist = { a: bow * 18 };
    // one field for torso and coat: below the waist the tails swing, flare and drift; above it the upper body bows
    {
      const [wx, wy] = L.PV.waist, ba = bow * 18 * Math.PI / 180, bc = Math.cos(ba), bs = Math.sin(ba);
      const { coatTop, coatBot, cx0, cx1 } = L;
      st.bodyWarp = {
        fn: (u, v, x, y) => {
          const vv = clamp((y - coatTop) / (coatBot - coatTop), 0, 1), k = vv * vv, uu = clamp((x - cx0) / (cx1 - cx0), 0, 1);
          let dx = coat * 5 * k + flare * (uu - .5) * 10 * vv + Math.sin(t * 1.3 + uu * 3) * .35 * k;
          let dy = -flare * k * 3;
          if (ba) {
            const w = 1 - smooth(wy - 8, wy + 10, y), lx = x - wx, ly = y - wy;
            dx += (lx * bc - ly * bs - lx) * w; dy += (lx * bs + ly * bc - ly) * w;
          }
          return [dx, dy];
        },
      };
    }
    // the arms never swing in across the coat (a flat layer would cut through it): inward swing stops at the coat's edge;
    // only a full run sweeps the far arm back behind her
    const armNc = Math.max(armN, -3), armFc = Math.min(armF, lerp(3, 30, runK));
    st.armNear = { a: armNc };
    st.armFar = { a: armFc };
    // a soft elbow: the hand trails the arm's motion, and bends a little forward at the front of a stride
    const bendOf = (k, a) => {
      const v = (a - (armWas[k] ?? a)) / Math.max(dt, 1e-3); armWas[k] = a;
      const lagT = clamp(-v * .045, -12, 12) + (a < 0 ? a * .3 : a * .08);
      return sp[k === 'n' ? 'bendN' : 'bendF'].step(lagT, dt);
    };
    const bN = bendOf('n', armNc) + ELB * wave * (62 + 24 * Math.sin(t * 11)), bF = bendOf('f', armFc);
    // a real elbow: everything past it turns about it; the sleeve blends across a short band at the joint
    const elbowFn = (sh, el, b) => {
      const r = b * Math.PI / 180, c = Math.cos(r), sn = Math.sin(r);
      const ax = el[0] - sh[0], ay = el[1] - sh[1], l2 = ax * ax + ay * ay;
      return (u, v, x, y) => {
        const k = ((x - sh[0]) * ax + (y - sh[1]) * ay) / l2, w = smooth(.82, 1.18, k);
        if (!w) return [0, 0];
        const lx = x - el[0], ly = y - el[1];
        return [(lx * c - ly * sn - lx) * w, (lx * sn + ly * c - ly) * w];
      };
    };
    st.armNearBend = { fn: elbowFn(L.PV.armNear, L.PV.elbowNear, bN) };
    st.armFarBend = { fn: elbowFn(L.PV.armFar, L.PV.elbowFar, bF) };
    // swung in across her body, the far arm passes behind it (behind the shirt and the coat's near panel too)
    st.z.arm_far = armFc > 12 ? 1.5 : armFc < -30 || bF < -25 ? 13.7 : 5.6;
    // raised (or with the forearm up while waving), the arm is in front of the hair beside her face, never under it
    st.z.arm_near = armNc > 30 || bN > 25 || wave > .02 ? 13.8 : 6;
    st.z.shoulder_cap = st.z.arm_near + .05;   // the coat's shoulder pad always covers the top of the waving arm
    // sitting swaps the standing coat tails and legs for the seated drawing halfway down
    const sitIn = smooth(.44, .56, sitK);
    st.alpha.coat = 1 - sitIn;
    st.alpha.leg_back = st.alpha.leg_front = 1 - smooth(.42, .54, sitK);
    st.alpha.lower_sit = sitIn;
    st.alpha.hair_back = 1 - sitIn; st.alpha.hair_back_sit = sitIn;   // seated, the hair tips go behind the seat
    // her feet swing a little while she sits, more when she is happy
    const kick = (face === 'happy' || face === 'love' || face === 'excited' ? 2.6 : 1.1) * (mode === 'sleep' ? .3 : 1);
    st.lowerSit = { fn: (u, v) => { const k = smooth(.5, 1, v); return [k * kick * Math.sin(t * 2.3 + u * 1.5), -k * .6 * Math.max(0, Math.sin(t * 2.3 + u * 1.5))]; } };
    // the seat forms as she sits down (a little ahead of her) and dissolves as she gets up
    seatK = smooth(.04, .42, sitK);
    if ((seatK > .02) !== (seatWas > .02)) seatBurst = t;
    seatWas = seatK;
    const pop = seatK < 1 ? 1 - Math.pow(1 - seatK, 3) : 1;
    st.seat = { s: .7 + .3 * pop + .05 * Math.sin(Math.PI * seatK), a: (1 - seatK) * -6, ty: (1 - seatK) * 6 - hover * .15 };
    st.alpha.seat = smooth(0, .7, seatK);
    const glow = Math.sin(Math.PI * clamp(seatK, 0, 1));
    st.tint.seat = [1.35, 1.3, 1.45, .7 * glow];
    const behind = o.legs.map(l => Math.max(0, l[0] - l[2]) * .3 * walkK);
    st.legBack = { fn: hinge(L.PV.legBack, lerp(legA[0], -55, sitK), (-lift[0] * .9 - behind[0]) * (1 - sitK)) };
    st.legFront = { fn: hinge(L.PV.legFront, lerp(legA[1], -60, sitK), (-lift[1] * .9 - behind[1]) * (1 - sitK)) };
    st.neck = { a: headA + clamp(bend * .8, -10, 12) - runK * 10, ty: (mode === 'sleep' ? 2.5 : 0) + breath * .35 };
    const parallax = (k, ky) => (u, v) => [angleX * k * bump(u) * (.4 + .6 * bump(v)), angleY * ky * bump(v) * (.4 + .6 * bump(u))];
    const pFront = parallax(4.2, 2.8), pBack = parallax(-1.4, -1), BR = L.rectOf('bangs');
    st.headFront = { fn: pFront };
    st.headFeat = { fn: parallax(2.2, 1.5) };
    st.headMid = { fn: parallax(2, 1.4) };
    st.headBack = { fn: parallax(-1.4, -1) };
    // the long hair hangs from the head; its lower half keeps to the body when the head tilts, and trails
    const nk = L.PV.neck, na = headA * Math.PI / 180;
    st.hairSway = {
      fn: (u, v, x, y) => {
        const w = smooth(.25, .75, v), a = -na * w, c = Math.cos(a), s = Math.sin(a);
        const dx = x - nk[0], dy = y - nk[1];
        const wv = Math.pow(v, 1.5);
        // where the fringe's outline continues into the long hair's, the long hair moves with the fringe
        // (same parallax and sway), so the silhouette never breaks at the chin; lower down it hangs on its own
        const hu = (x - HEAD[0]) / (HEAD[2] - HEAD[0]), hv = (y - HEAD[1]) / (HEAD[3] - HEAD[1]);
        const keep = 1 - smooth(.42, .78, v), pf = pFront(hu, hv), pb = pBack(hu, hv);
        const bv = clamp((y - BR[1]) / (BR[3] - BR[1]), 0, 1), bu = clamp((x - BR[0]) / (BR[2] - BR[0]), 0, 1);
        const sx = (pf[0] - pb[0] + bangs * 3 * bv * bv + Math.sin(t * 1.9 + bu * 2) * .45 * bv * bv) * keep;
        const sy = (pf[1] - pb[1] + hairY * 2.5 * bv * bv) * keep;
        const own = 1 - keep;
        return [nk[0] + dx * c - dy * s - x + (hair * 9 * wv + Math.sin(t * 1.5 + v * 3) * 1.1 * wv + (u - .5) * flare * 3 * wv) * own + sx,
          nk[1] + dx * s + dy * c - y + (hairY * 12 * wv * wv - Math.abs(hair) * 1.5 * wv) * own + sy];
      },
    };
    st.bangsSway = { fn: (u, v) => [bangs * 3 * v * v + Math.sin(t * 1.9 + u * 2) * .45 * v * v, hairY * 2.5 * v * v] };
    // the halo: floats and bobs, lags the head's motion, rises with joy and sinks with sorrow, tips with the turn
    const airLift = clamp(-lowV * .02, -4, 6);
    const hx = sp.haloX.step(-sway * 5 - tiltVel * .05 - yawVel * .6, dt);
    const hy = sp.haloY.step(-haloMood + airLift - up * 3 + (mode === 'drag' ? -2 : 0), dt);
    const ha = sp.haloA.step(-sway * 10 - tiltVel * .12 + angleX * 4 + (face === 'dizzy' ? 10 * Math.sin(t * 5) : 0), dt);
    const bob = Math.sin(t * 1.8) * 1.6 + Math.sin(t * .7) * .6;
    st.halo = { a: ha - headA * .5, tx: hx + angleX * 3, ty: hy + bob + (mode === 'sleep' ? 1.5 : 0), sx: 1 - .06 * Math.abs(angleX), sy: 1 };
    st.alpha.halo = mode === 'sleep' ? .65 + .1 * Math.sin(t * 1.2) : 1;
    // the halo brightens a little when she glows
    st.tint.halo = [1.08, 1.06, 1.15, haloGlow * (.5 + .5 * Math.sin(t * 6))];
    // the earring (and anything else hung on her) is a pendulum
    const faceTurn = (angleX - (rootWas.face ?? angleX)) / Math.max(dt, 1e-3); rootWas.face = angleX;
    for (const [k, d] of Object.entries(L.swings)) {
      let root = (o.groupRot || 0) * facing, onHead = false;
      for (let p = d.parent; p; p = L.deformers[p].parent) {
        if (L.deformers[p].kind === 'rot') root += st[p]?.a || 0;
        if (p === 'neck') onHead = true;
      }
      const kick = (root - (rootWas[k] ?? root)) / Math.max(dt, 1e-3); rootWas[k] = root;
      const pend = sp[`pend_${k}`] ||= spring(30, 1.6, 55), ph = d.pivot[0] * .05;
      const a = pend.step((-sway * 34 - kick * .15 + (onHead ? faceTurn * 8 : 0) + walkK * (legA[0] - legA[1]) * .3) * d.gain, dt);
      const idle = onHead ? Math.sin(t * 1.7 + ph) * 5 + Math.sin(t * 2.9 + ph * 1.3) * 2 : Math.sin(t * 1.7 + ph) * 2;
      st[k] = { a: a + idle * d.gain - root * Math.min(1, d.gain) };
    }

    const look = [clamp(o.look[0], -6, 6), clamp(o.look[1], -5, 5)], was = prevLook || look; prevLook = look;
    const shut = Math.max(o.blink || 0, o.eyeClose || 0), shutV = (shut - prevShut) / Math.max(dt, 1e-3); prevShut = shut;
    hl.dx = sp.hlX.step(-(look[0] - was[0]) / Math.max(dt, 1e-3) * .03 - yawVel * .8, dt);
    hl.dy = sp.hlY.step(-(look[1] - was[1]) / Math.max(dt, 1e-3) * .03 + shutV * .12, dt);
    const mood = HL_MOOD[face] || {};
    hl.scale = lerp(hl.scale, mood.scale ?? 1, ease(6, dt));
    hl.quiver = lerp(hl.quiver, mood.quiver ?? 0, ease(4, dt));
    hl.alpha = lerp(hl.alpha, mood.alpha ?? 1, ease(4, dt));

    paintFace(fc, face, o, t);
    rig.upload('faceFx', faceCv);
    st.alpha.lash_tip = lashVis;
    st.mix = 0;
    if (fade) {
      if (fade.t0 == null) fade.t0 = t;
      st.mix = smooth(0, 1, (t - fade.t0) / fade.dur);
      const own = img;
      img = fade.set.img; fg = fg2;
      paintFace(fc, face, o, t);
      img = own; fg = fg1;
      rig.upload('faceFx@mix', faceCv2);
    }
    rig.render(st);
    if (opts.raster) { fo.setAttribute('href', canvas.toDataURL('image/png')); decoded = fo.decode ? fo.decode().catch(() => {}) : null; }
    if (fade && st.mix >= 1) endFade();
    drawFx(fc, t);
  }

  /* ---------- effects over the figure (SVG) ---------- */
  const at = (x, y) => rig.point('neck', st, x, y);
  const STAR = 'M0 -7Q1.2 -1.2 7 0Q1.2 1.2 0 7Q-1.2 1.2 -7 0Q-1.2 -1.2 0 -7Z';
  function drawFx(fc, t) {
    let s = '';
    const ac = accent();
    const top = at(126, 30), side = at(198, 56);
    // the seat's light ring, hovering under it, and the stars it gives off when it forms or dissolves
    if (seatK > .01) {
      const rp = rig.point('body', st, L.PV.seatRing[0], L.PV.seatRing[1]);
      const rx = 52 * (.6 + .4 * seatK), ry = 9 * (.6 + .4 * seatK), br = .55 + .25 * Math.sin(t * 2.4);
      s += `<g opacity="${f1(seatK * br)}"><ellipse cx="${f1(rp[0])}" cy="${f1(rp[1])}" rx="${f1(rx + 4)}" ry="${f1(ry + 2.5)}" fill="none" stroke="${ac}" stroke-opacity=".35" stroke-width="5"/>`
        + `<ellipse cx="${f1(rp[0])}" cy="${f1(rp[1])}" rx="${f1(rx)}" ry="${f1(ry)}" fill="none" stroke="#f4f0ff" stroke-width="1.6"/>`;
      for (let i = 0; i < 4; i++) {
        const a = t * .9 + i * Math.PI / 2, x = rp[0] + rx * Math.cos(a), y = rp[1] + ry * Math.sin(a), k = .55 + .45 * Math.sin(t * 5 + i);
        s += `<path fill="#ffffff" opacity="${f1(k)}" transform="translate(${f1(x)} ${f1(y)}) scale(${f1(.45 + .25 * k)})" d="${STAR}"/>`;
      }
      s += '</g>';
    }
    const burst = t - seatBurst;
    if (burst >= 0 && burst < .9) {
      const sc = rig.point('seat', st, L.PV.seat[0], L.PV.seat[1]);
      for (let i = 0; i < 10; i++) {
        const a = i * 2.39 + 1, r = 30 + 60 * burst + 12 * (i % 3), k = 1 - burst / .9;
        s += `<path fill="#fff7c8" stroke="${ac}" stroke-width=".8" opacity="${f1(k)}" transform="translate(${f1(sc[0] + r * Math.cos(a))} ${f1(sc[1] + .55 * r * Math.sin(a) - 20 * burst)}) scale(${f1(.5 + .5 * k)})" d="${STAR}"/>`;
      }
    }
    // little stars twinkle round the halo while she glows
    if (haloGlow > .15) {
      const hc = rig.point('halo', st, L.PV.halo[0], L.PV.halo[1]);
      for (let i = 0; i < 4; i++) {
        const p = (t * .55 + i / 4) % 1, a = i * 1.7 + t * .4;
        const x = hc[0] + 52 * Math.cos(a), y = hc[1] - 4 + 9 * Math.sin(a) - 10 * p;
        const k = Math.sin(Math.PI * p) * haloGlow;
        s += `<path fill="#fff7c8" stroke="${ac}" stroke-width="1" opacity="${f1(k)}" transform="translate(${f1(x)} ${f1(y)}) scale(${f1(.5 + .5 * k)})" d="${STAR}"/>`;
      }
    }
    if (fc.orbit) {
      for (let i = 0; i < 3; i++) {
        const a = t * 3.2 + i * 2.094, sn = Math.sin(a);
        s += `<path fill="#ffd23f" stroke="#3a2f7a" stroke-width="1.6" stroke-linejoin="round" opacity="${sn < 0 ? .55 : 1}" transform="translate(${f1(top[0] + 56 * Math.cos(a))} ${f1(top[1] - 4 + 10 * sn)}) scale(${sn < 0 ? .7 : 1})" d="M0 -7L2 -2L7 -2L3 1L4.5 6.5L0 3.3L-4.5 6.5L-3 1L-7 -2L-2 -2Z"/>`;
      }
    }
    if (fc.listen) {
      for (let i = 0; i < 3; i++) {
        const p = (t * .9 + i / 3) % 1, r = 36 - 24 * p, c = at(210, 112);
        s += `<path fill="none" stroke="${ac}" stroke-width="5" stroke-linecap="round" opacity="${f1(Math.sin(Math.PI * p))}" d="M${f1(c[0] + r * Math.cos(-.55))} ${f1(c[1] + r * Math.sin(-.55))}A${f1(r)} ${f1(r)} 0 0 1 ${f1(c[0] + r * Math.cos(.55))} ${f1(c[1] + r * Math.sin(.55))}"/>`;
      }
    }
    if (fc.think) {
      for (let i = 0; i < 3; i++) {
        const k = (t * .8 + i / 3) % 1;
        s += `<circle fill="#f1ecff" stroke="${ac}" stroke-width="3" cx="${f1(side[0] + 10 * i)}" cy="${f1(side[1] - 20 * i - 6 * k)}" r="${4 + 3 * i}" opacity="${f1(.4 + .6 * Math.sin(Math.PI * k))}"/>`;
      }
    }
    if (fc.sweat) {
      const c = at(190, 92 + 3 * Math.sin(t * 7));
      s += `<path fill="#8fd0ff" stroke="#2f5fae" stroke-width="1.4" transform="translate(${f1(c[0])} ${f1(c[1])}) scale(1.4)" d="M0 -9C4 -3 6 0 6 3.5A6 6 0 0 1 -6 3.5C-6 0 -4 -3 0 -9Z"/>`;
    }
    if (fc.anger) {
      const c = at(186, 64), k = 1 + .12 * Math.sin(t * 10);
      s += `<g transform="translate(${f1(c[0])} ${f1(c[1])}) scale(${f1(k)})" fill="none" stroke="#e5484d" stroke-width="5" stroke-linecap="round"><path d="M-11 -3Q-3 -3 -3 -11M3 -11Q3 -3 11 -3M11 3Q3 3 3 11M-3 11Q-3 3 -11 3"/></g>`;
    }
    if (fc.bang) {
      const c = at(200, 40);
      s += `<g transform="translate(${f1(c[0])} ${f1(c[1])})"><path fill="none" stroke="#2c2350" stroke-width="8" stroke-linecap="round" d="M0 -16V3"/><circle fill="#2c2350" cx="0" cy="14" r="4.5"/></g>`;
    }
    if (fc.question) {
      const c = at(200, 40), k = 1 + .06 * Math.sin(t * 3);
      s += `<g transform="translate(${f1(c[0])} ${f1(c[1])}) scale(${f1(k)})"><path fill="none" stroke="#2c2350" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" d="M-8 -9Q-8 -19 0 -19Q9 -19 9 -11Q9 -4 0 -1V4"/><circle fill="#2c2350" cx="0" cy="14" r="4.5"/></g>`;
    }
    if (fx !== s) { fxG.innerHTML = s; fx = s; }
  }

  return {
    draw,
    groupTilt,
    gestures: ['nod', 'shake', 'wave', 'bow'],
    setScheme,
    snapshot(fc, o, res = 3, frames = 60) {
      fixedRes = res;
      const g = document.createElementNS(SVGNS, 'g');
      for (let i = 0; i < frames; i++) draw(g, fc, { ...o, t: (o.t || 0) + i / 60 });
      const href = canvas.toDataURL('image/png');
      rig.dispose();
      rig = null; mountedIn = null; fixedRes = 0;
      return `<image href="${href}" x="${VIEW[0]}" y="${VIEW[1]}" width="${VIEW[2] - VIEW[0]}" height="${VIEW[3] - VIEW[1]}"/>`;
    },
    dispose() {
      rig?.dispose();
      rig = null; canvas = null; fo = null; fxG = null; mountedIn = null;
    },
    reset() {
      endFade();
      for (const k in sp) { sp[k].x = 0; sp[k].v = 0; }
      lastT = null; rootWas = {}; armWas = {}; prevTilt = 0; prevYaw = 0; prevLow = 0; headTilt = 0; wTilt = 0; wLean = 0;
      haloMood = 0; haloGlow = 0; sitK = 0; walkK = 0; runK = 0; swingK = 0; prevAir = 0; seatK = 0; seatWas = 0; seatBurst = -9;
      prevLook = null; prevShut = 0; Object.assign(hl, { dx: 0, dy: 0, scale: 1, quiver: 0, alpha: 1 });
    },
    preload: () => Promise.all(SCHEMES.flatMap(sc => OUTFITS.map(of => loadScheme(sc.id, of.id)))),
    get scheme() { return `${scheme}-${outfit}`; },
    get painted() { return decoded || Promise.resolve(); },
    get colors() { return { z: accent() }; },
    schemes: SCHEMES,
    anchors: (() => {
      const e = feat.eyes.eyeL, cx = (e.iris[0] + e.iris[2]) / 2, cy = (e.iris[1] + e.iris[3]) / 2;
      return { gaze: [U(cx), V(cy)], tear: [U(cx), V(e.ball[3])], tears: [[U(cx), V(e.ball[3])], [U(cx), V(e.ball[3])]], z: [192, 46],
        hearts: [92, 172, 56], bubble: [128, 14] };
    })(),
    model,
  };
}

/** The pack's entry (figure.json): her body for the figure frame, the kit's body drawn by her figure. */
export async function createMornyeBody(base, opts) {
  return opts.kit.createBody(opts.host, { figure: await createMornyeFigure(base, opts) });
}
