"""Assemble the figure pack, mirrored so she faces right (the kit's convention).
All inputs are in the master's pixel frame as drawn (she faces left there); every texture is flipped and every
x coordinate becomes 1024 - x."""
import json
import numpy as np, os, shutil
from PIL import Image, ImageOps
B, PK = '/tmp/pet/build/', '/tmp/pet/pack/mornye/'
keep = {f: open(PK + f).read() for f in ('figure.js', 'figure.json') if os.path.exists(PK + f)}
shutil.rmtree(PK, ignore_errors=True)
for d in ('tex', 'feat', 'thumbs'): os.makedirs(PK + d)
for f, txt in keep.items(): open(PK + f, 'w').write(txt)
P = json.load(open(B + 'parts.json')); F = json.load(open(B + 'feat.json'))
WM = 1024
mx = lambda x: WM - x
S, FEET = 0.24, 997
X0 = WM - 485                       # the body's middle, mirrored
U = lambda x: round(128 + (x - X0) * S, 2)
V = lambda y: round(256 - (FEET - y) * S, 2)
pv = lambda x, y: [U(mx(x)), V(y)]  # a point given in the drawn (unmirrored) frame
sit = P['sit']
# elbows: half way from the shoulder pivot to the hand's centre, along the drawn arm
_L = np.load(B + 'labels_final.npz')
def _elbow(lab, sh):
    m = _L[lab]; ys, xs = np.nonzero(m); y1 = ys.max(); sel = ys > y1 - 34
    hx, hy = xs[sel].mean(), ys[sel].mean()
    return (sh[0] + .5 * (hx - sh[0]), sh[1] + .5 * (hy - sh[1])), (hx, hy)
EL_N, HAND_N = _elbow('arm_far', P['shoulder']['arm_far'])
EL_F, HAND_F = _elbow('arm_near', (382, 606))
print('elbows', EL_N, EL_F)
pivots = {
    'body': [128.0, 256.0], 'waist': pv(487, 760), 'neck': pv(490, 548),
    # near arm = the one on the left once mirrored (drawn on the right); far arm = the one with the bracelet
    'armNear': pv(*P['shoulder']['arm_far']), 'elbowNear': pv(*EL_N), 'elbowFar': pv(*EL_F), 'armFar': pv(382, 606),
    'legBack': pv(533, 812), 'legFront': pv(437, 812),
    'halo': pv(497, 63), 'earring': pv(641, 481), 'head': pv(470, 420),
    'seat': pv(*sit['seatC']), 'seatRing': pv(*sit['ringC']),
}
# part id in the pack <- (texture built in the drawn frame, z, parent deformer, grid)
SPEC = [
    ('seat', 'seat', .5, 'seat', [8, 8]),
    ('hair_back', 'hair_back', 1, 'hairSway', [8, 14]),
    ('hair_back_sit', 'hair_back_sit', 1.01, 'hairSway', [8, 14]),
    ('coat', 'coat', 2, 'coat', [10, 6]),
    ('leg_back', 'leg_far', 3.5, 'legBack', [3, 10]),      # drawn on the right, mirrored to the image-left: her near leg, drawn over the other
    ('leg_front', 'leg_near', 3, 'legFront', [3, 10]),
    ('torso', 'torso', 5, 'waist', [6, 6]),
    ('lower_sit', 'lower_sit', 5.3, 'lowerSit', [8, 6]),
    ('arm_far', 'arm_near', 5.6, 'armFar', [8, 14]),      # the bracelet arm
    ('arm_near', 'arm_far', 6, 'armNear', [8, 14]),
    ('shoulder_cap', 'shoulder_cap', 6.05, 'waist', [2, 2]),
    ('face', 'face', 8, 'headMid', [6, 6]),
    ('bangs', 'bangs', 13, 'bangsSway', [10, 10]),
    ('lash_tip', 'lash_tip', 13.2, 'headFeat', [2, 2]),
    ('earring', 'earring', 13.5, 'earring', [2, 6]),
    ('halo', 'halo', 15, 'halo', [8, 2]),
]
import numpy as np, cv2
def despeckle(im, minarea):
    a = np.asarray(im.convert('RGBA')).copy()
    m = (a[..., 3] > 10).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(m, 8)
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] < minarea: a[lab == i, 3] = 0
    return Image.fromarray(a)
parts = []
for pid, src, z, parent, grid in SPEC:
    x, y, w, h = P['boxes'][src]
    im = Image.open(B + f'tex_{src}.png')
    im = despeckle(im, 6)
    ImageOps.mirror(im).save(PK + f'tex/{pid}.png')
    xm = mx(x + w)
    parts.append({'id': pid, 'tex': pid, 'z': z, 'parent': parent, 'grid': grid,
                  'box': [U(xm), V(y), round(w * S, 2), round(h * S, 2)]})
# face features: flip the sprites, mirror their boxes and the eye's lid/rim curves
mbox = lambda b: [mx(b[2]), b[1], mx(b[0]), b[3]]
def mpoly(c):  # p(x) = a x^2 + b x + c  ->  p(1024 - x)
    a, b, k = c
    return [a, -2 * WM * a - b, a * WM * WM + WM * b + k]
for f in os.listdir(B + 'feat'):
    ImageOps.mirror(Image.open(B + 'feat/' + f)).save(PK + 'feat/' + f)
eyes = {}
for k, e in F['eyes'].items():
    eyes[k] = {n: (mbox(v) if n not in ('lidFit', 'rimFit') else mpoly(v)) for n, v in e.items()}
sprites = {n: mbox(b) for n, b in F['sprites'].items()}
model = {
    'units': {'S': S, 'X0': X0, 'FEET': FEET},
    'pivots': pivots,
    'parts': parts,
    'feat': {'eyes': eyes, 'sprites': sprites, 'scale': F.get('scale', 1)},
    'face': {'x': mx(296 + 252), 'y': 356, 'w': 252, 'h': 192},
    'cheeks': [[mx(372), 500, 34, 16], [mx(556), 505, 16, 10]],
    'mouth': [mx(487), 507],
    'schemes': [{'id': 'mornye', 'label': '星光', 'accent': '#8B6CF6', 'ready': True, 'eyeHighlights': True}],
    'outfits': [{'id': 'coat', 'deformers': {'earring': {'parent': 'headMid', 'pivot': pivots['earring'], 'gain': 1}}}],
    'view': [-12, -8, 268, 272],
}
json.dump(model, open(PK + 'model.json', 'w'), indent=1, ensure_ascii=False)
im = ImageOps.mirror(Image.open(B + 'rest.png'))
bb = im.getbbox(); cx = (bb[0] + bb[2]) // 2; side = max(bb[2] - bb[0], bb[3] - bb[1]) + 20
im.crop((cx - side // 2, bb[1] - 10, cx + side // 2, bb[1] - 10 + side)).resize((288, 288), Image.LANCZOS).save(PK + 'thumbs/mornye.png')
im.crop((324, 60, 724, 460)).resize((144, 144), Image.LANCZOS).save(PK + 'thumbs/coat.png')
print(json.dumps(pivots))
