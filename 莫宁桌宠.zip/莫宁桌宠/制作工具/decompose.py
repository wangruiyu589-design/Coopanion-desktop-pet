"""Cut the master into rig parts. Visible pixels come from the master; what a part needs under higher
parts (its hidden completion) comes from the registered edit images."""
import sys, json, numpy as np, cv2
sys.path.insert(0, '/tmp/pet/tools')
from matte import matte
from reg import register
from PIL import Image
SRC, OUT = '/tmp/pet/src/', '/tmp/pet/build/'
M = matte(SRC + 'master.png').astype(np.float32)
H, W = M.shape[:2]
aM = M[..., 3] / 255.
yy, xx = np.mgrid[0:H, 0:W]

def load(name, mask=None):
    E = matte(SRC + name + '.png')
    Wm, cc, out = register(M.astype(np.uint8), E, mask)
    if Wm is None or abs(Wm[0, 2]) > 6 or abs(Wm[1, 2]) > 6 or abs(Wm[0, 0] - 1) > .02:
        print(f'  {name}: registration rejected ({cc:.3f}), using identity'); out = E
    else:
        print(f'  {name}: cc={cc:.3f} t=({Wm[0,2]:.2f},{Wm[1,2]:.2f})')
    return out.astype(np.float32)

def diff(A, B):
    """colour distance where both are opaque; 255 where only one is."""
    d = np.sqrt(((A[..., :3] - B[..., :3]) ** 2).sum(-1))
    both = (A[..., 3] > 128) & (B[..., 3] > 128)
    return np.where(both, d, 255.)

def clean(m, k=2, minarea=60):
    m = m.astype(np.uint8)
    if k: m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((k, k), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m, 8)
    keep = np.zeros_like(m)
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] >= minarea: keep[lab == i] = 1
    return keep.astype(bool)

def largest(m):
    n, lab, st, _ = cv2.connectedComponentsWithStats(m.astype(np.uint8), 8)
    if n < 2: return m.astype(bool)
    i = 1 + np.argmax(st[1:, cv2.CC_STAT_AREA]); return lab == i

def fill_holes(m):
    m = m.astype(np.uint8); h, w = m.shape
    ff = m.copy(); mask = np.zeros((h + 2, w + 2), np.uint8); cv2.floodFill(ff, mask, (0, 0), 1)
    return (m | (1 - ff)).astype(bool)

print('registering edits')
E_hb = load('e_hairback_a'); E_bg = load('e_bangs_a'); E_na = load('e_noarms_a')
E_lg = load('r_legs_a'); E_nl = load('r_nolegs_a')
E_fc = matte(SRC + 'e_face_b.png').astype(np.float32)   # different content: identity (checked by overlay)

T = 34  # colour tolerance: "this edit explains the master pixel here"
op = aM > .5
ROI = lambda x0, y0, x1, y1: (xx >= x0) & (xx < x1) & (yy >= y0) & (yy < y1)

halo = op & (yy < 99)
earring = op & ROI(624, 478, 672, 590) & (diff(M, E_hb) > T) & (diff(M, E_bg) > T)
earring = clean(earring, 0, 30)
bangs_full = E_bg[..., 3] > 128
bangs = op & bangs_full & (diff(M, E_bg) < T) & ~earring & ~halo
bangs = clean(bangs, 2, 40)
hb_full = E_hb[..., 3] > 128
hairlike = (diff(M, E_hb) < T)
# arms: traced along the master's outlines (sleeve, cuff, hand), a rounded cap at the shoulder
PL = [(356, 618), (363, 606), (378, 598), (394, 598), (404, 606), (403, 618), (401, 625), (399, 635), (397, 645), (393, 656),
      (390, 665), (386, 675), (382, 685), (378, 695), (374, 705), (370, 714), (365, 724), (360, 733), (352, 744), (346, 752),
      (343, 760), (342, 772), (337, 785), (325, 795), (306, 795), (290, 787), (279, 773), (272, 753), (272, 738), (282, 728),
      (296, 722), (300, 714), (303, 702), (306, 692), (315, 682), (326, 672), (338, 662), (346, 652), (353, 642), (356, 630)]
PR = [(586, 606), (598, 597), (613, 594), (624, 601), (631, 612), (635, 624), (634, 636), (637, 646), (646, 657), (653, 668),
      (661, 680), (670, 690), (678, 700), (685, 712), (687, 722), (684, 732), (687, 744), (689, 754), (681, 761), (671, 763),
      (671, 776), (669, 795), (659, 807), (640, 807), (624, 799), (615, 782), (611, 766), (603, 759), (595, 753), (590, 744),
      (588, 724), (587, 704), (585, 690), (582, 676), (579, 664), (577, 652), (580, 638), (583, 622)]
R_, G_, B_ = M[..., 0], M[..., 1], M[..., 2]
lum_ = .3 * R_ + .59 * G_ + .11 * B_
def polymask(P):
    m = np.zeros((H, W), np.uint8); cv2.fillPoly(m, [np.array(P, np.int32)], 1)
    inner = m.astype(bool)
    ring = cv2.dilate(m, np.ones((5, 5), np.uint8)).astype(bool) & ~inner & (lum_ < 165)   # the outline stroke just outside
    return (inner | ring) & op
import os as _os, json as _json
ISO = _json.load(open('/tmp/pet/src/iso_choice.json')) if _os.path.exists('/tmp/pet/src/iso_choice.json') else {}
def isomask(name, P):
    if name not in ISO: return polymask(P)
    E = matte(SRC + ISO[name] + '.png')
    a = E[..., 3] > 128
    pm = np.zeros((H, W), np.uint8); cv2.fillPoly(pm, [np.array(P, np.int32)], 1)
    near = cv2.dilate(pm, np.ones((31, 31), np.uint8)).astype(bool)      # trust the edit only around where the arm is
    m = a & near & op
    if name == 'arm_near':   # the bracelet arm: the edit also kept a strip of the coat's inner panel; the trace bounds it
        m &= cv2.dilate(pm, np.ones((7, 7), np.uint8)).astype(bool)
    n_, lab_, st_, _ = cv2.connectedComponentsWithStats(m.astype(np.uint8), 8)
    m = lab_ == (1 + np.argmax(st_[1:, 4]))
    ff = m.astype(np.uint8).copy(); mk = np.zeros((H + 2, W + 2), np.uint8); cv2.floodFill(ff, mk, (0, 0), 1)
    return (m | (ff == 0)) & op
arm_near = isomask('arm_near', PL)
arm_far = isomask('arm_far', PR)
face = op & ROI(318, 300, 660, 545) & ~bangs & ~earring & ~hairlike
face = fill_holes(largest(clean(face, 2, 100))) & op & ~bangs & ~earring
legs = op & ROI(370, 790, 610, 1010) & (diff(M, E_nl) > T) & ((diff(M, E_lg) < T + 10) | (yy > 830)) & ~arm_near & ~arm_far
legs = fill_holes(largest(clean(legs, 3, 300)) | clean(legs, 3, 300)) & op
hair = op & hb_full & hairlike & ~bangs & ~face & ~arm_near & ~arm_far & ~legs & ~earring & ~halo
rest = op & ~(halo | earring | bangs | arm_near | arm_far | face | legs | hair)
Y_SPLIT = 760
def near_core(m, core):
    n, lab, st, _ = cv2.connectedComponentsWithStats(m.astype(np.uint8), 8)
    keep = np.zeros(m.shape, bool)
    for i in range(1, n):
        c = lab == i
        if (c & core).any(): keep |= c
    return keep
torso = near_core(rest & (yy < Y_SPLIT), ROI(380, 540, 610, Y_SPLIT))
coat = near_core(rest & (yy >= Y_SPLIT), ROI(270, Y_SPLIT, 730, 960))
hair = hair | (rest & ~torso & ~coat)   # stray outline bits go with the hair

labels = {'hair_back': hair, 'coat': coat, 'legs': legs, 'arm_far': arm_far, 'torso': torso, 'arm_near': arm_near,
          'face': face, 'earring': earring, 'bangs': bangs, 'halo': halo}
np.savez_compressed(OUT + 'labels.npz', **{k: v for k, v in labels.items()})
# a label map picture
cols = {'hair_back': (200, 200, 255), 'coat': (120, 60, 200), 'legs': (40, 160, 255), 'arm_far': (255, 160, 0), 'torso': (255, 80, 80),
        'arm_near': (255, 220, 0), 'face': (255, 200, 170), 'earring': (0, 255, 255), 'bangs': (150, 255, 150), 'halo': (255, 0, 255)}
vis = np.full((H, W, 3), 30, np.uint8)
for k, m in labels.items(): vis[m] = cols[k]
un = op & ~np.any(np.stack(list(labels.values())), 0)
vis[un] = (255, 255, 255)
Image.fromarray(vis).save(OUT + 'labels.png')
print({k: int(v.sum()) for k, v in labels.items()}, 'unassigned', int(un.sum()))
