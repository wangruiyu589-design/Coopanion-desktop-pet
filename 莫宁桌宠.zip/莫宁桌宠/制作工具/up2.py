"""2x output: a layer built at 1024 is resampled at 2048. Where the layer shows the master (or another source)
as drawn, colour and soft edge come from the upscaled source; elsewhere (painted-in fills, fades) from a smooth
premultiplied upscale of the layer."""
import numpy as np, cv2

def premul_up(img, k=2):
    a = img[..., 3:4] / 255.
    p = np.concatenate([img[..., :3] * a, a], -1).astype(np.float32)
    h, w = img.shape[:2]
    p2 = cv2.resize(p, (w * k, h * k), interpolation=cv2.INTER_CUBIC)
    a2 = np.clip(p2[..., 3:4], 0, 1)
    rgb2 = np.where(a2 > 1e-3, p2[..., :3] / np.maximum(a2, 1e-3), 0)
    return np.concatenate([np.clip(rgb2, 0, 255), a2 * 255], -1)

def up2(layer, src1, src2, tol=10, k=2):
    """layer, src1: float RGBA at 1024 (src1 = the image the layer was copied from); src2: the same source at 2048."""
    base = premul_up(layer, k)
    direct = (np.abs(layer[..., :3] - src1[..., :3]).max(-1) < tol) & (layer[..., 3] > 0) & (src1[..., 3] > 0)
    ratio = np.where(direct, np.clip(layer[..., 3] / np.maximum(src1[..., 3], 1), 0, 1), 0).astype(np.float32)
    h, w = layer.shape[:2]
    d2 = cv2.resize(direct.astype(np.float32), (w * k, h * k), interpolation=cv2.INTER_LINEAR)
    r2 = cv2.resize(ratio, (w * k, h * k), interpolation=cv2.INTER_LINEAR)
    wgt = np.clip((d2 - .25) / .5, 0, 1)[..., None]
    hq = src2.astype(np.float32).copy()
    hq[..., 3] = hq[..., 3] * np.clip(r2 / np.maximum(d2, 1e-3), 0, 1)
    out = wgt * hq + (1 - wgt) * base
    return np.clip(out, 0, 255)
