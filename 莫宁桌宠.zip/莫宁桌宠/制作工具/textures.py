"""Build each part's texture: master pixels where it is visible, completion from the edits where a higher part
covers it, a few pixels of margin under higher neighbours (no seams when parts move)."""
import sys, json, numpy as np, cv2
sys.path.insert(0, '/tmp/pet/tools')
from matte import matte
from reg import register
from PIL import Image
SRC, OUT = '/tmp/pet/src/', '/tmp/pet/build/'
M = matte(SRC + 'master.png').astype(np.float32)
H, W = M.shape[:2]
yy, xx = np.mgrid[0:H, 0:W]
L = {k: v for k, v in np.load(OUT + 'labels.npz').items()}

def load(name):
    E = matte(SRC + name + '.png')
    Wm, cc, out = register(M.astype(np.uint8), E)
    return (out if Wm is not None and abs(Wm[0, 2]) < 6 and abs(Wm[1, 2]) < 6 else E).astype(np.float32)
E_hb, E_bg, E_na, E_lg, E_nl = load('e_hairback_a'), load('e_bangs_a'), load('e_noarms_a'), load('r_legs_a'), load('r_nolegs_a')
E_fc = matte(SRC + 'e_face_b.png').astype(np.float32)
ROI = lambda x0, y0, x1, y1: (xx >= x0) & (xx < x1) & (yy >= y0) & (yy < y1)
op = M[..., 3] > 128

# ---- split the hair: the fringe and crown above the chin go with the head, the locks below with the long hair
CHIN = 548
Y_SPLIT = 760
SHOULDER = {'arm_near': (382, 606), 'arm_far': (602, 612)}
SH_R1, SH_R2 = 12, 42
fringe = L['bangs'] & (yy < CHIN)
locks = L['bangs'] & (yy >= CHIN)
L['bangs'] = fringe
L['hair_back'] = L['hair_back'] | locks
# legs: near (image left) and far by the gap between them
legs = L.pop('legs')
SPLIT_X = 487
L['leg_near'] = legs & (xx < SPLIT_X)
L['leg_far'] = legs & (xx >= SPLIT_X)

# the fringe's outline strokes over the skin belong to the fringe (else they stay behind when it sways)
r0, g0, b0 = M[..., 0], M[..., 1], M[..., 2]
skinlike = (r0 > 190) & (g0 > 140) & (b0 > 110) & (r0 - b0 > 20)
FEATBOX = ROI(322, 383, 452, 488) | ROI(468, 496, 504, 515) | ROI(473, 472, 486, 484) | ROI(385, 487, 407, 508)
dist_b = cv2.distanceTransform((~L['bangs']).astype(np.uint8), cv2.DIST_L2, 3)
stroke = L['face'] & ~skinlike & ~FEATBOX & (dist_b <= 40) & (yy < 512)
L['face'] &= ~stroke; L['bangs'] |= stroke
# back-hair pixels inside the face (the fringe's strands and outline crossing the skin) are the fringe's too
face_hull = cv2.morphologyEx(L['face'].astype(np.uint8), cv2.MORPH_CLOSE, np.ones((25, 25), np.uint8)).astype(bool)
head_ext = ((E_fc[..., 3] > 128) | face_hull) & ROI(300, 280, 680, CHIN)
inner = L['hair_back'] & head_ext
L['hair_back'] &= ~inner; L['bangs'] |= inner
np.savez_compressed(OUT + 'labels_final.npz', **L)
Z = {'hair_back': 1, 'coat': 2, 'leg_near': 3, 'leg_far': 3.5, 'arm_far': 5.6, 'torso': 5, 'arm_near': 6, 'face': 8, 'bangs': 13, 'earring': 13.5, 'halo': 15}
zmap = np.zeros((H, W), np.float32)  # z of what the master shows; 0 = nothing
for k, m in L.items(): zmap[m] = Z[k]

def nearest_fill(tex, region, src_mask=None, blur=0):
    """Fill `region` with the colour of the nearest pixel of src_mask (default: the opaque pixels)."""
    a = (tex[..., 3] > 128) if src_mask is None else src_mask
    if not a.any() or not region.any(): return tex
    _, lab = cv2.distanceTransformWithLabels((~a).astype(np.uint8), cv2.DIST_L2, 5, labelType=cv2.DIST_LABEL_PIXEL)
    ys, xs = np.where(a)
    idx = np.zeros(lab.max() + 1, np.int64)
    # label ids of the zero (source) pixels, in scan order
    idx[lab[ys, xs]] = np.arange(len(ys))
    sel = idx[lab[region]]
    t = tex.copy()
    t[region, :3] = tex[ys[sel], xs[sel], :3]
    t[region, 3] = 255
    if blur:
        w = (t[..., 3] > 128).astype(np.float32)
        b = cv2.GaussianBlur(t[..., :3] * w[..., None], (0, 0), blur) / np.maximum(cv2.GaussianBlur(w, (0, 0), blur), 1e-3)[..., None]
        t[region, :3] = b[region]
    return t

def extend(tex, region, r):
    """Grow `tex` r px into `region` with the colours of its own edge (hidden margin)."""
    a = tex[..., 3] > 128
    grow = cv2.dilate(a.astype(np.uint8), np.ones((2 * r + 1, 2 * r + 1), np.uint8)).astype(bool) & region & ~a
    return nearest_fill(tex, grow) if grow.any() else tex

def build(name, full=None, src=None, margin=4, extra=None):
    """full: where the part exists (visible ∪ hidden); src: image that shows it where hidden."""
    z = Z[name]; vis = L[name]
    tex = np.zeros((H, W, 4), np.float32)
    tex[vis] = M[vis]
    if full is not None and src is not None:
        hid = full & ~vis & (zmap > z) & (src[..., 3] > 128)
        if name in ('torso', 'coat'):
            body_hull = cv2.morphologyEx((L['torso'] | L['coat'] | L['arm_near'] | L['arm_far']).astype(np.uint8), cv2.MORPH_CLOSE, np.ones((41, 41), np.uint8)).astype(bool)
            hid &= body_hull
            # what the edit painted that is just the long hair belongs to the hair layer; thin slivers are seams
            hairish = (E_hb[..., 3] > 128) & (np.sqrt(((src[..., :3] - E_hb[..., :3]) ** 2).sum(-1)) < 40)
            hid &= ~hairish
            hid = cv2.morphologyEx(hid.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8)).astype(bool)
        if name == 'coat':  # thin stray strokes the edit left where the boots were
            hid = cv2.morphologyEx(hid.astype(np.uint8), cv2.MORPH_OPEN, np.ones((7, 7), np.uint8)).astype(bool)
        tex[hid] = src[hid]; tex[hid, 3] = 255
    # margin under higher parts (and under the master's own soft edge it keeps the master's alpha)
    tex = extend(tex, (zmap > z), margin)
    if extra is not None: tex = extend(tex, extra, 40)
    return tex

T = {}
T['halo'] = build('halo', margin=0)
T['earring'] = build('earring', margin=0)
T['bangs'] = build('bangs', E_bg[..., 3] > 128, E_bg)
# fade the fringe's lower cut into the long hair below it, where both are hair
band = np.clip((CHIN + 2 - yy) / 26., 0, 1)
cut = L['bangs'] & (yy > CHIN - 30) & ~(cv2.dilate(L['face'].astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool))
T['bangs'][..., 3] = np.where(cut, T['bangs'][..., 3] * band, T['bangs'][..., 3])
T['hair_back'] = build('hair_back', E_hb[..., 3] > 128, E_hb, margin=6)
# under the fringe's fading band the long hair needs the master's hair (the band shows both)
fb = cut & (band < 1)
T['hair_back'][fb] = M[fb]

# face: skin under the fringe filled from the face's own skin (the bald edit gives the extent only)
face_ext = (E_fc[..., 3] > 128) & (yy < CHIN + 4) | L['face']
face_ext &= ROI(300, 280, 680, CHIN + 4)
ft = np.zeros((H, W, 4), np.float32); ft[L['face']] = M[L['face']]
need = face_ext & ~L['face'] & (zmap > Z['face'])
# erase the features (eye, lashes, mouth, nose dot) so the live face texture draws them instead
FEAT = {'eye': (322, 383, 452, 488), 'mouth': (468, 496, 504, 515), 'nose': (473, 472, 486, 484)}
# the beauty mark under the eye is painted out for good (user request); no sprite draws it back
MOLE = (388, 489, 405, 506)
feat = np.zeros((H, W), bool)
for (x0, y0, x1, y1) in FEAT.values(): feat |= ROI(x0, y0, x1, y1)
feat |= ROI(*MOLE)
feat &= L['face']
r_, g_, b_ = M[..., 0], M[..., 1], M[..., 2]
skin_src = L['face'] & ~feat & (r_ > 200) & (g_ > 150) & (b_ > 120) & (r_ - b_ > 25)
skin_src = cv2.erode(skin_src.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
ft = nearest_fill(ft, need | feat, skin_src, blur=6)
# the visible part of the erased features: a smooth (Navier-Stokes) fill from the skin around, no box edges
vis_fill = feat & ~need
base = np.ascontiguousarray(np.where(skin_src[..., None], M[..., :3], ft[..., :3]).clip(0, 255).astype(np.uint8))
inp = cv2.inpaint(base, vis_fill.astype(np.uint8), 12, cv2.INPAINT_NS).astype(np.float32)
inp = cv2.GaussianBlur(inp, (0, 0), 2.5)
wv = cv2.GaussianBlur(vis_fill.astype(np.float32), (0, 0), 2)
near_f = (wv > 0) & skin_src
ft[near_f, :3] = ft[near_f, :3] * (1 - wv[near_f, None]) + inp[near_f] * wv[near_f, None]
ft[vis_fill, :3] = inp[vis_fill]
np.savez_compressed(OUT+'dbg.npz', need=need, feat=feat, face=L['face'], bangs=L['bangs'], zmap=zmap, fa=ft[...,3])
T['face'] = extend(ft, zmap > Z['face'], 4)
T['face_master'] = np.where(L['face'][..., None], M, 0)  # the face as drawn, for cutting the features

# torso: completion behind the arms and the hair from the no-arms edit; neck grows up under the chin
tfull = (E_na[..., 3] > 128) & ROI(250, 530, 740, 790) & ~L['face'] & ~(yy >= 790)
T['torso'] = build('torso', tfull, E_na, margin=5, extra=ROI(430, 500, 560, 560) & (zmap >= Z['face']))
# the coat below the split: behind the legs from the no-legs edit, behind hands/hair from the no-arms edit
cfull_nl = (E_nl[..., 3] > 128) & ROI(250, 720, 745, 1005)
cfull_na = (E_na[..., 3] > 128) & ROI(250, 720, 745, 1005) & ~ROI(375, 790, 600, 1010)
coat_src = np.where((cfull_nl & ROI(372, 785, 605, 1010))[..., None], E_nl, E_na)
T['coat'] = build('coat', cfull_nl | cfull_na, coat_src, margin=6)
# the coat reaches up under the torso, so bowing or swinging never shows a gap at the cut
T['coat'] = extend(T['coat'], ROI(250, 700, 745, 770) & cv2.erode(L['torso'].astype(np.uint8), np.ones((7, 7), np.uint8)).astype(bool), 30)
# legs: thighs under the shirt/coat from the full-legs edit (only where a higher part covers them)
lfull = (E_lg[..., 3] > 128) & ROI(372, 770, 605, 1010)
for k in ('leg_near', 'leg_far'):
    side = (xx < SPLIT_X) if k == 'leg_near' else (xx >= SPLIT_X)
    T[k] = build(k, lfull & side, E_lg, margin=4)
# under each arm: the single-arm removal edit shows the whole picture there (coat side + hair behind).
# split it into body vs hair by colour, keep the coat's outline with the coat, and use it for both layers.
import os as _os
SH_R1, SH_R2 = 6, 22
BODY_O = {}
BODY = {}
for arm, ed in (('arm_near', 'r_nonear'), ('arm_far', 'r_nofar')):
    if not _os.path.exists(SRC + ed + '.png'): continue
    R_ = load(ed)
    # pixels next to the arm that the removal edit changed are the arm's own (its outline, the hand's rim):
    # they go with the arm, so moving it leaves nothing of it behind
    near7 = cv2.dilate(L[arm].astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool)
    other = 'arm_far' if arm == 'arm_near' else 'arm_near'
    dRM = np.abs(R_[..., :3] - M[..., :3]).max(-1)
    extra = near7 & ~L[arm] & ~L[other] & ~L['face'] & (M[..., 3] > 100) & ((dRM > 55) | (R_[..., 3] < 60))
    for k_ in L:
        if k_ != arm: L[k_] = L[k_] & ~extra
    L[arm] = L[arm] | extra
    zmap[extra] = Z[arm]
    print(arm, 'outline px moved to the arm', int(extra.sum()))
    A = cv2.dilate(L[arm].astype(np.uint8), np.ones((15, 15), np.uint8)).astype(bool) & (R_[..., 3] > 8)
    A &= ~cv2.dilate(L['face'].astype(np.uint8), np.ones((5, 5), np.uint8)).astype(bool)
    r, g, b = R_[..., 0], R_[..., 1], R_[..., 2]; lum = .3 * r + .59 * g + .11 * b
    hair_c = (b - r > 8) & (lum > 140) & (R_[..., 3] > 128)
    body_c = ((r - b > -6) & (lum > 150) & (R_[..., 3] > 128)) | ((r - b > 25) & (lum > 60))
    body_c |= (b - r > 30) & (r < 150)
    body_c &= ~hair_c
    body_c = cv2.morphologyEx(body_c.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8)).astype(bool)
    anchor = (L['torso'] | L['coat']) & ~A
    n, lab = cv2.connectedComponents((body_c & (A | anchor)).astype(np.uint8))
    keep = np.unique(lab[anchor & body_c]); keep = keep[keep > 0]
    body = np.isin(lab, keep)
    body = cv2.morphologyEx(body.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8)).astype(bool)
    dark = (lum < 140) & (R_[..., 3] > 60)
    body_o = body | (cv2.dilate(body.astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool) & dark)
    body_o = cv2.morphologyEx(body_o.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8)).astype(bool)
    body_o &= A
    px, py = SHOULDER[arm]
    core = np.hypot(xx - px, yy - py) < SH_R1 + 4
    m0 = body_o & ~core
    for part, rows in (('torso', yy < Y_SPLIT + 6), ('coat', yy >= Y_SPLIT - 50)):
        m = m0 & rows
        T[part][m] = R_[m]; T[part][m, 3] = np.where(R_[m, 3] > 200, 255, R_[m, 3])
    out = A & ~body_o & ~core & ~(L['torso'] | L['coat'])
    for part in ('torso', 'coat'): T[part][out, 3] = 0
    hm = A & ~body & (R_[..., 3] > 8)
    T['hair_back'][hm] = R_[hm]
    # where the edit shows nothing (below the hair tips, beside the coat), nothing may be left behind the arm
    A0 = cv2.dilate(L[arm].astype(np.uint8), np.ones((15, 15), np.uint8)).astype(bool) & ~L['face']
    empty = A0 & (R_[..., 3] < 40)
    for part in ('hair_back', 'torso', 'coat'):
        e_ = empty & ~L[part]
        T[part][e_, 3] = 0
    np.savez_compressed(OUT + f'dbg_{arm}.npz', A=A, body=body, body_o=body_o)
    BODY_O[arm] = body_o | ((L['torso'] | L['coat']) & ~A)
    BODY[arm] = cv2.erode(body.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
T['arm_far'] = build('arm_far', margin=0)
T['arm_near'] = build('arm_near', margin=0)
# ---- the waving arm (drawn right, label arm_far) hangs from a real shoulder joint:
# the coat's shoulder pad above the sleeve's fold line stays with the body as its own cap layer over the arm,
# the arm turns about the top of the sleeve just below that fold, and its top is a round socket that turns in place
FOLD = lambda x: 633 - .5 * (x - 608)
cap = L['arm_far'] & (yy < FOLD(xx) + 1)
row = L['arm_far'][660]; xs_ = np.where(row)[0]
PIVOT = (int(round(xs_.mean())), int(round(FOLD(xs_.mean()) + 12)))
R0 = 24
capT = np.zeros((H, W, 4), np.float32); capT[cap] = M[cap]
# soft lower edge: 2 px under the fold line, so the fold's dark line stays crisp on top of the sleeve
low = L['arm_far'] & (yy >= FOLD(xx) + 1) & (yy < FOLD(xx) + 3)
capT[low] = M[low]; capT[low, 3] *= .5
T['shoulder_cap'] = capT; Z['shoulder_cap'] = 6.05
ta = T['arm_far']
disk = np.hypot(xx - PIVOT[0], yy - PIVOT[1]) < R0
keep_arm = (L['arm_far'] & (yy >= FOLD(xx) - 3)) | disk
ta[~keep_arm, 3] = 0
need_ = disk & ~(L['arm_far'] & (yy >= FOLD(xx) - 3))
src_ = L['arm_far'] & (yy >= FOLD(xx) + 4) & (np.hypot(xx - PIVOT[0], yy - PIVOT[1]) < R0 + 12)
lumA = .3 * M[..., 0] + .59 * M[..., 1] + .11 * M[..., 2]
src_ &= lumA > 200
ta = nearest_fill(ta, need_, src_, blur=3)
T['arm_far'] = ta
SHOULDER['arm_far'] = PIVOT
print('shoulder pivot', PIVOT, 'cap px', int(cap.sum()))
for arm in ('arm_near',):
    px, py = SHOULDER[arm]
    d = np.hypot(xx - px, yy - py)
    under = cv2.erode(BODY_O[arm].astype(np.uint8), np.ones((5, 5), np.uint8)).astype(bool) if arm in BODY_O else np.ones((H, W), bool)
    fade = np.clip((d - SH_R1) / (SH_R2 - SH_R1), 0, 1) ** 1.5
    T[arm][..., 3] *= np.where(under, fade, 1)
    zone = L[arm] & (d < SH_R2) & under & BODY.get(arm, under)
    T['torso'][zone] = M[zone]; T['torso'][zone, 3] = np.maximum(M[zone, 3], 0)
# long hair: crack lines the edit left where the body hides it at rest -> inpaint them
hb = T['hair_back']; hid = (zmap > 1) & ~L['hair_back']
hid = cv2.erode(hid.astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool)
lum_h = (.3 * hb[..., 0] + .59 * hb[..., 1] + .11 * hb[..., 2]).astype(np.float32)
bh = cv2.morphologyEx(lum_h, cv2.MORPH_BLACKHAT, np.ones((9, 9), np.uint8))
crack = hid & (bh > 18) & (hb[..., 3] > 128)
crack = cv2.dilate(crack.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool) & hid
rgb = np.ascontiguousarray(hb[..., :3].clip(0, 255).astype(np.uint8))
rgb = cv2.inpaint(rgb, crack.astype(np.uint8), 5, cv2.INPAINT_TELEA)
hb[crack, :3] = rgb[crack]
# above the chin the fringe covers the long hair; keep the long hair's outline tucked inside the fringe
bang_in = cv2.erode((T['bangs'][..., 3] > 200).astype(np.uint8), np.ones((11, 11), np.uint8)).astype(bool)
tuck = (yy < CHIN - 30) & ~L['hair_back'] & ~bang_in & (T['bangs'][..., 3] > 0)
# (no tuck: the long hair moves with the fringe near the chin, see figure.js hairSway)
print('cracks inpainted', int(crack.sum()), 'tucked', int(tuck.sum()))
# drawn frame: arm_near = the bracelet arm on the image left, arm_far = the one on the image right
# a clean outline along the cut at the shoulder (where the trace crosses the coat, not an outline of the drawing)
def cap_outline(tex, mask, ink=(92, 94, 120)):
    edge = mask & ~cv2.erode(mask.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)
    lumM = .3 * M[..., 0] + .59 * M[..., 1] + .11 * M[..., 2]
    cut = edge & (lumM > 170)
    cut = cv2.dilate(cut.astype(np.uint8), np.ones((2, 2), np.uint8)).astype(bool) & mask
    t2 = tex.copy(); t2[cut, 0], t2[cut, 1], t2[cut, 2] = ink; t2[cut, 3] = 235
    return t2

# the lash flicks are drawn over the hair at the eye's outer corner: they leave the fringe for a part of their own
# above it, which the face hides whenever the eye is not the open drawn eye (closed, > <, hearts, spirals...)
lumM = .3 * M[..., 0] + .59 * M[..., 1] + .11 * M[..., 2]
tipbox = ROI(318, 375, 382, 445)
tip = tipbox & (T['bangs'][..., 3] > 30) & (lumM < 125) & (M[..., 0] > M[..., 2] + 4)
n_, lab_, st_, _ = cv2.connectedComponentsWithStats(tip.astype(np.uint8), 8)
tip = np.isin(lab_, [i for i in range(1, n_) if st_[i, 4] >= 6])
ring_ = cv2.dilate(tip.astype(np.uint8), np.ones((5, 5), np.uint8)).astype(bool) & tipbox & ~tip
fillm = cv2.dilate(tip.astype(np.uint8), np.ones((5, 5), np.uint8)).astype(bool) & tipbox
bg_rgb = np.ascontiguousarray(T['bangs'][..., :3].clip(0, 255).astype(np.uint8))
bg_rgb = cv2.inpaint(bg_rgb, fillm.astype(np.uint8), 4, cv2.INPAINT_TELEA).astype(np.float32)
lt = np.zeros((H, W, 4), np.float32)
lt[tip] = M[tip]; lt[tip, 3] = 255
lumF = .3 * bg_rgb[..., 0] + .59 * bg_rgb[..., 1] + .11 * bg_rgb[..., 2]
ink = np.array([62, 36, 34], np.float32)
aa = np.clip((lumF - lumM) / np.maximum(lumF - 70, 1), 0, 1)
r_ = ring_ & (aa > .04)
lt[r_, :3] = ink; lt[r_, 3] = aa[r_] * 255
T['bangs'][fillm, :3] = bg_rgb[fillm]
T['lash_tip'] = lt
Z['lash_tip'] = 13.2
print('lash tip px', int(tip.sum()))
# where the fringe fades into the long hair, nothing between them may show through
for k in T:
    if k in ('bangs', 'hair_back', 'face_master', 'halo', 'earring', 'lash_tip'): continue
    T[k][fb, 3] = 0
# ---- save cropped textures + boxes (master px); tex_ at 2x for the pack, tex1_ at 1x for the checks
from up2 import up2
HQ = matte(SRC + 'hq2048.png').astype(np.float32)
boxes = {}
for k, t in T.items():
    a = t[..., 3] > 3
    if not a.any(): print('EMPTY', k); continue
    ys, xs = np.where(a); x0, y0, x1, y1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    x0, y0 = max(0, x0 - 2), max(0, y0 - 2); x1, y1 = min(W, x1 + 2), min(H, y1 + 2)
    crop = t[y0:y1, x0:x1]
    Image.fromarray(crop.clip(0, 255).astype(np.uint8)).save(OUT + f'tex1_{k}.png')
    big = up2(crop, M[y0:y1, x0:x1], HQ[2 * y0:2 * y1, 2 * x0:2 * x1])
    Image.fromarray(big.round().astype(np.uint8)).save(OUT + f'tex_{k}.png')
    boxes[k] = [int(x0), int(y0), int(x1 - x0), int(y1 - y0)]
json.dump({'shoulder': {'arm_far': list(SHOULDER['arm_far'])}, 'boxes': boxes, 'z': Z, 'chin': CHIN, 'splitx': SPLIT_X, 'feat': FEAT}, open(OUT + 'parts.json', 'w'), indent=1)
# ---- rest-pose check: composite in z order and compare with the master
comp = np.zeros((H, W, 4), np.float32)
for k in sorted(Z, key=Z.get):
    x0, y0, w, h = boxes[k]; t = np.asarray(Image.open(OUT + f'tex1_{k}.png')).astype(np.float32)
    if k == 'face':  # the live face draws the features back
        t = t.copy(); fm = T['face_master'][y0:y0 + h, x0:x0 + w]; fe = feat[y0:y0 + h, x0:x0 + w]; t[fe] = fm[fe]
    a = t[..., 3:] / 255.; dst = comp[y0:y0 + h, x0:x0 + w]
    dst[..., :3] = t[..., :3] * a + dst[..., :3] * (1 - a); dst[..., 3:] = a * 255 + dst[..., 3:] * (1 - a)
d = np.abs(comp[..., :3] - M[..., :3]).max(-1) * (M[..., 3] > 200)
print('rest-pose max diff', d.max(), ' pixels >12:', int((d > 12).sum()), ' of', int(op.sum()))
Image.fromarray(comp.clip(0, 255).astype(np.uint8)).save(OUT + 'rest.png')
print(json.dumps(boxes))
