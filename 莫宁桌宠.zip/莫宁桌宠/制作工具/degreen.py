import numpy as np, glob, sys
from PIL import Image
n_tot = 0
for f in glob.glob(sys.argv[1] + '/**/*.png', recursive=True):
    im = np.asarray(Image.open(f).convert('RGBA')).astype(np.int32)
    r, g, b, a = im[..., 0], im[..., 1], im[..., 2], im[..., 3]
    green = (g > np.maximum(r, b) + 18) & (a > 0)
    if green.any():
        n_tot += int(green.sum())
        im[..., 1] = np.where(green, np.maximum(r, b), g)
        # strongly green (background that leaked in): drop it
        strong = green & (g > np.maximum(r, b) + 60)
        im[..., 3] = np.where(strong, 0, a)
        Image.fromarray(im.astype(np.uint8)).save(f)
print('fixed px', n_tot)
