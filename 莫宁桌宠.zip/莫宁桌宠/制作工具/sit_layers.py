"""Sitting layers: the floating seat (shell + ring) and her lower body seated, all in the master's frame."""
import sys, json, numpy as np, cv2
sys.path.insert(0, '/tmp/pet/tools')
from matte import matte
from reg import register
from PIL import Image
SRC, OUT = '/tmp/pet/src/', '/tmp/pet/build/'
M = matte(SRC + 'master.png')
H, W = M.shape[:2]; yy, xx = np.mgrid[0:H, 0:W]
S = matte(SRC + 'sit.png')
up = ((M[..., 3] > 128) & (S[..., 3] > 128) & (yy < 700)).astype(np.uint8) * 255
Ws, cc, S = register(M, S, up); print('sit -> master', round(cc, 3), np.round(Ws[:, 2], 2).tolist())
def to_sit(name):
    E = matte(SRC + name)
    Wm, c2, out = register(S, E)
    ok = Wm is not None and abs(Wm[0, 2]) < 6 and abs(Wm[1, 2]) < 6
    print(name, '->sit', round(c2, 3) if ok else 'identity')
    return (out if ok else E)
SEAT = to_sit('seat_only_a.png').astype(np.float32)
NOSEAT = to_sit('sit_noseat_a.png').astype(np.float32)
a = SEAT[..., 3] > 128
n, lab, st, cen = cv2.connectedComponentsWithStats(a.astype(np.uint8), 8)
comps = sorted(range(1, n), key=lambda i: -st[i, 4])
shell = lab == comps[0]
ring = np.zeros_like(shell)
for i in comps[1:]:
    if st[i, 4] > 30: ring |= lab == i      # the ring and its little stars below the shell
print('shell px', int(shell.sum()), 'ring px', int(ring.sum()))
out = {}
from up2 import up2, premul_up
import os as _os
def hq_aligned(path, ref):
    """An upscaled source aligned to the 2x of `ref` (a 1024 layer already in the master frame)."""
    if not _os.path.exists(path): return premul_up(ref)
    X = matte(path)
    if X.shape[0] != 2 * H: X = np.asarray(Image.fromarray(X).resize((2 * W, 2 * H), Image.LANCZOS))
    ref2 = premul_up(ref).round().clip(0, 255).astype(np.uint8)
    Wm, cc, o = register(ref2, X)
    ok = Wm is not None and abs(Wm[0, 2]) < 12 and abs(Wm[1, 2]) < 12
    print('  hq', _os.path.basename(path), round(cc, 3) if ok else 'kept unaligned')
    return (o if ok else X).astype(np.float32)
def save(name, img, mask, src2=None, src1=None):
    t = np.zeros((H, W, 4), np.float32); t[mask] = img[mask]
    ys, xs = np.where(t[..., 3] > 3)
    x0, y0, x1, y1 = max(0, xs.min() - 2), max(0, ys.min() - 2), min(W, xs.max() + 3), min(H, ys.max() + 3)
    crop = t[y0:y1, x0:x1]
    Image.fromarray(crop.clip(0, 255).astype(np.uint8)).save(OUT + f'tex1_{name}.png')
    big = up2(crop, (img if src1 is None else src1)[y0:y1, x0:x1], src2[2 * y0:2 * y1, 2 * x0:2 * x1]) if src2 is not None else premul_up(crop)
    Image.fromarray(big.round().clip(0, 255).astype(np.uint8)).save(OUT + f'tex_{name}.png')
    out[name] = [int(x0), int(y0), int(x1 - x0), int(y1 - y0)]
SEAT2 = hq_aligned(SRC + 'hq_seat_only_a.png', SEAT)
save('seat', SEAT, shell, SEAT2)
save('seat_ring', SEAT, ring, SEAT2)
# her lower body seated: coat drape, thighs, legs, boots; no hair, no hands (her own arms are drawn by the arm parts)
NOSEAT_RAW = NOSEAT.copy()   # as edited, before the hand holes are filled (the 2x source must not bring the hands back)
R, G, B = NOSEAT[..., 0], NOSEAT[..., 1], NOSEAT[..., 2]
poly = np.zeros((H, W), np.uint8)
cv2.fillPoly(poly, [np.array([(262, 700), (420, 690), (560, 688), (700, 696), (712, 860), (600, 880), (450, 960), (330, 960), (262, 840)], np.int32)], 1)
skin = (R > 200) & (G > 150) & (B > 120) & (R - B > 30) & (R - G > 12)
handbox = ((xx < 360) & (yy < 775)) | ((xx > 600) & (yy < 780))
hand = skin & handbox
hand = cv2.dilate(hand.astype(np.uint8), np.ones((9, 9), np.uint8)).astype(bool) & handbox
hairish = (B - R > 4) & (np.abs(R - G) < 14) & (R > 175) & (R < 238)   # pale lavender
hair_edge = (xx < 300) | (xx > 690)
lower = (NOSEAT[..., 3] > 128) & poly.astype(bool) & ~hand & ~(hairish & hair_edge)
n, lab, st, _ = cv2.connectedComponentsWithStats(lower.astype(np.uint8), 8)
keep = np.zeros_like(lower)
for i in range(1, n):
    if st[i, 4] > 400: keep |= lab == i
lower = keep
# the holes the hands left: filled with the cloth around them
hull = cv2.morphologyEx(lower.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((25, 25), np.uint8)).astype(bool)
ff = hull.astype(np.uint8).copy(); mk = np.zeros((H + 2, W + 2), np.uint8); cv2.floodFill(ff, mk, (0, 0), 1); hull |= (ff == 0)
holes = hull & ~lower & (yy >= 712) & poly.astype(bool)
cloth = lower & ~(((R + G + B) / 3) < 120)      # light cloth, not the dark lining or outlines
_, lb = cv2.distanceTransformWithLabels((~cloth).astype(np.uint8), cv2.DIST_L2, 5, labelType=cv2.DIST_LABEL_PIXEL)
ys_, xs_ = np.where(cloth); ix = np.zeros(lb.max() + 1, np.int64); ix[lb[ys_, xs_]] = np.arange(len(ys_))
sel = ix[lb[holes]]
NOSEAT[holes, :3] = NOSEAT[ys_[sel], xs_[sel], :3]; NOSEAT[holes, 3] = 255
blur = cv2.GaussianBlur(NOSEAT[..., :3], (0, 0), 3); NOSEAT[holes, :3] = blur[holes]
lower |= holes
# soft top edge: the seated thighs fade in over the torso's lower edge
img = NOSEAT.copy()
fade = np.clip((yy - 700) / 14., 0, 1)
img[..., 3] = img[..., 3] * np.where(yy < 714, fade, 1)
NOSEAT2 = hq_aligned(SRC + 'hq_sit_noseat_a.png', NOSEAT_RAW)
save('lower_sit', img, lower, NOSEAT2, NOSEAT_RAW)
# pivots (master px): the seat's centre, the ring's centre, her hips when seated
ys, xs = np.where(shell); seatC = [float(xs.mean()), float(ys.mean())]
ys, xs = np.where(ring); ringC = [float(xs.mean()), float(ys.mean())]
P = json.load(open(OUT + 'parts.json'))
P['boxes'].update(out)
P['z'].update({'seat_ring': .3, 'seat': .5, 'lower_sit': 5.3})
P['sit'] = {'seatC': seatC, 'ringC': ringC, 'hip': [470, 760]}
json.dump(P, open(OUT + 'parts.json', 'w'), indent=1)
print(out, seatC, ringC)
# a composite of the seated pose for checking
L = json.load(open(OUT + 'parts.json'))
comp = Image.new('RGBA', (W, H), (255, 255, 255, 255))
skip = {'coat', 'leg_near', 'leg_far', 'face_master'}
for k in sorted(L['z'], key=L['z'].get):
    if k in skip or k not in L['boxes']: continue
    x0, y0, w, h = L['boxes'][k]
    comp.alpha_composite(Image.open(OUT + f'tex1_{k}.png'), (x0, y0))
comp.save(OUT + 'sit_rest.png')
# long hair while seated: where the sit drawing shows the seat (cushion, front rim), the hair tips are behind it
Pb = json.load(open(OUT + 'parts.json'))
hx, hy, hw, hh = Pb['boxes']['hair_back']
HB1 = np.asarray(Image.open(OUT + 'tex1_hair_back.png')).astype(np.float32)
HB2 = np.asarray(Image.open(OUT + 'tex_hair_back.png')).astype(np.float32)
Sf = S.astype(np.float32)
seat_vis = shell & (S[..., 3] > 128) & (np.abs(Sf[..., :3] - SEAT[..., :3]).max(-1) < 36)
seat_vis = cv2.morphologyEx(seat_vis.astype(np.uint8), cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
seat_vis = cv2.dilate(seat_vis, np.ones((5, 5), np.uint8)).astype(bool) & (yy > 720)
keep1 = (~seat_vis[hy:hy + hh, hx:hx + hw]).astype(np.float32)
keep1 = cv2.GaussianBlur(keep1, (0, 0), 1.2)
a1 = HB1.copy(); a1[..., 3] *= keep1
k2 = cv2.resize(keep1, (HB2.shape[1], HB2.shape[0]), interpolation=cv2.INTER_LINEAR)
a2 = HB2.copy(); a2[..., 3] *= k2
Image.fromarray(a1.round().clip(0, 255).astype(np.uint8)).save(OUT + 'tex1_hair_back_sit.png')
Image.fromarray(a2.round().clip(0, 255).astype(np.uint8)).save(OUT + 'tex_hair_back_sit.png')
Pb['boxes']['hair_back_sit'] = [hx, hy, hw, hh]; Pb['z']['hair_back_sit'] = 1.01
json.dump(Pb, open(OUT + 'parts.json', 'w'), indent=1)
print('hair tips hidden by the seat', int(seat_vis.sum()))
