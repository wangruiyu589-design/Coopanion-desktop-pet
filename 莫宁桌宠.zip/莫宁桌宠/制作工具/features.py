"""Face features: the near eye split into ball / iris / highlight / lash with fitted lid and rim curves,
and whole sprites (eye, mouth) for each expression edit. All in master pixels."""
import sys, json, numpy as np, cv2
sys.path.insert(0, '/tmp/pet/tools')
from matte import matte
from reg import register
from PIL import Image
SRC, OUT = '/tmp/pet/src/', '/tmp/pet/build/'
M = matte(SRC + 'master.png').astype(np.float32)
H, W = M.shape[:2]; yy, xx = np.mgrid[0:H, 0:W]
P = json.load(open(OUT + 'parts.json'))
# the blank face in master coordinates
fx0, fy0, fw, fh = P['boxes']['face']
blank = np.zeros((H, W, 4), np.float32)
blank[fy0:fy0 + fh, fx0:fx0 + fw] = np.asarray(Image.open(OUT + 'tex1_face.png')).astype(np.float32)
os = __import__('os'); os.makedirs(OUT + 'feat', exist_ok=True)
from up2 import up2
HQ = matte(SRC + 'hq2048.png').astype(np.float32)
blank2 = np.zeros((2 * H, 2 * W, 4), np.float32)
blank2[2 * fy0:2 * (fy0 + fh), 2 * fx0:2 * (fx0 + fw)] = np.asarray(Image.open(OUT + 'tex_face.png')).astype(np.float32)

from up2 import premul_up
def save(name, img, box, src1=None, src2=None, smooth=False):
    x0, y0, x1, y1 = box
    crop = img[y0:y1, x0:x1]
    if src2 is None: src1, src2 = M, HQ
    if smooth:   # drawn by us (no master pixels to borrow): plain premultiplied upscale, then a clean alpha edge
        big = premul_up(crop)
        a = cv2.GaussianBlur(big[..., 3], (0, 0), .8); big[..., 3] = np.clip((a - 128) * 1.6 + 128, 0, 255)
    else:
        big = up2(crop, src1[y0:y1, x0:x1], src2[2 * y0:2 * y1, 2 * x0:2 * x1])
    Image.fromarray(big.round().clip(0, 255).astype(np.uint8)).save(OUT + f'feat/{name}.png')

def bbox(m, pad=2):
    ys, xs = np.where(m); return [int(xs.min()) - pad, int(ys.min()) - pad, int(xs.max()) + 1 + pad, int(ys.max()) + 1 + pad]

R, G, B = M[..., 0], M[..., 1], M[..., 2]
lum = .3 * R + .59 * G + .11 * B
EB = (xx >= 322) & (xx < 452) & (yy >= 383) & (yy < 490)
# ---- the eye: iris ellipse (measured), lid = the lash's lower edge (parabola), rim = the opening's lowest pixels
ICX, ICY, IAX, IAY = 414.5, 445.0, 31.5, 37.0
iris_ell = ((xx - ICX) / (IAX + .8)) ** 2 + ((yy - ICY) / (IAY + .8)) ** 2 <= 1
iris_tight = ((xx - ICX) / (IAX - .4)) ** 2 + ((yy - ICY) / (IAY - .4)) ** 2 <= 1
LIDPTS = [(364, 433), (367, 429), (370, 425), (373, 421), (376, 419), (379, 417), (382, 416), (400, 415), (415, 415), (421, 416), (435, 418), (447, 423), (452, 427)]
lidFit = np.polyfit([p[0] for p in LIDPTS], [p[1] for p in LIDPTS], 2).tolist()
lid = lambda x: np.polyval(lidFit, x)
sclera_c = EB & (lum > 200) & (np.abs(R - B) < 30) & (G > 195)
X0E, X1E = 360, 456
below = (yy >= lid(xx)) & (xx >= X0E) & (xx <= X1E)
body = below & (sclera_c | iris_ell)
cols = [x for x in range(X0E, X1E + 1) if body[:, x].any()]
bot = np.array([np.where(body[:, x])[0].max() for x in cols], float)
rimFit = np.polyfit(np.array(cols, float)[2:-2], bot[2:-2], 2).tolist()
rim = lambda x: np.polyval(rimFit, x)
open_ = below & (yy <= rim(xx) + 1)
dark_line = (lum < 150) & ~((R > 190) & (G > 140))
keep = sclera_c | iris_ell | dark_line
keep = cv2.morphologyEx(keep.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8)).astype(bool)
n_, lab_, st_, _ = cv2.connectedComponentsWithStats((open_ & keep).astype(np.uint8), 8)
open_ = lab_ == (1 + np.argmax(st_[1:, 4]))
ff_ = open_.astype(np.uint8).copy(); mk_ = np.zeros((H + 2, W + 2), np.uint8); cv2.floodFill(ff_, mk_, (0, 0), 1); open_ = open_ | (ff_ == 0)
ball_box = bbox(open_ | (iris_ell & below), 2)
iris = iris_tight & (yy >= lid(xx) - 10)
iris_box = bbox(iris, 1)
# highlights: near-white blobs inside the iris
inner_ell = ((xx - ICX) / (IAX * .82)) ** 2 + ((yy - ICY) / (IAY * .85)) ** 2 <= 1
hl = iris & inner_ell & (lum > 226)
hl = cv2.dilate(hl.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool) & iris
hl_box = bbox(hl, 2)
def nearest(img, region, src):
    _, lb = cv2.distanceTransformWithLabels((~src).astype(np.uint8), cv2.DIST_L2, 5, labelType=cv2.DIST_LABEL_PIXEL)
    ys, xs = np.where(src); ix = np.zeros(lb.max() + 1, np.int64); ix[lb[ys, xs]] = np.arange(len(ys))
    s_ = ix[lb[region]]; img[region, :3] = M[ys[s_], xs[s_], :3]
# iris without its highlights; above the lid (hidden under the lash) the iris's top colour carries on
iris_img = np.zeros((H, W, 4), np.float32); iris_img[iris] = M[iris]; iris_img[iris, 3] = 255
known = iris & ~hl & (yy >= lid(xx) + 2)
nearest(iris_img, iris & ~known, known)
bl = cv2.GaussianBlur(iris_img[..., :3], (0, 0), 2.0); fix = iris & ~known; iris_img[fix, :3] = bl[fix]
hl_img = np.zeros((H, W, 4), np.float32); hl_img[hl] = M[hl]; hl_img[hl, :3] = 255
hl_img[hl, 3] = np.clip((lum[hl] - 200) / 40, 0, 1) * 255
# the ball: a clean, smooth eye-white over the whole opening (colour by row from the drawn sclera), soft lid shade
om = cv2.GaussianBlur(open_.astype(np.float32), (0, 0), 1.0) > .5
ball_img = np.zeros((H, W, 4), np.float32)
scl = om & ~iris_ell & sclera_c & ~((R < 225) & (B > R + 4))
rows = {}
for y in range(int(ball_box[1]), int(ball_box[3])):
    r_ = scl[y]; 
    if r_.sum() >= 3: rows[y] = np.median(M[y, r_, :3], 0)
ys_ = sorted(rows); base = np.array([rows[y] for y in ys_])
for y in range(int(ball_box[1]), int(ball_box[3])):
    c_ = np.array([np.interp(y, ys_, base[:, k]) for k in range(3)])
    ball_img[y, om[y], :3] = c_; ball_img[y, om[y], 3] = 255
ball_img[..., :3] = cv2.GaussianBlur(ball_img[..., :3], (0, 0), 1.5)
d_lid = np.clip((yy - lid(xx)) / 10., 0, 1); ball_img[..., :3] *= (.86 + .14 * d_lid)[..., None]
# the eye's outline along the rim (dark ring of the opening's lower edge), drawn over the iris
ring = open_ & (yy >= rim(xx) - 3) & (lum < 150)
rim_img = np.zeros((H, W, 4), np.float32); rim_img[ring] = M[ring]
# a thin drawn outline round the sides and bottom of the opening (the smooth ball has none of its own)
edge = om & ~cv2.erode(om.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool) & (yy > lid(xx) + 3) & ~ring
rim_img[edge, :3] = (118, 92, 104); rim_img[edge, 3] = 170
# lash: every dark stroke of the eye box outside the opening (upper lash with flicks, lower lash dots)
lash = EB & ~open_ & (lum < 160) & ~((R > 190) & (G > 140)) & ~(iris_ell & (yy >= lid(xx) - 1))
lash &= ((R - B > 14) | (lum < 75))
n_l, lab_l, st_l, _ = cv2.connectedComponentsWithStats(lash.astype(np.uint8), 8)
lash = np.isin(lab_l, [i for i in range(1, n_l) if st_l[i, 4] >= 60])
lash_img = np.zeros((H, W, 4), np.float32); lash_img[lash] = M[lash]
lash_img[lash, 3] = np.clip((205 - lum[lash]) / 55, 0, 1) * 255
# one more px of lash under its lower edge, so no light seam shows between the lash and the lid line
seam = cv2.dilate(lash.astype(np.uint8), np.array([[0, 0, 0], [0, 1, 0], [0, 1, 0]], np.uint8)).astype(bool) & ~lash & (yy < lid(xx) + 3)
lash_img[seam] = M[seam]; lash_img[seam, 3] = 200
lash = lash | seam
lash_box = bbox(lash, 2)
for nm, im, bx in [('eyeL_iris', iris_img, iris_box), ('eyeL_hl', hl_img, hl_box), ('eyeL_lash', lash_img, lash_box)]:
    save(nm, im, bx)
# the ball and its outline drawn at 2x straight from the fitted curves: an almond between the lid and the rim parabolas
def vec_layers(box):
    x0, y0, x1, y1 = box; Hh, Ww = 2 * (y1 - y0), 2 * (x1 - x0)
    gy, gx = np.mgrid[0:Hh, 0:Ww]; X = x0 + (gx + .5) / 2; Y = y0 + (gy + .5) / 2
    # the drawn opening, extended up under the lash, smoothed into a clean curve at 2x
    cols_ = open_.any(0)
    top = (yy >= lid(xx) - 3) & (yy <= rim(xx)) & cols_[None, :] & cv2.dilate(open_.astype(np.uint8), np.ones((1, 9), np.uint8)).astype(bool)
    m1 = (open_ | top).astype(np.float32)[y0:y1, x0:x1]
    m2 = cv2.resize(m1, (Ww, Hh), interpolation=cv2.INTER_CUBIC)
    m2 = cv2.GaussianBlur(m2, (0, 0), 2.2)
    a = np.clip((m2 - .5) * 3.2 + .5, 0, 1)
    col = np.zeros((Hh, Ww, 3), np.float32)
    for k in range(3): col[..., k] = np.interp(Y, ys_, base[:, k])
    col *= (.86 + .14 * np.clip((Y - lid(X)) / 10., 0, 1))[..., None]
    ball = np.dstack([col, a * 255])
    # outline: a thin line just inside the contour, round the sides and bottom (under the lash it fades out)
    inside = (m2 > .5).astype(np.uint8)
    din = cv2.distanceTransform(inside, cv2.DIST_L2, 5)
    oa = np.clip(1 - np.abs(din - 1.2) / 1.3, 0, 1) * inside * np.clip((Y - lid(X) - 2) / 6, 0, 1)
    out = np.dstack([np.broadcast_to(np.array([96, 70, 82], np.float32), (Hh, Ww, 3)), oa * 210])
    return ball, out
vb, vo = vec_layers(ball_box)
Image.fromarray(vb.round().clip(0, 255).astype(np.uint8)).save(OUT + 'feat/eyeL_ball.png')
rim_img[edge, 3] = 0
save('eyeL_rim', rim_img, ball_box)
r2 = np.asarray(Image.open(OUT + 'feat/eyeL_rim.png')).astype(np.float32)
a1, a2 = r2[..., 3:] / 255, vo[..., 3:] / 255
comb_a = a1 + a2 * (1 - a1); comb = (r2[..., :3] * a1 + vo[..., :3] * a2 * (1 - a1)) / np.maximum(comb_a, 1e-3)
Image.fromarray(np.dstack([comb, comb_a * 255]).round().clip(0, 255).astype(np.uint8)).save(OUT + 'feat/eyeL_rim.png')
eyes = {'eyeL': {'lash': lash_box, 'ball': ball_box, 'iris': iris_box, 'hl': hl_box, 'rim': ball_box, 'lidFit': lidFit, 'rimFit': rimFit}}

# ---- sprites: what each expression edit drew over the blank face
LF = np.load(OUT + 'labels_final.npz')
FACE_REGION = (blank[..., 3] > 128) & ~LF['bangs'] & ~LF['hair_back'] & (yy < 524)
def cut(img, region, lo=.16, hi=.34):
    """Colour-to-alpha against the blank face: the least opacity that explains the edit over the skin.
    Ink lines come out opaque, a slightly different skin tone comes out transparent."""
    bg = np.clip(blank[..., :3], 1, 254); c = img[..., :3]
    a_dn = np.where(c < bg, (bg - c) / bg, 0)
    a_up = np.where(c > bg, (c - bg) / (255 - bg), 0)
    a = np.maximum(a_dn, a_up).max(-1)
    a = np.clip((a - lo) / (hi - lo), 0, 1) * a          # drop the faint differences, keep the true opacity of the rest
    a = a * region
    a = cv2.morphologyEx((a > .04).astype(np.uint8), cv2.MORPH_OPEN, np.ones((2, 2), np.uint8)) * a
    safe = np.maximum(a, 1e-3)[..., None]
    fg = np.clip((c - (1 - safe) * bg) / safe, 0, 255)
    out = np.zeros_like(img); out[..., :3] = fg; out[..., 3] = a * 255
    return out, a > .04
NOSE_BOX = (xx >= 462) & (xx < 497) & (yy >= 460) & (yy < 492)
MOLE_BOX = (xx > 378) & (xx < 414) & (yy > 484) & (yy < 512)
EYE_R = FACE_REGION & (xx >= 300) & (xx < 470) & (yy >= 360) & (yy < 500) & ~MOLE_BOX & ~NOSE_BOX
MOUTH_R = FACE_REGION & (xx >= 440) & (xx < 540) & (yy >= 492) & (yy < 540) & ~NOSE_BOX
NOSE_R = (blank[..., 3] > 128) & (xx >= 470) & (xx < 490) & (yy >= 468) & (yy < 488)
sprites = {}
EYE_CORE = ((xx - 395) / 82.) ** 2 + ((yy - 440) / 64.) ** 2 <= 1
def cut2(img2, region2, lo=.16, hi=.34):
    bg = np.clip(blank2[..., :3], 1, 254); c = img2[..., :3]
    a_dn = np.where(c < bg, (bg - c) / bg, 0); a_up = np.where(c > bg, (c - bg) / (255 - bg), 0)
    a = np.maximum(a_dn, a_up).max(-1)
    a = np.clip((a - lo) / (hi - lo), 0, 1) * a * region2
    safe = np.maximum(a, 1e-3)[..., None]
    fg = np.clip((c - (1 - safe) * bg) / safe, 0, 255)
    out = np.zeros_like(img2); out[..., :3] = fg; out[..., 3] = a * 255
    return out
INK_ONLY = {'dizzy_eyeL', 'drag_eyeL', 'happy_eyeL', 'sleep_eyeL'}
# closed-eye arcs sit where the open eye's upper lid is (the edit drew the smile arc too low on the face)
INK_Y = {'happy_eyeL': 424, 'sleep_eyeL': 436}   # drawn as dark lines only: no skin, hair or highlight patches around them
def ink(o):
    l = .3 * o[..., 0] + .59 * o[..., 1] + .11 * o[..., 2]
    o[..., 3] *= np.clip((150 - l) / 45., 0, 1)
    return o
def add(name, img, region, img2=None):
    out, m = cut(img, region)
    if name in INK_ONLY:
        out = ink(out); m &= out[..., 3] > 10
        n_, lab_, st_, _ = cv2.connectedComponentsWithStats(m.astype(np.uint8), 8)
        if n_ > 1:
            big = 1 + int(np.argmax(st_[1:, cv2.CC_STAT_AREA])); keepc = lab_ == big
            out[~keepc, 3] = 0; m &= keepc
    dy = 0
    if name in INK_Y:
        lum_ = .3 * out[..., 0] + .59 * out[..., 1] + .11 * out[..., 2]
        ys_ = np.nonzero((out[..., 3] > 200) & (lum_ < 90))[0]
        dy = int(round(INK_Y[name] - ys_.mean())); out = np.roll(out, dy, 0); m = np.roll(m, dy, 0)
        print(name, 'moved', dy, 'px')
    lum_o = .3 * out[..., 0] + .59 * out[..., 1] + .11 * out[..., 2]
    if name.endswith('_eyeL'):
        stray = m & ~EYE_CORE & (lum_o > 115)
        out[stray, 3] = 0; m &= ~stray
    n_, lab_, st_, _ = cv2.connectedComponentsWithStats(m.astype(np.uint8), 8)
    for i in range(1, n_):
        if st_[i, cv2.CC_STAT_AREA] < 25: out[lab_ == i, 3] = 0; m[lab_ == i] = False
    if m.sum() < 4: print('empty sprite', name); return
    bx = bbox(m, 3); sprites[name] = bx
    x0, y0, x1, y1 = bx
    if img2 is None:
        save(name, out, bx, out, None); return
    if dy: img2 = np.roll(img2, 2 * dy, 0)
    keep2 = cv2.resize(cv2.dilate(m.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(np.float32), (2 * W, 2 * H), interpolation=cv2.INTER_LINEAR)
    o2 = cut2(img2, keep2)
    if name in INK_ONLY: o2 = ink(o2)
    Image.fromarray(o2[2 * y0:2 * y1, 2 * x0:2 * x1].round().clip(0, 255).astype(np.uint8)).save(OUT + f'feat/{name}.png')
add('neutral_mouth', M, MOUTH_R, HQ)
out_, m_ = cut(M, NOSE_R, .05, .2)
if m_.sum() >= 3:
    bxn = bbox(m_, 3); sprites['nose'] = bxn
    o2 = cut2(HQ, cv2.resize(cv2.dilate(m_.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(np.float32), (2 * W, 2 * H)), .05, .2)
    Image.fromarray(o2[2 * bxn[1]:2 * bxn[3], 2 * bxn[0]:2 * bxn[2]].round().clip(0, 255).astype(np.uint8)).save(OUT + 'feat/nose.png')
for x in ['happy', 'sleep', 'drag', 'love', 'dizzy', 'surprised']:
    E = matte(SRC + f'x_{x}.png')
    Wm, cc, out = register(M.astype(np.uint8), E)
    E = (out if Wm is not None and abs(Wm[0, 2]) < 4 else E).astype(np.float32)
    E2 = None
    if os.path.exists(SRC + f'hq_x_{x}.png'):
        e2 = matte(SRC + f'hq_x_{x}.png')
        if e2.shape[0] != 2 * H: e2 = np.asarray(Image.fromarray(e2).resize((2 * W, 2 * H), Image.LANCZOS))
        W2, c2, o2 = register(HQ.astype(np.uint8), e2)
        E2 = (o2 if W2 is not None and abs(W2[0, 2]) < 8 else e2).astype(np.float32)
    add(f'{x}_eyeL', E, EYE_R, E2)
    add(f'{x}_mouth', E, MOUTH_R, E2)
json.dump({'eyes': eyes, 'sprites': sprites, 'scale': 2}, open(OUT + 'feat.json', 'w'), indent=1)
print(json.dumps(eyes)); print(json.dumps(sprites))
# ---- clean 2x edges for the iris (an anti-aliased ellipse) and the highlights (smoothed blobs)
def _grid(box):
    x0, y0, x1, y1 = box; Hh, Ww = 2 * (y1 - y0), 2 * (x1 - x0)
    gy, gx = np.mgrid[0:Hh, 0:Ww]; return x0 + (gx + .5) / 2, y0 + (gy + .5) / 2
X_, Y_ = _grid(iris_box)
r_ = np.sqrt(((X_ - ICX) / (IAX - .4)) ** 2 + ((Y_ - ICY) / (IAY - .4)) ** 2)
ell_a = np.clip((1 - r_) * (IAX - .4) * 2 + .5, 0, 1)
ir = np.asarray(Image.open(OUT + 'feat/eyeL_iris.png')).astype(np.float32)
top_a = np.clip((Y_ - (lid(X_) - 10)) * 2 + .5, 0, 1)
ir[..., 3] = 255 * ell_a * top_a
Image.fromarray(ir.round().clip(0, 255).astype(np.uint8)).save(OUT + 'feat/eyeL_iris.png')
hq_ = np.asarray(Image.open(OUT + 'feat/eyeL_hl.png')).astype(np.float32)
ha = cv2.GaussianBlur(hq_[..., 3], (0, 0), 1.6); hq_[..., 3] = np.clip((ha - 110) * 2.2 + 110, 0, 255); hq_[..., :3] = 255
Image.fromarray(hq_.round().clip(0, 255).astype(np.uint8)).save(OUT + 'feat/eyeL_hl.png')
print('eye edges smoothed')
la_ = np.asarray(Image.open(OUT + 'feat/eyeL_lash.png')).astype(np.float32)
a_ = cv2.GaussianBlur(la_[..., 3], (0, 0), .9); a_ = np.clip((a_ - 128) * 1.5 + 128, 0, 255)
n_, lb_, st_, _ = cv2.connectedComponentsWithStats((a_ > 40).astype(np.uint8), 8)
for i in range(1, n_):
    if st_[i, 4] < 120: a_[lb_ == i] = 0
la_[..., 3] = a_
Image.fromarray(la_.round().clip(0, 255).astype(np.uint8)).save(OUT + 'feat/eyeL_lash.png')
