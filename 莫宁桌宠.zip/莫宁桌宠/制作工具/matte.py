"""Green-screen matting, physically: c = a*fg + (1-a)*bg. The background colour is measured per image;
alpha comes from the green excess (g - max(r, b)), which the background has ~230 of and the figure ~0;
the colour is un-mixed from the background, so soft edges keep their true colour (no magenta, no green)."""
import numpy as np, cv2
from PIL import Image

def matte(path_or_img, noise=.06):
    im = path_or_img if isinstance(path_or_img, Image.Image) else Image.open(path_or_img)
    c = np.asarray(im.convert('RGB')).astype(np.float32)
    gd = c[..., 1] - np.maximum(c[..., 0], c[..., 2])
    bgm = gd > 150
    bg = np.median(c[bgm], 0) if bgm.sum() > 1000 else np.array([0, 255, 0], np.float32)
    bgd = float(bg[1] - max(bg[0], bg[2]))
    a = np.clip(1 - np.maximum(gd, 0) / bgd, 0, 1)
    a = np.where(a < noise, 0, np.where(a > 1 - noise, 1, (a - noise) / (1 - 2 * noise)))
    safe = np.maximum(a, .02)[..., None]
    fg = (c - (1 - safe) * bg) / safe
    fg = np.clip(fg, 0, 255)
    # what green is left is spill: a figure pixel is never greener than its larger other channel
    # (this figure has no colour greener than its red or blue: skin, gold, purple, lavender, white)
    g_lim = np.maximum(fg[..., 0], fg[..., 2]) + 2
    fg[..., 1] = np.minimum(fg[..., 1], g_lim)
    # chroma-subsampled spill at the rim (slate outline turned teal): near the edge, a pixel greener than its red
    # gets its green pulled to the mean of red and blue (gold and skin have green below red and are untouched)
    r_ = max(3, int(round(c.shape[0] / 256)))
    rim = cv2.dilate((a < .5).astype(np.uint8), np.ones((2 * r_ + 1, 2 * r_ + 1), np.uint8)).astype(bool)
    teal = rim & (fg[..., 1] > fg[..., 0])
    fg[..., 1] = np.where(teal, np.minimum(fg[..., 1], (fg[..., 0] + fg[..., 2]) / 2 + 4), fg[..., 1])
    fg = np.where((a > 0)[..., None], fg, 0)
    return np.dstack([fg, a * 255]).round().clip(0, 255).astype(np.uint8)
