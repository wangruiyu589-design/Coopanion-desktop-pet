"""Register an edit image to the master (ECC affine on luminance, only where both have content)."""
import cv2, numpy as np, sys
sys.path.insert(0, '/tmp/pet/tools')
from matte import matte

def gray_on(rgba, bg=128):
    a = rgba[..., 3:4] / 255.0
    rgb = rgba[..., :3] * a + bg * (1 - a)
    return cv2.cvtColor(rgb.astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32) / 255.0

def register(master_rgba, edit_rgba, mask=None, iters=300, motion=cv2.MOTION_AFFINE):
    """Returns (warp 2x3, cc, warped edit rgba). mask: uint8 region of master to use."""
    A = gray_on(master_rgba); B = gray_on(edit_rgba)
    sA = cv2.GaussianBlur(A, (0, 0), 1.5); sB = cv2.GaussianBlur(B, (0, 0), 1.5)
    W = np.eye(2, 3, dtype=np.float32)
    if mask is None:
        mask = ((master_rgba[..., 3] > 128) & (edit_rgba[..., 3] > 128)).astype(np.uint8) * 255
    try:
        cc, W = cv2.findTransformECC(sA, sB, W, motion, (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, iters, 1e-6), mask, 5)
    except cv2.error as e:
        return None, 0.0, None
    h, w = A.shape
    out = cv2.warpAffine(edit_rgba, W, (w, h), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
    return W, cc, out
