"""Async image task helper for api.seedance.nz.
usage: python gen.py submit MODEL OUT.png "prompt" [img1 img2 ...] [--size 1:1] [--field image]
       python gen.py poll                       # polls every pending job in jobs.json, downloads finished ones
Key is read from env SEEDANCE_KEY (never written to disk)."""
import urllib.error, base64, json, os, sys, time, urllib.request, mimetypes
API = 'https://api.seedance.nz/v1/image/generations'
KEY = os.environ['SEEDANCE_KEY']
JOBS = os.path.join(os.path.dirname(__file__), 'jobs.json')

def req(url, body=None):
    r = urllib.request.Request(url, data=None if body is None else json.dumps(body).encode(),
        headers={'Authorization': f'Bearer {KEY}', 'Content-Type': 'application/json', 'User-Agent': 'curl/8'})
    try:
        with urllib.request.urlopen(r, timeout=120) as f:
            return json.loads(f.read())
    except urllib.error.HTTPError as e:
        return {'_http': e.code, '_body': e.read().decode('utf-8', 'replace')[:800]}

def data_url(p):
    mt = mimetypes.guess_type(p)[0] or 'image/png'
    return f'data:{mt};base64,' + base64.b64encode(open(p, 'rb').read()).decode()

def load():
    return json.load(open(JOBS)) if os.path.exists(JOBS) else {}

def save(j):
    json.dump(j, open(JOBS, 'w'), indent=1, ensure_ascii=False)

def submit(model, out, prompt, imgs, size='1:1', field='image', extra=None):
    body = {'model': model, 'prompt': prompt, 'n': 1, 'size': size}
    if extra: body.update(extra)
    if imgs:
        urls = [data_url(p) for p in imgs]
        body[field] = urls[0] if field == 'image' and len(urls) == 1 else urls
    r = req(API, body)
    tid = r.get('task_id') or r.get('id')
    if not tid:
        print('SUBMIT FAIL', r); return None
    j = load(); j[out] = {'task': tid, 'model': model, 'prompt': prompt[:200], 'imgs': imgs, 'status': 'queued', 't': time.time()}; save(j)
    print('submitted', out, tid)
    return tid

def poll():
    j = load(); pending = 0
    for out, info in j.items():
        if info['status'] in ('done', 'failed'): continue
        try:
            r = req(f"{API}/{info['task']}")
        except Exception as e:
            print('poll err', out, e); pending += 1; continue
        d = r.get('data', r)
        st = d.get('status')
        if st == 'SUCCESS':
            url = d.get('result_url') or d['data']['content']['image_url']
            rq = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
            open(out, 'wb').write(urllib.request.urlopen(rq, timeout=120).read())
            info['status'] = 'done'; info['url'] = url
            print('DONE', out, f"{time.time()-info['t']:.0f}s")
        elif st in ('FAILURE', 'FAILED', 'failed'):
            info['status'] = 'failed'; info['reason'] = d.get('fail_reason'); print('FAILED', out, d.get('fail_reason'))
        else:
            pending += 1; info['status'] = st or 'queued'
    save(j); print('pending', pending)
    return pending

if __name__ == '__main__':
    a = sys.argv[1:]
    if a[0] == 'submit':
        size = 'auto'; field = 'image'
        if '--size' in a: i = a.index('--size'); size = a[i+1]; del a[i:i+2]
        if '--field' in a: i = a.index('--field'); field = a[i+1]; del a[i:i+2]
        extra = None
        if '--extra' in a: i = a.index('--extra'); extra = json.loads(a[i+1]); del a[i:i+2]
        submit(a[1], a[2], a[3], a[4:], size, field, extra)
    elif a[0] == 'poll':
        poll()
